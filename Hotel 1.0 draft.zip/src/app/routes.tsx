import { createBrowserRouter } from 'react-router';
import { LandingPage } from './pages/LandingPage';
import { LoginPage } from './pages/LoginPage';
import { AdminLayout } from './components/AdminLayout';
import { AdminDashboard } from './pages/AdminDashboard';
import { FrontDeskDashboard } from './pages/FrontDeskDashboard';
import { ReservationsPage } from './pages/ReservationsPage';
import { RoomsPage } from './pages/RoomsPage';
import { GuestsPage } from './pages/GuestsPage';
import { CheckInOutPage } from './pages/CheckInOutPage';
import { ReportsPage } from './pages/ReportsPage';
import { SettingsPage } from './pages/SettingsPage';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: LandingPage,
  },
  {
    path: '/login',
    Component: LoginPage,
  },
  {
    path: '/admin',
    Component: AdminLayout,
    children: [
      { index: true, Component: AdminDashboard },
      { path: 'reservations', Component: ReservationsPage },
      { path: 'rooms', Component: RoomsPage },
      { path: 'guests', Component: GuestsPage },
      { path: 'checkinout', Component: CheckInOutPage },
      { path: 'reports', Component: ReportsPage },
      { path: 'settings', Component: SettingsPage },
    ],
  },
  {
    path: '/frontdesk',
    Component: AdminLayout,
    children: [
      { index: true, Component: FrontDeskDashboard },
      { path: 'reservations', Component: ReservationsPage },
      { path: 'rooms', Component: RoomsPage },
      { path: 'guests', Component: GuestsPage },
      { path: 'checkinout', Component: CheckInOutPage },
    ],
  },
]);
