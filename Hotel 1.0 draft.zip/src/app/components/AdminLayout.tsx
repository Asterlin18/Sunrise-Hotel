import { useState } from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router';
import { motion, AnimatePresence } from 'motion/react';
import {
  LayoutDashboard, CalendarDays, BedDouble, Users, ArrowLeftRight,
  BarChart3, Settings, LogOut, ChevronLeft, ChevronRight, Bell,
  Sun, Menu, X, Briefcase
} from 'lucide-react';

const ADMIN_NAV = [
  { label: 'Dashboard', icon: LayoutDashboard, path: '/admin' },
  { label: 'Reservations', icon: CalendarDays, path: '/admin/reservations' },
  { label: 'Room Management', icon: BedDouble, path: '/admin/rooms' },
  { label: 'Guests', icon: Users, path: '/admin/guests' },
  { label: 'Check-In / Out', icon: ArrowLeftRight, path: '/admin/checkinout' },
  { label: 'Reports', icon: BarChart3, path: '/admin/reports' },
  { label: 'Settings', icon: Settings, path: '/admin/settings' },
];

const FRONTDESK_NAV = [
  { label: 'Dashboard', icon: LayoutDashboard, path: '/frontdesk' },
  { label: 'Reservations', icon: CalendarDays, path: '/frontdesk/reservations' },
  { label: 'Room Management', icon: BedDouble, path: '/frontdesk/rooms' },
  { label: 'Guests', icon: Users, path: '/frontdesk/guests' },
  { label: 'Check-In / Out', icon: ArrowLeftRight, path: '/frontdesk/checkinout' },
];

export function AdminLayout() {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  const isFrontDesk = location.pathname.startsWith('/frontdesk');
  const navItems = isFrontDesk ? FRONTDESK_NAV : ADMIN_NAV;
  const roleLabel = isFrontDesk ? 'Front Desk' : 'Administrator';
  const roleColor = isFrontDesk ? '#3a5f7a' : '#c4943d';

  const isActive = (path: string) => {
    if (path === '/admin' || path === '/frontdesk') {
      return location.pathname === path;
    }
    return location.pathname.startsWith(path);
  };

  return (
    <div style={{ backgroundColor: '#0f1510', minHeight: '100vh', display: 'flex', fontFamily: "'EB Garamond', serif" }}>
      {/* Mobile overlay */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setMobileOpen(false)}
            className="fixed inset-0 z-40 lg:hidden"
            style={{ backgroundColor: 'rgba(0,0,0,0.7)' }}
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <motion.aside
        animate={{ width: collapsed ? 72 : 240 }}
        transition={{ duration: 0.3, ease: 'easeInOut' }}
        className="hidden lg:flex flex-col sticky top-0 h-screen z-50 flex-shrink-0"
        style={{
          backgroundColor: '#141a11',
          borderRight: '1px solid #344a2a',
          overflow: 'hidden',
        }}
      >
        <SidebarContent
          collapsed={collapsed}
          navItems={navItems}
          roleLabel={roleLabel}
          roleColor={roleColor}
          isActive={isActive}
          navigate={navigate}
          onToggle={() => setCollapsed(!collapsed)}
          isFrontDesk={isFrontDesk}
        />
      </motion.aside>

      {/* Mobile Sidebar */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.aside
            initial={{ x: -240 }}
            animate={{ x: 0 }}
            exit={{ x: -240 }}
            transition={{ duration: 0.3, ease: 'easeInOut' }}
            className="fixed left-0 top-0 h-screen z-50 lg:hidden flex flex-col"
            style={{
              width: 240,
              backgroundColor: '#141a11',
              borderRight: '1px solid #344a2a',
            }}
          >
            <SidebarContent
              collapsed={false}
              navItems={navItems}
              roleLabel={roleLabel}
              roleColor={roleColor}
              isActive={isActive}
              navigate={navigate}
              onToggle={() => setMobileOpen(false)}
              isFrontDesk={isFrontDesk}
              mobileClose
            />
          </motion.aside>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Bar */}
        <header
          className="flex items-center justify-between px-6 py-3 sticky top-0 z-30"
          style={{
            backgroundColor: '#141a11',
            borderBottom: '1px solid #344a2a',
            height: 60,
          }}
        >
          <div className="flex items-center gap-4">
            <button
              onClick={() => setMobileOpen(true)}
              className="lg:hidden p-2 rounded"
              style={{ color: '#9a9278' }}
            >
              <Menu size={20} />
            </button>
            <div>
              <span style={{ color: '#9a9278', fontSize: '0.75rem', fontFamily: "'Cinzel', serif", letterSpacing: '0.1em' }}>
                SUNRISE HAVEN HOTEL
              </span>
              <div style={{ color: '#c4943d', fontSize: '0.7rem', fontFamily: "'Cinzel', serif", letterSpacing: '0.08em' }}>
                {roleLabel} Portal
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Date/Time */}
            <div className="hidden md:block text-right">
              <div style={{ color: '#9a9278', fontSize: '0.7rem', fontFamily: "'Cinzel', serif", letterSpacing: '0.06em' }}>
                {new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
              </div>
            </div>
            {/* Notification Bell */}
            <button
              className="relative p-2 rounded-lg transition-colors"
              style={{ color: '#9a9278' }}
              onMouseEnter={e => (e.currentTarget.style.color = '#c4943d')}
              onMouseLeave={e => (e.currentTarget.style.color = '#9a9278')}
            >
              <Bell size={18} />
              <span
                className="absolute top-1 right-1 w-2 h-2 rounded-full"
                style={{ backgroundColor: '#c4943d' }}
              />
            </button>
            {/* Profile */}
            <button
              onClick={() => navigate('/')}
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg transition-all"
              style={{ color: '#e8dfc8', backgroundColor: '#222a1e', border: '1px solid #344a2a' }}
              onMouseEnter={e => (e.currentTarget.style.borderColor = '#c4943d')}
              onMouseLeave={e => (e.currentTarget.style.borderColor = '#344a2a')}
            >
              <div
                className="w-7 h-7 rounded-full flex items-center justify-center"
                style={{ backgroundColor: roleColor, fontSize: '0.65rem', fontFamily: "'Cinzel', serif", color: '#141a11' }}
              >
                {isFrontDesk ? 'FD' : 'AD'}
              </div>
              <span className="hidden md:block" style={{ fontFamily: "'Cinzel', serif", fontSize: '0.72rem', letterSpacing: '0.05em' }}>
                {isFrontDesk ? 'Front Desk' : 'Admin'}
              </span>
            </button>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-auto" style={{ backgroundColor: '#0f1510' }}>
          <motion.div
            key={location.pathname}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            <Outlet />
          </motion.div>
        </main>
      </div>
    </div>
  );
}

interface SidebarContentProps {
  collapsed: boolean;
  navItems: typeof ADMIN_NAV;
  roleLabel: string;
  roleColor: string;
  isActive: (path: string) => boolean;
  navigate: (path: string) => void;
  onToggle: () => void;
  isFrontDesk: boolean;
  mobileClose?: boolean;
}

function SidebarContent({
  collapsed, navItems, roleLabel, roleColor, isActive, navigate, onToggle, isFrontDesk, mobileClose
}: SidebarContentProps) {
  return (
    <>
      {/* Logo Area */}
      <div
        className="flex items-center justify-between px-4 py-4"
        style={{ borderBottom: '1px solid #344a2a', minHeight: 60 }}
      >
        <div className="flex items-center gap-3 overflow-hidden">
          <div
            className="flex-shrink-0 w-9 h-9 rounded-lg flex items-center justify-center"
            style={{
              background: 'linear-gradient(135deg, #c4943d, #e0b85a)',
              boxShadow: '0 0 12px rgba(196, 148, 61, 0.4)',
            }}
          >
            <Sun size={18} style={{ color: '#141a11' }} />
          </div>
          <AnimatePresence>
            {!collapsed && (
              <motion.div
                initial={{ opacity: 0, width: 0 }}
                animate={{ opacity: 1, width: 'auto' }}
                exit={{ opacity: 0, width: 0 }}
                className="overflow-hidden"
              >
                <div style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '0.8rem', fontWeight: 600, letterSpacing: '0.05em', whiteSpace: 'nowrap' }}>
                  SUNRISE HAVEN
                </div>
                <div style={{ fontFamily: "'Cormorant Garamond', serif", color: roleColor, fontSize: '0.65rem', letterSpacing: '0.1em', whiteSpace: 'nowrap' }}>
                  {roleLabel}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
        <button
          onClick={onToggle}
          className="flex-shrink-0 p-1.5 rounded transition-colors"
          style={{ color: '#9a9278' }}
          onMouseEnter={e => (e.currentTarget.style.color = '#c4943d')}
          onMouseLeave={e => (e.currentTarget.style.color = '#9a9278')}
        >
          {mobileClose ? <X size={16} /> : collapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
        </button>
      </div>

      {/* Decorative Japanese motif */}
      {!collapsed && (
        <div className="px-4 py-2" style={{ borderBottom: '1px solid #2a3526' }}>
          <div style={{ color: '#4a6a3a', fontSize: '0.6rem', fontFamily: "'Noto Serif JP', serif", letterSpacing: '0.15em', textAlign: 'center' }}>
            ── 旅館管理システム ──
          </div>
        </div>
      )}

      {/* Nav Items */}
      <nav className="flex-1 py-3 overflow-y-auto">
        {navItems.map((item) => {
          const active = isActive(item.path);
          const Icon = item.icon;
          return (
            <motion.button
              key={item.path}
              onClick={() => navigate(item.path)}
              className="w-full flex items-center gap-3 px-4 py-3 transition-all relative group"
              whileHover={{ x: 2 }}
              style={{
                backgroundColor: active ? 'rgba(196, 148, 61, 0.12)' : 'transparent',
                borderRight: active ? `2px solid #c4943d` : '2px solid transparent',
                color: active ? '#c4943d' : '#9a9278',
              }}
              onMouseEnter={e => {
                if (!active) e.currentTarget.style.color = '#e8dfc8';
              }}
              onMouseLeave={e => {
                if (!active) e.currentTarget.style.color = '#9a9278';
              }}
            >
              <Icon size={18} className="flex-shrink-0" />
              <AnimatePresence>
                {!collapsed && (
                  <motion.span
                    initial={{ opacity: 0, width: 0 }}
                    animate={{ opacity: 1, width: 'auto' }}
                    exit={{ opacity: 0, width: 0 }}
                    className="overflow-hidden whitespace-nowrap text-left"
                    style={{ fontFamily: "'Cinzel', serif", fontSize: '0.72rem', letterSpacing: '0.06em' }}
                  >
                    {item.label}
                  </motion.span>
                )}
              </AnimatePresence>
              {/* Active indicator glow */}
              {active && (
                <motion.div
                  layoutId="activeIndicator"
                  className="absolute left-0 top-0 bottom-0 w-0.5"
                  style={{ backgroundColor: '#c4943d', boxShadow: '0 0 6px #c4943d' }}
                />
              )}
            </motion.button>
          );
        })}

        {/* Divider */}
        <div className="mx-4 my-3" style={{ borderTop: '1px solid #2a3526' }} />

        {/* Switch Role */}
        <motion.button
          onClick={() => navigate(isFrontDesk ? '/admin' : '/frontdesk')}
          className="w-full flex items-center gap-3 px-4 py-3 transition-all"
          whileHover={{ x: 2 }}
          style={{ color: '#9a9278' }}
          onMouseEnter={e => (e.currentTarget.style.color = '#6a9954')}
          onMouseLeave={e => (e.currentTarget.style.color = '#9a9278')}
        >
          <Briefcase size={18} className="flex-shrink-0" />
          {!collapsed && (
            <span style={{ fontFamily: "'Cinzel', serif", fontSize: '0.72rem', letterSpacing: '0.06em' }}>
              {isFrontDesk ? 'Admin Portal' : 'Front Desk'}
            </span>
          )}
        </motion.button>
      </nav>

      {/* Bottom: Logout */}
      <div style={{ borderTop: '1px solid #344a2a', padding: '12px' }}>
        <motion.button
          onClick={() => navigate('/login')}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all"
          whileHover={{ x: 2 }}
          style={{ color: '#9a9278' }}
          onMouseEnter={e => {
            e.currentTarget.style.color = '#c87a7a';
            e.currentTarget.style.backgroundColor = 'rgba(139, 53, 53, 0.15)';
          }}
          onMouseLeave={e => {
            e.currentTarget.style.color = '#9a9278';
            e.currentTarget.style.backgroundColor = 'transparent';
          }}
        >
          <LogOut size={18} className="flex-shrink-0" />
          {!collapsed && (
            <span style={{ fontFamily: "'Cinzel', serif", fontSize: '0.72rem', letterSpacing: '0.06em' }}>
              Sign Out
            </span>
          )}
        </motion.button>
      </div>
    </>
  );
}
