import { useState } from 'react';
import type { ComponentType } from 'react';
import { useNavigate } from 'react-router';
import { motion } from 'motion/react';
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from 'recharts';
import {
  BedDouble, CalendarDays, Users, TrendingUp, CheckCircle2,
  XCircle, Clock, AlertTriangle, ChevronRight, ArrowUp, ArrowDown
} from 'lucide-react';

const reservationTrend = [
  { month: 'Oct', reservations: 68, revenue: 238000 },
  { month: 'Nov', reservations: 82, revenue: 287000 },
  { month: 'Dec', reservations: 115, revenue: 402500 },
  { month: 'Jan', reservations: 94, revenue: 329000 },
  { month: 'Feb', reservations: 88, revenue: 308000 },
  { month: 'Mar', reservations: 102, revenue: 357000 },
  { month: 'Apr', reservations: 78, revenue: 273000 },
];

const occupancyData = [
  { name: 'Occupied', value: 74, color: '#6a9954' },
  { name: 'Available', value: 31, color: '#344a2a' },
  { name: 'Maintenance', value: 15, color: '#8b5a2b' },
];

const revenueByType = [
  { type: 'Standard', revenue: 128000 },
  { type: 'Premium', revenue: 187000 },
  { type: 'Suite', revenue: 258000 },
  { type: 'Events', revenue: 96000 },
];

const recentActivity = [
  { id: 'RES-2026-089', guest: 'Maria Santos', room: '305', type: 'Check-In', time: '8:32 AM', status: 'completed' },
  { id: 'RES-2026-087', guest: 'Juan dela Cruz', room: '212', type: 'Check-Out', time: '9:15 AM', status: 'completed' },
  { id: 'RES-2026-091', guest: 'Ana Reyes', room: '418', type: 'Reservation', time: '10:05 AM', status: 'pending' },
  { id: 'RES-2026-090', guest: 'Carlos Mañalac', room: '110', type: 'Check-In', time: '11:00 AM', status: 'pending' },
  { id: 'RES-2026-088', guest: 'Lucia Fernandez', room: '307', type: 'Check-Out', time: '12:00 PM', status: 'upcoming' },
];

const statusConfig: Record<string, { color: string; bg: string; icon: ComponentType<any> }> = {
  completed: { color: '#6a9954', bg: 'rgba(106,153,84,0.12)', icon: CheckCircle2 },
  pending: { color: '#c4943d', bg: 'rgba(196,148,61,0.12)', icon: Clock },
  upcoming: { color: '#3a5f7a', bg: 'rgba(58,95,122,0.12)', icon: AlertTriangle },
  cancelled: { color: '#8b3535', bg: 'rgba(139,53,53,0.12)', icon: XCircle },
};

interface StatCardProps {
  label: string;
  value: string | number;
  sub: string;
  icon: ComponentType<any>;
  trend?: number;
  accentColor: string;
  onClick?: () => void;
}

function StatCard({ label, value, sub, icon: Icon, trend, accentColor, onClick }: StatCardProps) {
  return (
    <motion.div
      whileHover={{ y: -2 }}
      onClick={onClick}
      className="rounded-2xl p-5 cursor-pointer relative overflow-hidden"
      style={{ backgroundColor: '#1a2016', border: '1px solid #2a3526', transition: 'border-color 0.3s' }}
      onMouseEnter={e => (e.currentTarget.style.borderColor = accentColor)}
      onMouseLeave={e => (e.currentTarget.style.borderColor = '#2a3526')}
    >
      <div className="absolute top-0 left-0 right-0 h-px" style={{ background: `linear-gradient(to right, transparent, ${accentColor}55, transparent)` }} />
      <div className="flex items-start justify-between mb-4">
        <div
          className="w-10 h-10 rounded-xl flex items-center justify-center"
          style={{ backgroundColor: `${accentColor}18`, border: `1px solid ${accentColor}30` }}
        >
          <Icon size={18} style={{ color: accentColor }} />
        </div>
        {trend !== undefined && (
          <div className="flex items-center gap-1" style={{ color: trend >= 0 ? '#6a9954' : '#8b3535', fontSize: '0.75rem' }}>
            {trend >= 0 ? <ArrowUp size={12} /> : <ArrowDown size={12} />}
            {Math.abs(trend)}%
          </div>
        )}
      </div>
      <div style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '1.8rem', fontWeight: 700, lineHeight: 1 }}>
        {value}
      </div>
      <div style={{ fontFamily: "'Cinzel', serif", color: '#9a9278', fontSize: '0.65rem', letterSpacing: '0.12em', marginTop: '0.3rem' }}>
        {label}
      </div>
      <div style={{ color: '#4a6a3a', fontSize: '0.78rem', marginTop: '0.4rem' }}>{sub}</div>
    </motion.div>
  );
}

export function AdminDashboard() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'overview' | 'revenue'>('overview');

  return (
    <div className="p-6 space-y-6" style={{ fontFamily: "'EB Garamond', serif" }}>
      {/* Page Header */}
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <div className="h-px w-6" style={{ backgroundColor: '#c4943d' }} />
            <span style={{ fontFamily: "'Cinzel', serif", color: '#c4943d', fontSize: '0.65rem', letterSpacing: '0.2em' }}>
              OPERATIONAL NEXUS
            </span>
          </div>
          <h1 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '1.6rem', fontWeight: 600, letterSpacing: '0.04em' }}>
            Admin Dashboard
          </h1>
          <p style={{ color: '#9a9278', fontSize: '0.9rem' }}>
            Live overview — {new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </p>
        </div>

        <div className="flex gap-2">
          <button
            onClick={() => navigate('/admin/checkinout')}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl transition-all"
            style={{ fontFamily: "'Cinzel', serif", fontSize: '0.7rem', letterSpacing: '0.08em', color: '#141a11', background: 'linear-gradient(135deg, #c4943d, #a87830)', fontWeight: 700 }}
          >
            <CheckCircle2 size={14} />
            Check In Guest
          </button>
          <button
            onClick={() => navigate('/admin/reservations')}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl transition-all"
            style={{ fontFamily: "'Cinzel', serif", fontSize: '0.7rem', letterSpacing: '0.08em', color: '#e8dfc8', border: '1px solid #344a2a', backgroundColor: '#1e2519' }}
            onMouseEnter={e => (e.currentTarget.style.borderColor = '#c4943d')}
            onMouseLeave={e => (e.currentTarget.style.borderColor = '#344a2a')}
          >
            <CalendarDays size={14} />
            New Reservation
          </button>
        </div>
      </div>

      {/* ── STAT CARDS ── */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          label="TOTAL ROOMS" value="120" sub="15 under maintenance"
          icon={BedDouble} trend={0} accentColor="#c4943d"
          onClick={() => navigate('/admin/rooms')}
        />
        <StatCard
          label="TODAY'S RESERVATIONS" value="23" sub="8 arriving · 6 departing"
          icon={CalendarDays} trend={12} accentColor="#6a9954"
          onClick={() => navigate('/admin/reservations')}
        />
        <StatCard
          label="GUESTS CHECKED-IN" value="74" sub="Out of 105 occupied rooms"
          icon={Users} trend={5} accentColor="#3a5f7a"
          onClick={() => navigate('/admin/guests')}
        />
        <StatCard
          label="MONTHLY REVENUE" value="₱2.35M" sub="↑ ₱180K vs last month"
          icon={TrendingUp} trend={8} accentColor="#9a6a3a"
          onClick={() => navigate('/admin/reports')}
        />
      </div>

      {/* ── CHARTS ROW ── */}
      <div className="grid lg:grid-cols-3 gap-5">
        {/* Reservation Trend - wide */}
        <div
          className="lg:col-span-2 rounded-2xl p-5"
          style={{ backgroundColor: '#1a2016', border: '1px solid #2a3526' }}
        >
          <div className="flex items-center justify-between mb-5">
            <div>
              <h3 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '0.85rem', letterSpacing: '0.08em' }}>Reservation Trends</h3>
              <p style={{ color: '#9a9278', fontSize: '0.8rem' }}>Past 7 months</p>
            </div>
            <div className="flex gap-1">
              {(['overview', 'revenue'] as const).map(tab => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className="px-3 py-1.5 rounded-lg transition-all"
                  style={{
                    fontFamily: "'Cinzel', serif", fontSize: '0.62rem', letterSpacing: '0.08em',
                    backgroundColor: activeTab === tab ? 'rgba(196,148,61,0.15)' : 'transparent',
                    color: activeTab === tab ? '#c4943d' : '#9a9278',
                    border: activeTab === tab ? '1px solid rgba(196,148,61,0.3)' : '1px solid transparent',
                  }}
                >
                  {tab.charAt(0).toUpperCase() + tab.slice(1)}
                </button>
              ))}
            </div>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={reservationTrend} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="resGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={activeTab === 'overview' ? '#6a9954' : '#c4943d'} stopOpacity={0.3} />
                  <stop offset="95%" stopColor={activeTab === 'overview' ? '#6a9954' : '#c4943d'} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e2519" />
              <XAxis dataKey="month" tick={{ fill: '#9a9278', fontSize: 11, fontFamily: "'Cinzel', serif" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: '#9a9278', fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip
                contentStyle={{ backgroundColor: '#1e2519', border: '1px solid #344a2a', borderRadius: '8px', fontFamily: "'EB Garamond', serif" }}
                labelStyle={{ color: '#c4943d', fontFamily: "'Cinzel', serif", fontSize: '0.75rem' }}
                itemStyle={{ color: '#e8dfc8' }}
              />
              <Area
                type="monotone"
                dataKey={activeTab === 'overview' ? 'reservations' : 'revenue'}
                stroke={activeTab === 'overview' ? '#6a9954' : '#c4943d'}
                strokeWidth={2}
                fill="url(#resGrad)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Occupancy Pie */}
        <div
          className="rounded-2xl p-5"
          style={{ backgroundColor: '#1a2016', border: '1px solid #2a3526' }}
        >
          <h3 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '0.85rem', letterSpacing: '0.08em', marginBottom: '4px' }}>
            Room Occupancy
          </h3>
          <p style={{ color: '#9a9278', fontSize: '0.8rem', marginBottom: '16px' }}>120 total rooms</p>
          <ResponsiveContainer width="100%" height={160}>
            <PieChart>
              <Pie
                data={occupancyData}
                cx="50%"
                cy="50%"
                innerRadius={50}
                outerRadius={72}
                dataKey="value"
                strokeWidth={0}
              >
                {occupancyData.map((entry, i) => (
                  <Cell key={i} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{ backgroundColor: '#1e2519', border: '1px solid #344a2a', borderRadius: '8px' }}
                itemStyle={{ color: '#e8dfc8' }}
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-2 mt-2">
            {occupancyData.map(item => (
              <div key={item.name} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }} />
                  <span style={{ color: '#9a9278', fontSize: '0.82rem' }}>{item.name}</span>
                </div>
                <span style={{ color: '#e8dfc8', fontSize: '0.82rem', fontFamily: "'Cinzel', serif" }}>{item.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── LOWER ROW ── */}
      <div className="grid lg:grid-cols-3 gap-5">
        {/* Revenue by Type */}
        <div
          className="rounded-2xl p-5"
          style={{ backgroundColor: '#1a2016', border: '1px solid #2a3526' }}
        >
          <h3 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '0.85rem', letterSpacing: '0.08em', marginBottom: '4px' }}>
            Revenue by Room Type
          </h3>
          <p style={{ color: '#9a9278', fontSize: '0.8rem', marginBottom: '16px' }}>This month (April)</p>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={revenueByType} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e2519" vertical={false} />
              <XAxis dataKey="type" tick={{ fill: '#9a9278', fontSize: 10, fontFamily: "'Cinzel', serif" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: '#9a9278', fontSize: 10 }} axisLine={false} tickLine={false} />
              <Tooltip
                contentStyle={{ backgroundColor: '#1e2519', border: '1px solid #344a2a', borderRadius: '8px' }}
                itemStyle={{ color: '#e8dfc8' }}
                formatter={(v: number) => [`₱${v.toLocaleString()}`, 'Revenue']}
              />
              <Bar dataKey="revenue" fill="#c4943d" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Recent Activity */}
        <div
          className="lg:col-span-2 rounded-2xl p-5"
          style={{ backgroundColor: '#1a2016', border: '1px solid #2a3526' }}
        >
          <div className="flex items-center justify-between mb-5">
            <div>
              <h3 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '0.85rem', letterSpacing: '0.08em' }}>Recent Activity</h3>
              <p style={{ color: '#9a9278', fontSize: '0.8rem' }}>Today's log</p>
            </div>
            <button
              onClick={() => navigate('/admin/checkinout')}
              className="flex items-center gap-1 transition-colors"
              style={{ color: '#c4943d', fontFamily: "'Cinzel', serif", fontSize: '0.65rem', letterSpacing: '0.1em' }}
            >
              View All <ChevronRight size={12} />
            </button>
          </div>
          <div className="space-y-2">
            {recentActivity.map((item) => {
              const cfg = statusConfig[item.status];
              const Icon = cfg.icon;
              return (
                <motion.div
                  key={item.id}
                  whileHover={{ x: 2 }}
                  className="flex items-center justify-between px-4 py-3 rounded-xl"
                  style={{ backgroundColor: '#222a1e', border: '1px solid #2a3526', cursor: 'default' }}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0" style={{ backgroundColor: cfg.bg }}>
                      <Icon size={14} style={{ color: cfg.color }} />
                    </div>
                    <div>
                      <div style={{ color: '#e8dfc8', fontSize: '0.9rem' }}>{item.guest}</div>
                      <div style={{ color: '#9a9278', fontSize: '0.75rem', fontFamily: "'Cinzel', serif", letterSpacing: '0.06em' }}>
                        {item.id} · Room {item.room}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div style={{ color: cfg.color, fontSize: '0.78rem', fontFamily: "'Cinzel', serif", letterSpacing: '0.06em' }}>
                      {item.type}
                    </div>
                    <div style={{ color: '#4a6a3a', fontSize: '0.72rem' }}>{item.time}</div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}