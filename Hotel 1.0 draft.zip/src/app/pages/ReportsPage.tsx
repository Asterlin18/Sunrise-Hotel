import { useState } from 'react';
import { motion } from 'motion/react';
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, Legend
} from 'recharts';
import { TrendingUp, BedDouble, Users, Calendar, ArrowUp, Download, Filter } from 'lucide-react';

const monthlyRevenue = [
  { month: 'Jan', revenue: 1820000, occupancy: 72, guests: 286 },
  { month: 'Feb', revenue: 1640000, occupancy: 65, guests: 259 },
  { month: 'Mar', revenue: 2100000, occupancy: 83, guests: 326 },
  { month: 'Apr', revenue: 2350000, occupancy: 88, guests: 367 },
  { month: 'May', revenue: 1980000, occupancy: 78, guests: 311 },
  { month: 'Jun', revenue: 1750000, occupancy: 69, guests: 274 },
  { month: 'Jul', revenue: 2200000, occupancy: 85, guests: 342 },
  { month: 'Aug', revenue: 2450000, occupancy: 91, guests: 378 },
  { month: 'Sep', revenue: 2100000, occupancy: 82, guests: 326 },
  { month: 'Oct', revenue: 1920000, occupancy: 76, guests: 299 },
  { month: 'Nov', revenue: 2300000, occupancy: 87, guests: 358 },
  { month: 'Dec', revenue: 2780000, occupancy: 95, guests: 432 },
];

const roomTypeRevenue = [
  { name: 'Standard', value: 38, color: '#6a9954', amount: '₱892,400' },
  { name: 'Premium', value: 42, color: '#c4943d', amount: '₱987,000' },
  { name: 'Suite', value: 20, color: '#9a6aaa', amount: '₱470,000' },
];

const weeklyReservations = [
  { day: 'Mon', new: 8, cancelled: 1, completed: 6 },
  { day: 'Tue', new: 12, cancelled: 2, completed: 9 },
  { day: 'Wed', new: 6, cancelled: 0, completed: 8 },
  { day: 'Thu', new: 15, cancelled: 1, completed: 11 },
  { day: 'Fri', new: 22, cancelled: 3, completed: 14 },
  { day: 'Sat', new: 28, cancelled: 2, completed: 18 },
  { day: 'Sun', new: 19, cancelled: 1, completed: 15 },
];

const guestNationality = [
  { country: 'Filipino', count: 2840 },
  { country: 'American', count: 420 },
  { country: 'Korean', count: 380 },
  { country: 'Japanese', count: 290 },
  { country: 'Australian', count: 210 },
  { country: 'Others', count: 260 },
];

const monthlyReservationTable = [
  { month: 'January 2026', reservations: 94, checkIns: 88, checkOuts: 82, revenue: '₱1,820,000', occupancy: '72%', avgStay: '3.2 nights' },
  { month: 'February 2026', reservations: 78, checkIns: 71, checkOuts: 69, revenue: '₱1,640,000', occupancy: '65%', avgStay: '3.0 nights' },
  { month: 'March 2026', reservations: 112, checkIns: 105, checkOuts: 98, revenue: '₱2,100,000', occupancy: '83%', avgStay: '3.5 nights' },
  { month: 'April 2026', reservations: 127, checkIns: 119, checkOuts: 0, revenue: '₱2,350,000', occupancy: '88%', avgStay: '3.8 nights' },
];

type Period = 'weekly' | 'monthly' | 'yearly';

export function ReportsPage() {
  const [period, setPeriod] = useState<Period>('monthly');

  return (
    <div className="p-6 space-y-5" style={{ fontFamily: "'EB Garamond', serif" }}>
      {/* Header */}
      <div className="flex items-start justify-between flex-wrap gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <div className="h-px w-6" style={{ backgroundColor: '#c4943d' }} />
            <span style={{ fontFamily: "'Cinzel', serif", color: '#c4943d', fontSize: '0.65rem', letterSpacing: '0.2em' }}>ANALYTICS & INTELLIGENCE</span>
          </div>
          <h1 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '1.6rem', fontWeight: 600, letterSpacing: '0.04em' }}>
            Reports & Analytics
          </h1>
          <p style={{ color: '#9a9278', fontSize: '0.9rem' }}>Operational intelligence for Sunrise Haven Hotel</p>
        </div>
        <div className="flex gap-2">
          {(['weekly', 'monthly', 'yearly'] as Period[]).map(p => (
            <button
              key={p}
              onClick={() => setPeriod(p)}
              className="px-4 py-2 rounded-xl transition-all"
              style={{
                fontFamily: "'Cinzel', serif", fontSize: '0.68rem', letterSpacing: '0.08em',
                backgroundColor: period === p ? 'rgba(196,148,61,0.15)' : '#1a2016',
                color: period === p ? '#c4943d' : '#9a9278',
                border: period === p ? '1px solid rgba(196,148,61,0.3)' : '1px solid #2a3526',
              }}
            >
              {p.charAt(0).toUpperCase() + p.slice(1)}
            </button>
          ))}
          <button
            className="flex items-center gap-2 px-4 py-2 rounded-xl"
            style={{ fontFamily: "'Cinzel', serif", fontSize: '0.68rem', letterSpacing: '0.08em', backgroundColor: '#1a2016', color: '#9a9278', border: '1px solid #2a3526' }}
          >
            <Download size={13} /> Export
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'TOTAL REVENUE', value: '₱28.35M', sub: 'Year to date', trend: '+18.4%', icon: TrendingUp, color: '#c4943d' },
          { label: 'ROOMS OCCUPIED', value: '88%', sub: 'April 2026', trend: '+5.2%', icon: BedDouble, color: '#6a9954' },
          { label: 'TOTAL GUESTS', value: '4,400', sub: 'Year to date', trend: '+22.1%', icon: Users, color: '#5a8faa' },
          { label: 'RESERVATIONS', value: '411', sub: 'Year to date', trend: '+14.8%', icon: Calendar, color: '#9a6aaa' },
        ].map((kpi) => {
          const Icon = kpi.icon;
          return (
            <motion.div
              key={kpi.label}
              whileHover={{ y: -2 }}
              className="rounded-2xl p-5 relative overflow-hidden"
              style={{ backgroundColor: '#1a2016', border: '1px solid #2a3526' }}
            >
              <div className="absolute top-0 left-0 right-0 h-px" style={{ background: `linear-gradient(to right, transparent, ${kpi.color}55, transparent)` }} />
              <div className="flex items-center justify-between mb-3">
                <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ backgroundColor: `${kpi.color}18`, border: `1px solid ${kpi.color}30` }}>
                  <Icon size={17} style={{ color: kpi.color }} />
                </div>
                <div className="flex items-center gap-1" style={{ color: '#6a9954', fontSize: '0.75rem' }}>
                  <ArrowUp size={11} />
                  {kpi.trend}
                </div>
              </div>
              <div style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '1.7rem', fontWeight: 700, lineHeight: 1 }}>{kpi.value}</div>
              <div style={{ fontFamily: "'Cinzel', serif", color: '#9a9278', fontSize: '0.6rem', letterSpacing: '0.12em', marginTop: '0.3rem' }}>{kpi.label}</div>
              <div style={{ color: '#4a6a3a', fontSize: '0.78rem', marginTop: '0.25rem' }}>{kpi.sub}</div>
            </motion.div>
          );
        })}
      </div>

      {/* Revenue & Occupancy Chart */}
      <div className="grid lg:grid-cols-3 gap-5">
        <div className="lg:col-span-2 rounded-2xl p-5" style={{ backgroundColor: '#1a2016', border: '1px solid #2a3526' }}>
          <div className="mb-4">
            <h3 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '0.85rem', letterSpacing: '0.08em' }}>Revenue & Occupancy Trends</h3>
            <p style={{ color: '#9a9278', fontSize: '0.8rem' }}>Full year 2026 · Monthly breakdown</p>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={monthlyRevenue} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#c4943d" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#c4943d" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="occGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#6a9954" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#6a9954" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e2519" />
              <XAxis dataKey="month" tick={{ fill: '#9a9278', fontSize: 10, fontFamily: "'Cinzel', serif" }} axisLine={false} tickLine={false} />
              <YAxis yAxisId="rev" orientation="left" tick={{ fill: '#9a9278', fontSize: 10 }} axisLine={false} tickLine={false} tickFormatter={v => `₱${(v/1000000).toFixed(1)}M`} />
              <YAxis yAxisId="occ" orientation="right" tick={{ fill: '#9a9278', fontSize: 10 }} axisLine={false} tickLine={false} tickFormatter={v => `${v}%`} />
              <Tooltip
                contentStyle={{ backgroundColor: '#1e2519', border: '1px solid #344a2a', borderRadius: '8px' }}
                labelStyle={{ color: '#c4943d', fontFamily: "'Cinzel', serif", fontSize: '0.72rem' }}
                itemStyle={{ color: '#e8dfc8' }}
              />
              <Area yAxisId="rev" type="monotone" dataKey="revenue" stroke="#c4943d" strokeWidth={2} fill="url(#revGrad)" name="Revenue" />
              <Area yAxisId="occ" type="monotone" dataKey="occupancy" stroke="#6a9954" strokeWidth={2} fill="url(#occGrad)" name="Occupancy %" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Room Type Revenue Pie */}
        <div className="rounded-2xl p-5" style={{ backgroundColor: '#1a2016', border: '1px solid #2a3526' }}>
          <h3 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '0.85rem', letterSpacing: '0.08em', marginBottom: '4px' }}>Revenue by Room Type</h3>
          <p style={{ color: '#9a9278', fontSize: '0.8rem', marginBottom: '16px' }}>April 2026</p>
          <ResponsiveContainer width="100%" height={160}>
            <PieChart>
              <Pie data={roomTypeRevenue} cx="50%" cy="50%" innerRadius={50} outerRadius={72} dataKey="value" strokeWidth={0}>
                {roomTypeRevenue.map((entry, i) => (
                  <Cell key={i} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{ backgroundColor: '#1e2519', border: '1px solid #344a2a', borderRadius: '8px' }}
                itemStyle={{ color: '#e8dfc8' }}
                formatter={(v: number) => [`${v}%`, '']}
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-2 mt-2">
            {roomTypeRevenue.map(item => (
              <div key={item.name} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }} />
                  <span style={{ color: '#9a9278', fontSize: '0.82rem' }}>{item.name}</span>
                </div>
                <div className="text-right">
                  <span style={{ color: '#e8dfc8', fontSize: '0.82rem', fontFamily: "'Cinzel', serif" }}>{item.value}%</span>
                  <span style={{ color: '#4a6a3a', fontSize: '0.72rem', marginLeft: '6px' }}>{item.amount}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Weekly Reservations + Nationality */}
      <div className="grid lg:grid-cols-2 gap-5">
        <div className="rounded-2xl p-5" style={{ backgroundColor: '#1a2016', border: '1px solid #2a3526' }}>
          <h3 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '0.85rem', letterSpacing: '0.08em', marginBottom: '4px' }}>Weekly Reservation Activity</h3>
          <p style={{ color: '#9a9278', fontSize: '0.8rem', marginBottom: '16px' }}>Current week</p>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={weeklyReservations} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e2519" vertical={false} />
              <XAxis dataKey="day" tick={{ fill: '#9a9278', fontSize: 10, fontFamily: "'Cinzel', serif" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: '#9a9278', fontSize: 10 }} axisLine={false} tickLine={false} />
              <Tooltip
                contentStyle={{ backgroundColor: '#1e2519', border: '1px solid #344a2a', borderRadius: '8px' }}
                itemStyle={{ color: '#e8dfc8' }}
              />
              <Legend wrapperStyle={{ color: '#9a9278', fontSize: '0.75rem' }} />
              <Bar dataKey="new" fill="#c4943d" name="New" radius={[3, 3, 0, 0]} />
              <Bar dataKey="completed" fill="#6a9954" name="Completed" radius={[3, 3, 0, 0]} />
              <Bar dataKey="cancelled" fill="#8b3535" name="Cancelled" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Guest Nationality */}
        <div className="rounded-2xl p-5" style={{ backgroundColor: '#1a2016', border: '1px solid #2a3526' }}>
          <h3 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '0.85rem', letterSpacing: '0.08em', marginBottom: '4px' }}>Guest Nationality</h3>
          <p style={{ color: '#9a9278', fontSize: '0.8rem', marginBottom: '16px' }}>Top source markets</p>
          <div className="space-y-3">
            {guestNationality.map((item, i) => {
              const total = guestNationality.reduce((s, g) => s + g.count, 0);
              const pct = Math.round((item.count / total) * 100);
              const colors = ['#c4943d', '#6a9954', '#5a8faa', '#9a6aaa', '#9a9278', '#4a6a3a'];
              return (
                <div key={item.country}>
                  <div className="flex items-center justify-between mb-1">
                    <span style={{ color: '#e8dfc8', fontSize: '0.88rem' }}>{item.country}</span>
                    <span style={{ fontFamily: "'Cinzel', serif", color: colors[i], fontSize: '0.78rem' }}>{item.count.toLocaleString()} · {pct}%</span>
                  </div>
                  <div className="h-1.5 rounded-full overflow-hidden" style={{ backgroundColor: '#222a1e' }}>
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${pct}%` }}
                      transition={{ delay: i * 0.1, duration: 0.6 }}
                      className="h-full rounded-full"
                      style={{ backgroundColor: colors[i] }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Monthly Summary Table */}
      <div className="rounded-2xl overflow-hidden" style={{ backgroundColor: '#1a2016', border: '1px solid #2a3526' }}>
        <div className="px-5 py-4" style={{ borderBottom: '1px solid #2a3526' }}>
          <h3 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '0.85rem', letterSpacing: '0.08em' }}>Monthly Summary Report</h3>
          <p style={{ color: '#9a9278', fontSize: '0.8rem' }}>2026 performance overview</p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr style={{ borderBottom: '1px solid #2a3526', backgroundColor: '#141a11' }}>
                {['Month', 'Reservations', 'Check-Ins', 'Check-Outs', 'Revenue', 'Occupancy', 'Avg Stay'].map(h => (
                  <th key={h} className="px-4 py-3 text-left" style={{ fontFamily: "'Cinzel', serif", fontSize: '0.6rem', letterSpacing: '0.12em', color: '#9a9278' }}>
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {monthlyReservationTable.map((row, i) => (
                <motion.tr
                  key={row.month}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: i * 0.08 }}
                  style={{ borderBottom: '1px solid #1e2519' }}
                  onMouseEnter={e => (e.currentTarget.style.backgroundColor = '#222a1e')}
                  onMouseLeave={e => (e.currentTarget.style.backgroundColor = 'transparent')}
                >
                  <td className="px-4 py-3.5" style={{ fontFamily: "'Cinzel', serif", color: '#c4943d', fontSize: '0.82rem' }}>{row.month}</td>
                  <td className="px-4 py-3.5" style={{ color: '#e8dfc8', fontSize: '0.9rem' }}>{row.reservations}</td>
                  <td className="px-4 py-3.5" style={{ color: '#6a9954', fontSize: '0.9rem' }}>{row.checkIns}</td>
                  <td className="px-4 py-3.5" style={{ color: '#5a8faa', fontSize: '0.9rem' }}>{row.checkOuts || '—'}</td>
                  <td className="px-4 py-3.5" style={{ color: '#c4943d', fontSize: '0.9rem', fontFamily: "'Cinzel', serif" }}>{row.revenue}</td>
                  <td className="px-4 py-3.5">
                    <div className="flex items-center gap-2">
                      <div className="flex-1 h-1.5 rounded-full" style={{ backgroundColor: '#222a1e', maxWidth: '60px' }}>
                        <div className="h-full rounded-full" style={{ width: row.occupancy, backgroundColor: '#c4943d' }} />
                      </div>
                      <span style={{ color: '#e8dfc8', fontSize: '0.82rem' }}>{row.occupancy}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3.5" style={{ color: '#9a9278', fontSize: '0.88rem' }}>{row.avgStay}</td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
