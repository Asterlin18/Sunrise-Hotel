import { useState } from 'react';
import { useNavigate } from 'react-router';
import { motion } from 'motion/react';
import { Sun, Lock, User, Eye, EyeOff, ArrowLeft, Briefcase, ShieldCheck } from 'lucide-react';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

const BG_IMG = 'https://images.unsplash.com/photo-1654661201774-c501d3f9d8bc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxUYWdheXRheSUyMFBoaWxpcHBpbmVzJTIwdm9sY2FuaWMlMjBsYWtlJTIwc2NlbmljJTIwYWVyaWFsJTIwdmlld3xlbnwxfHx8fDE3NzU2Njc3MTB8MA&ixlib=rb-4.1.0&q=80&w=1080';

type Role = 'admin' | 'frontdesk';

export function LoginPage() {
  const navigate = useNavigate();
  const [role, setRole] = useState<Role>('admin');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) {
      setError('Please fill in all fields.');
      return;
    }
    setError('');
    setLoading(true);
    await new Promise(r => setTimeout(r, 1200));
    setLoading(false);
    navigate(role === 'admin' ? '/admin' : '/frontdesk');
  };

  return (
    <div
      className="min-h-screen flex"
      style={{ fontFamily: "'EB Garamond', serif", backgroundColor: '#0f1510' }}
    >
      {/* Left — Background image panel */}
      <div className="hidden lg:flex flex-1 relative overflow-hidden">
        <ImageWithFallback
          src={BG_IMG}
          alt="Tagaytay scenic view"
          className="w-full h-full object-cover"
          style={{ filter: 'brightness(0.28) saturate(0.6)' }}
        />
        <div className="absolute inset-0" style={{ background: 'linear-gradient(to right, rgba(15,21,16,0.3) 0%, rgba(15,21,16,0.9) 100%)' }} />
        <div className="absolute inset-0 flex flex-col justify-between p-12">
          <button
            onClick={() => navigate('/')}
            className="flex items-center gap-2 self-start transition-colors"
            style={{ color: '#9a9278' }}
            onMouseEnter={e => (e.currentTarget.style.color = '#c4943d')}
            onMouseLeave={e => (e.currentTarget.style.color = '#9a9278')}
          >
            <ArrowLeft size={16} />
            <span style={{ fontFamily: "'Cinzel', serif", fontSize: '0.72rem', letterSpacing: '0.1em' }}>BACK TO HOTEL</span>
          </button>

          <div>
            <div style={{ fontFamily: "'Noto Serif JP', serif", color: '#4a6a3a', fontSize: '0.75rem', letterSpacing: '0.2em', marginBottom: '1rem' }}>
              旭の宿 管理システム
            </div>
            <h2 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '2.5rem', fontWeight: 600, lineHeight: 1.3, marginBottom: '1rem', letterSpacing: '0.03em' }}>
              Operational<br />
              <span style={{ color: '#c4943d' }}>Nexus</span>
            </h2>
            <p style={{ color: '#9a9278', lineHeight: 1.9, maxWidth: '380px' }}>
              Sunrise Haven Hotel's unified management system — designed for precision, efficiency, and calm control within a high-stakes environment.
            </p>
            <div className="flex items-center gap-3 mt-8">
              <div className="h-px w-12" style={{ backgroundColor: '#344a2a' }} />
              <span style={{ color: '#4a6a3a', fontSize: '0.7rem', fontFamily: "'Cinzel', serif", letterSpacing: '0.15em' }}>AUTHORIZED PERSONNEL ONLY</span>
            </div>
          </div>

          <div style={{ color: '#4a6a3a', fontSize: '0.7rem', fontFamily: "'Cinzel', serif", letterSpacing: '0.12em' }}>
            © 2026 SUNRISE HAVEN HOTEL · TAGAYTAY CITY
          </div>
        </div>

        {/* Vertical lines */}
        <div className="absolute left-16 top-0 bottom-0 w-px opacity-10" style={{ backgroundColor: '#c4943d' }} />
      </div>

      {/* Right — Login form */}
      <div
        className="flex-1 flex items-center justify-center p-8 lg:max-w-lg"
        style={{ backgroundColor: '#0f1510' }}
      >
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-md"
        >
          {/* Mobile back button */}
          <button
            onClick={() => navigate('/')}
            className="flex items-center gap-2 mb-8 lg:hidden transition-colors"
            style={{ color: '#9a9278' }}
          >
            <ArrowLeft size={16} />
            <span style={{ fontFamily: "'Cinzel', serif", fontSize: '0.72rem', letterSpacing: '0.1em' }}>BACK TO HOTEL</span>
          </button>

          {/* Logo */}
          <div className="flex items-center gap-4 mb-8">
            <div
              className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
              style={{
                background: 'linear-gradient(135deg, #c4943d, #e0b85a)',
                boxShadow: '0 0 20px rgba(196,148,61,0.4)',
              }}
            >
              <Sun size={24} style={{ color: '#141a11' }} />
            </div>
            <div>
              <div style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '1.1rem', fontWeight: 700, letterSpacing: '0.08em' }}>
                SUNRISE HAVEN
              </div>
              <div style={{ fontFamily: "'Noto Serif JP', serif", color: '#9a9278', fontSize: '0.62rem', letterSpacing: '0.15em' }}>
                Hotel Management System
              </div>
            </div>
          </div>

          {/* Case File Panel */}
          <div
            className="rounded-2xl p-8"
            style={{
              backgroundColor: '#1a2016',
              border: '1px solid #2a3526',
              boxShadow: '0 24px 60px rgba(0,0,0,0.5)',
              position: 'relative',
              overflow: 'hidden',
            }}
          >
            {/* Top ornamental border */}
            <div className="absolute top-0 left-8 right-8 h-px" style={{ background: 'linear-gradient(to right, transparent, #c4943d, transparent)' }} />

            <div className="mb-6">
              <h1 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '1.4rem', fontWeight: 600, letterSpacing: '0.05em', marginBottom: '0.4rem' }}>
                Access Portal
              </h1>
              <p style={{ color: '#9a9278', fontSize: '0.9rem' }}>Sign in to your account to continue</p>
            </div>

            {/* Role Selector */}
            <div className="mb-6">
              <label style={{ fontFamily: "'Cinzel', serif", color: '#9a9278', fontSize: '0.65rem', letterSpacing: '0.15em', display: 'block', marginBottom: '0.5rem' }}>
                ACCESS ROLE
              </label>
              <div className="grid grid-cols-2 gap-3">
                {(['admin', 'frontdesk'] as Role[]).map(r => (
                  <motion.button
                    key={r}
                    whileTap={{ scale: 0.97 }}
                    onClick={() => setRole(r)}
                    className="flex items-center gap-2.5 px-4 py-3 rounded-xl transition-all"
                    style={{
                      backgroundColor: role === r ? 'rgba(196,148,61,0.15)' : '#222a1e',
                      border: role === r ? '1px solid #c4943d' : '1px solid #2a3526',
                      color: role === r ? '#c4943d' : '#9a9278',
                    }}
                  >
                    {r === 'admin' ? <ShieldCheck size={16} /> : <Briefcase size={16} />}
                    <span style={{ fontFamily: "'Cinzel', serif", fontSize: '0.72rem', letterSpacing: '0.08em' }}>
                      {r === 'admin' ? 'Administrator' : 'Front Desk'}
                    </span>
                  </motion.button>
                ))}
              </div>
            </div>

            <form onSubmit={handleLogin} className="space-y-5">
              {/* Username */}
              <div>
                <label style={{ fontFamily: "'Cinzel', serif", color: '#9a9278', fontSize: '0.65rem', letterSpacing: '0.15em', display: 'block', marginBottom: '0.5rem' }}>
                  USERNAME
                </label>
                <div className="relative">
                  <User size={15} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: '#4a6a3a' }} />
                  <input
                    type="text"
                    value={username}
                    onChange={e => setUsername(e.target.value)}
                    placeholder="Enter your username"
                    className="w-full pl-9 pr-4 py-3 rounded-xl transition-all outline-none"
                    style={{
                      backgroundColor: '#222a1e',
                      border: '1px solid #2a3526',
                      color: '#e8dfc8',
                      fontSize: '0.95rem',
                      fontFamily: "'EB Garamond', serif",
                    }}
                    onFocus={e => (e.target.style.borderColor = '#c4943d')}
                    onBlur={e => (e.target.style.borderColor = '#2a3526')}
                  />
                </div>
              </div>

              {/* Password */}
              <div>
                <label style={{ fontFamily: "'Cinzel', serif", color: '#9a9278', fontSize: '0.65rem', letterSpacing: '0.15em', display: 'block', marginBottom: '0.5rem' }}>
                  PASSWORD
                </label>
                <div className="relative">
                  <Lock size={15} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: '#4a6a3a' }} />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    placeholder="Enter your password"
                    className="w-full pl-9 pr-10 py-3 rounded-xl transition-all outline-none"
                    style={{
                      backgroundColor: '#222a1e',
                      border: '1px solid #2a3526',
                      color: '#e8dfc8',
                      fontSize: '0.95rem',
                      fontFamily: "'EB Garamond', serif",
                    }}
                    onFocus={e => (e.target.style.borderColor = '#c4943d')}
                    onBlur={e => (e.target.style.borderColor = '#2a3526')}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2"
                    style={{ color: '#4a6a3a' }}
                  >
                    {showPassword ? <EyeOff size={15} /> : <Eye size={15} />}
                  </button>
                </div>
              </div>

              {/* Error */}
              {error && (
                <motion.div
                  initial={{ opacity: 0, y: -8 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="px-4 py-2.5 rounded-lg"
                  style={{ backgroundColor: 'rgba(139,53,53,0.2)', border: '1px solid rgba(139,53,53,0.4)', color: '#c87a7a', fontSize: '0.88rem' }}
                >
                  {error}
                </motion.div>
              )}

              {/* Submit */}
              <motion.button
                type="submit"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.97 }}
                disabled={loading}
                className="w-full py-3.5 rounded-xl flex items-center justify-center gap-2"
                style={{
                  background: loading ? '#2a3526' : 'linear-gradient(135deg, #c4943d, #a87830)',
                  color: loading ? '#9a9278' : '#141a11',
                  fontFamily: "'Cinzel', serif",
                  fontWeight: 700,
                  fontSize: '0.82rem',
                  letterSpacing: '0.12em',
                  boxShadow: loading ? 'none' : '0 4px 20px rgba(196,148,61,0.35)',
                  transition: 'all 0.3s',
                }}
              >
                {loading ? (
                  <>
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ repeat: Infinity, duration: 1, ease: 'linear' }}
                      className="w-4 h-4 rounded-full border-2"
                      style={{ borderColor: '#9a9278', borderTopColor: 'transparent' }}
                    />
                    AUTHENTICATING...
                  </>
                ) : (
                  'ENTER SYSTEM'
                )}
              </motion.button>
            </form>

            {/* Bottom ornamental border */}
            <div className="absolute bottom-0 left-8 right-8 h-px" style={{ background: 'linear-gradient(to right, transparent, #344a2a, transparent)' }} />
          </div>

          <p style={{ color: '#4a6a3a', fontSize: '0.72rem', fontFamily: "'Cinzel', serif", textAlign: 'center', marginTop: '1.5rem', letterSpacing: '0.1em' }}>
            SUNRISE HAVEN HOTEL · MANAGEMENT SYSTEM v2.4
          </p>
        </motion.div>
      </div>
    </div>
  );
}
