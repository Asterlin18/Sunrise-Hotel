import { useState } from 'react';
import type { ComponentType } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Search, Filter, Plus, Eye, Pencil, Trash2, ChevronDown,
  ChevronUp, X, Calendar, BedDouble, User, Phone, Mail,
  CheckCircle2, Clock, XCircle, AlertCircle, ChevronLeft, ChevronRight
} from 'lucide-react';

const RESERVATIONS = [
  { id: 'RES-2026-001', guest: 'Maria Santos', phone: '+63 912 345-6789', email: 'maria@email.com', room: '305', type: 'Premium', checkIn: '2026-04-10', checkOut: '2026-04-13', nights: 3, amount: '₱15,600', status: 'confirmed', pax: 2 },
  { id: 'RES-2026-002', guest: 'Juan dela Cruz', phone: '+63 917 234-5678', email: 'juan@email.com', room: '212', type: 'Standard', checkIn: '2026-04-11', checkOut: '2026-04-12', nights: 1, amount: '₱3,500', status: 'checked-in', pax: 1 },
  { id: 'RES-2026-003', guest: 'Ana Reyes', phone: '+63 920 876-5432', email: 'ana@email.com', room: '418', type: 'Suite', checkIn: '2026-04-12', checkOut: '2026-04-14', nights: 2, amount: '₱17,000', status: 'pending', pax: 2 },
  { id: 'RES-2026-004', guest: 'Carlos Mañalac', phone: '+63 915 543-2109', email: 'carlos@email.com', room: '110', type: 'Standard', checkIn: '2026-04-08', checkOut: '2026-04-10', nights: 2, amount: '₱7,000', status: 'checked-out', pax: 2 },
  { id: 'RES-2026-005', guest: 'Lucia Fernandez', phone: '+63 918 765-4321', email: 'lucia@email.com', room: '307', type: 'Premium', checkIn: '2026-04-15', checkOut: '2026-04-18', nights: 3, amount: '₱15,600', status: 'confirmed', pax: 3 },
  { id: 'RES-2026-006', guest: 'Roberto Villanueva', phone: '+63 921 678-9012', email: 'roberto@email.com', room: '207', type: 'Standard', checkIn: '2026-04-09', checkOut: '2026-04-11', nights: 2, amount: '₱7,000', status: 'cancelled', pax: 1 },
  { id: 'RES-2026-007', guest: 'Sofia Garcia', phone: '+63 913 234-5670', email: 'sofia@email.com', room: '502', type: 'Suite', checkIn: '2026-04-20', checkOut: '2026-04-25', nights: 5, amount: '₱42,500', status: 'confirmed', pax: 4 },
  { id: 'RES-2026-008', guest: 'Emmanuel Bautista', phone: '+63 916 345-6781', email: 'emman@email.com', room: '314', type: 'Premium', checkIn: '2026-04-13', checkOut: '2026-04-15', nights: 2, amount: '₱10,400', status: 'pending', pax: 2 },
];

const statusConfig: Record<string, { label: string; color: string; bg: string; icon: ComponentType<any> }> = {
  confirmed: { label: 'Confirmed', color: '#6a9954', bg: 'rgba(106,153,84,0.12)', icon: CheckCircle2 },
  'checked-in': { label: 'Checked-In', color: '#5a8faa', bg: 'rgba(58,95,122,0.12)', icon: CheckCircle2 },
  pending: { label: 'Pending', color: '#c4943d', bg: 'rgba(196,148,61,0.12)', icon: Clock },
  'checked-out': { label: 'Checked-Out', color: '#9a9278', bg: 'rgba(154,146,120,0.12)', icon: CheckCircle2 },
  cancelled: { label: 'Cancelled', color: '#c87a7a', bg: 'rgba(139,53,53,0.12)', icon: XCircle },
};

type SortKey = 'id' | 'guest' | 'checkIn' | 'checkOut' | 'amount' | 'status';

export function ReservationsPage() {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [sortKey, setSortKey] = useState<SortKey>('checkIn');
  const [sortAsc, setSortAsc] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [viewItem, setViewItem] = useState<typeof RESERVATIONS[0] | null>(null);
  const [page, setPage] = useState(1);
  const PER_PAGE = 6;

  const filtered = RESERVATIONS.filter(r => {
    const matchSearch = !search || r.guest.toLowerCase().includes(search.toLowerCase()) || r.id.includes(search) || r.phone.includes(search);
    const matchStatus = statusFilter === 'all' || r.status === statusFilter;
    const matchType = typeFilter === 'all' || r.type === typeFilter;
    return matchSearch && matchStatus && matchType;
  }).sort((a, b) => {
    const av = a[sortKey as keyof typeof a] as string;
    const bv = b[sortKey as keyof typeof b] as string;
    return sortAsc ? av.localeCompare(bv) : bv.localeCompare(av);
  });

  const totalPages = Math.ceil(filtered.length / PER_PAGE);
  const paginated = filtered.slice((page - 1) * PER_PAGE, page * PER_PAGE);

  const handleSort = (key: SortKey) => {
    if (sortKey === key) setSortAsc(!sortAsc);
    else { setSortKey(key); setSortAsc(true); }
  };

  const SortIcon = ({ col }: { col: SortKey }) =>
    sortKey === col
      ? sortAsc ? <ChevronUp size={12} /> : <ChevronDown size={12} />
      : <ChevronDown size={12} style={{ opacity: 0.3 }} />;

  return (
    <div className="p-6 space-y-5" style={{ fontFamily: "'EB Garamond', serif" }}>
      {/* Header */}
      <div className="flex items-start justify-between flex-wrap gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <div className="h-px w-6" style={{ backgroundColor: '#c4943d' }} />
            <span style={{ fontFamily: "'Cinzel', serif", color: '#c4943d', fontSize: '0.65rem', letterSpacing: '0.2em' }}>RESERVATION LEDGER</span>
          </div>
          <h1 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '1.6rem', fontWeight: 600, letterSpacing: '0.04em' }}>
            Reservations
          </h1>
          <p style={{ color: '#9a9278', fontSize: '0.9rem' }}>{filtered.length} records found</p>
        </div>
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.97 }}
          onClick={() => setShowModal(true)}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl"
          style={{ background: 'linear-gradient(135deg, #c4943d, #a87830)', color: '#141a11', fontFamily: "'Cinzel', serif", fontWeight: 700, fontSize: '0.72rem', letterSpacing: '0.1em' }}
        >
          <Plus size={15} /> New Reservation
        </motion.button>
      </div>

      {/* Filters */}
      <div className="rounded-2xl p-4" style={{ backgroundColor: '#1a2016', border: '1px solid #2a3526' }}>
        <div className="flex flex-wrap gap-3">
          {/* Search */}
          <div className="relative flex-1 min-w-56">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: '#4a6a3a' }} />
            <input
              value={search}
              onChange={e => { setSearch(e.target.value); setPage(1); }}
              placeholder="Search by guest, ID, phone..."
              className="w-full pl-9 pr-4 py-2.5 rounded-xl outline-none"
              style={{ backgroundColor: '#222a1e', border: '1px solid #2a3526', color: '#e8dfc8', fontSize: '0.9rem', fontFamily: "'EB Garamond', serif" }}
              onFocus={e => (e.target.style.borderColor = '#c4943d')}
              onBlur={e => (e.target.style.borderColor = '#2a3526')}
            />
          </div>

          {/* Status filter */}
          <div className="flex gap-1.5 flex-wrap">
            {['all', 'confirmed', 'checked-in', 'pending', 'checked-out', 'cancelled'].map(s => (
              <button
                key={s}
                onClick={() => { setStatusFilter(s); setPage(1); }}
                className="px-3 py-2 rounded-xl transition-all"
                style={{
                  fontFamily: "'Cinzel', serif", fontSize: '0.62rem', letterSpacing: '0.08em',
                  backgroundColor: statusFilter === s ? 'rgba(196,148,61,0.15)' : '#222a1e',
                  color: statusFilter === s ? '#c4943d' : '#9a9278',
                  border: statusFilter === s ? '1px solid rgba(196,148,61,0.3)' : '1px solid #2a3526',
                }}
              >
                {s === 'all' ? 'All' : statusConfig[s]?.label}
              </button>
            ))}
          </div>

          {/* Type filter */}
          <select
            value={typeFilter}
            onChange={e => { setTypeFilter(e.target.value); setPage(1); }}
            className="px-4 py-2.5 rounded-xl outline-none"
            style={{ backgroundColor: '#222a1e', border: '1px solid #2a3526', color: '#9a9278', fontFamily: "'Cinzel', serif", fontSize: '0.72rem', letterSpacing: '0.06em' }}
          >
            <option value="all">All Types</option>
            <option value="Standard">Standard</option>
            <option value="Premium">Premium</option>
            <option value="Suite">Suite</option>
          </select>
        </div>
      </div>

      {/* Table */}
      <div className="rounded-2xl overflow-hidden" style={{ backgroundColor: '#1a2016', border: '1px solid #2a3526' }}>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr style={{ borderBottom: '1px solid #2a3526', backgroundColor: '#141a11' }}>
                {[
                  { label: 'Reservation ID', key: 'id' as SortKey },
                  { label: 'Guest', key: 'guest' as SortKey },
                  { label: 'Room', key: null },
                  { label: 'Check-In', key: 'checkIn' as SortKey },
                  { label: 'Check-Out', key: 'checkOut' as SortKey },
                  { label: 'Amount', key: 'amount' as SortKey },
                  { label: 'Status', key: 'status' as SortKey },
                  { label: 'Actions', key: null },
                ].map(col => (
                  <th
                    key={col.label}
                    onClick={() => col.key && handleSort(col.key)}
                    className="px-4 py-3 text-left"
                    style={{
                      fontFamily: "'Cinzel', serif", fontSize: '0.6rem', letterSpacing: '0.12em',
                      color: '#9a9278', whiteSpace: 'nowrap',
                      cursor: col.key ? 'pointer' : 'default',
                    }}
                  >
                    <div className="flex items-center gap-1">
                      {col.label}
                      {col.key && <SortIcon col={col.key} />}
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {paginated.map((res, idx) => {
                const cfg = statusConfig[res.status];
                const StatusIcon = cfg.icon;
                return (
                  <motion.tr
                    key={res.id}
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.04 }}
                    style={{ borderBottom: '1px solid #1e2519' }}
                    onMouseEnter={e => (e.currentTarget.style.backgroundColor = '#222a1e')}
                    onMouseLeave={e => (e.currentTarget.style.backgroundColor = 'transparent')}
                  >
                    <td className="px-4 py-3.5">
                      <span style={{ fontFamily: "'Cinzel', serif", color: '#c4943d', fontSize: '0.78rem', letterSpacing: '0.06em' }}>{res.id}</span>
                    </td>
                    <td className="px-4 py-3.5">
                      <div style={{ color: '#e8dfc8', fontSize: '0.92rem' }}>{res.guest}</div>
                      <div style={{ color: '#9a9278', fontSize: '0.72rem' }}>{res.phone}</div>
                    </td>
                    <td className="px-4 py-3.5">
                      <div style={{ color: '#e8dfc8', fontSize: '0.88rem' }}>Room {res.room}</div>
                      <div style={{ color: '#9a9278', fontSize: '0.72rem', fontFamily: "'Cinzel', serif", letterSpacing: '0.05em' }}>{res.type}</div>
                    </td>
                    <td className="px-4 py-3.5" style={{ color: '#e8dfc8', fontSize: '0.88rem', whiteSpace: 'nowrap' }}>{res.checkIn}</td>
                    <td className="px-4 py-3.5" style={{ color: '#e8dfc8', fontSize: '0.88rem', whiteSpace: 'nowrap' }}>{res.checkOut}</td>
                    <td className="px-4 py-3.5">
                      <span style={{ color: '#c4943d', fontSize: '0.92rem', fontFamily: "'Cinzel', serif" }}>{res.amount}</span>
                    </td>
                    <td className="px-4 py-3.5">
                      <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg w-fit" style={{ backgroundColor: cfg.bg }}>
                        <StatusIcon size={11} style={{ color: cfg.color }} />
                        <span style={{ fontFamily: "'Cinzel', serif", fontSize: '0.62rem', color: cfg.color, letterSpacing: '0.08em' }}>
                          {cfg.label}
                        </span>
                      </div>
                    </td>
                    <td className="px-4 py-3.5">
                      <div className="flex items-center gap-1.5">
                        <motion.button
                          whileHover={{ scale: 1.1 }}
                          onClick={() => setViewItem(res)}
                          className="p-2 rounded-lg"
                          style={{ backgroundColor: 'rgba(58,95,122,0.15)', color: '#5a8faa' }}
                        >
                          <Eye size={13} />
                        </motion.button>
                        <motion.button
                          whileHover={{ scale: 1.1 }}
                          className="p-2 rounded-lg"
                          style={{ backgroundColor: 'rgba(196,148,61,0.12)', color: '#c4943d' }}
                        >
                          <Pencil size={13} />
                        </motion.button>
                        <motion.button
                          whileHover={{ scale: 1.1 }}
                          className="p-2 rounded-lg"
                          style={{ backgroundColor: 'rgba(139,53,53,0.12)', color: '#c87a7a' }}
                        >
                          <Trash2 size={13} />
                        </motion.button>
                      </div>
                    </td>
                  </motion.tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between px-4 py-3" style={{ borderTop: '1px solid #1e2519' }}>
          <span style={{ color: '#9a9278', fontSize: '0.8rem' }}>
            Showing {((page - 1) * PER_PAGE) + 1}–{Math.min(page * PER_PAGE, filtered.length)} of {filtered.length}
          </span>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setPage(Math.max(1, page - 1))}
              disabled={page === 1}
              className="p-1.5 rounded-lg"
              style={{ color: page === 1 ? '#2a3526' : '#9a9278', backgroundColor: '#222a1e' }}
            >
              <ChevronLeft size={15} />
            </button>
            {Array.from({ length: totalPages }, (_, i) => (
              <button
                key={i + 1}
                onClick={() => setPage(i + 1)}
                className="w-8 h-8 rounded-lg"
                style={{
                  fontFamily: "'Cinzel', serif", fontSize: '0.72rem',
                  backgroundColor: page === i + 1 ? 'rgba(196,148,61,0.15)' : '#222a1e',
                  color: page === i + 1 ? '#c4943d' : '#9a9278',
                  border: page === i + 1 ? '1px solid rgba(196,148,61,0.3)' : '1px solid transparent',
                }}
              >
                {i + 1}
              </button>
            ))}
            <button
              onClick={() => setPage(Math.min(totalPages, page + 1))}
              disabled={page === totalPages}
              className="p-1.5 rounded-lg"
              style={{ color: page === totalPages ? '#2a3526' : '#9a9278', backgroundColor: '#222a1e' }}
            >
              <ChevronRight size={15} />
            </button>
          </div>
        </div>
      </div>

      {/* View Modal */}
      <AnimatePresence>
        {viewItem && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
            style={{ backgroundColor: 'rgba(0,0,0,0.7)' }}
            onClick={() => setViewItem(null)}
          >
            <motion.div
              initial={{ scale: 0.95, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 20 }}
              onClick={e => e.stopPropagation()}
              className="rounded-2xl p-6 w-full max-w-lg relative overflow-hidden"
              style={{ backgroundColor: '#1a2016', border: '1px solid #344a2a', boxShadow: '0 24px 60px rgba(0,0,0,0.6)' }}
            >
              <div className="absolute top-0 left-8 right-8 h-px" style={{ background: 'linear-gradient(to right, transparent, #c4943d, transparent)' }} />
              <div className="flex items-start justify-between mb-5">
                <div>
                  <span style={{ fontFamily: "'Cinzel', serif", color: '#c4943d', fontSize: '0.65rem', letterSpacing: '0.2em' }}>RESERVATION FILE</span>
                  <h2 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '1.2rem', fontWeight: 600, letterSpacing: '0.04em' }}>
                    {viewItem.id}
                  </h2>
                </div>
                <button onClick={() => setViewItem(null)} style={{ color: '#9a9278' }}><X size={18} /></button>
              </div>

              <div className="grid grid-cols-2 gap-4">
                {[
                  { icon: User, label: 'Guest Name', value: viewItem.guest },
                  { icon: Phone, label: 'Phone', value: viewItem.phone },
                  { icon: Mail, label: 'Email', value: viewItem.email },
                  { icon: BedDouble, label: 'Room', value: `Room ${viewItem.room} · ${viewItem.type}` },
                  { icon: Calendar, label: 'Check-In', value: viewItem.checkIn },
                  { icon: Calendar, label: 'Check-Out', value: viewItem.checkOut },
                ].map(field => {
                  const Icon = field.icon;
                  return (
                    <div key={field.label} className="flex items-start gap-3">
                      <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0" style={{ backgroundColor: 'rgba(196,148,61,0.1)' }}>
                        <Icon size={14} style={{ color: '#c4943d' }} />
                      </div>
                      <div>
                        <div style={{ fontFamily: "'Cinzel', serif", color: '#9a9278', fontSize: '0.62rem', letterSpacing: '0.1em' }}>{field.label}</div>
                        <div style={{ color: '#e8dfc8', fontSize: '0.9rem' }}>{field.value}</div>
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="mt-5 pt-4 flex items-center justify-between" style={{ borderTop: '1px solid #2a3526' }}>
                <div>
                  <div style={{ fontFamily: "'Cinzel', serif", color: '#9a9278', fontSize: '0.62rem', letterSpacing: '0.1em' }}>TOTAL AMOUNT</div>
                  <div style={{ fontFamily: "'Cinzel', serif", color: '#c4943d', fontSize: '1.4rem', fontWeight: 700 }}>{viewItem.amount}</div>
                </div>
                <div
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg"
                  style={{ backgroundColor: statusConfig[viewItem.status].bg }}
                >
                  <span style={{ fontFamily: "'Cinzel', serif", fontSize: '0.72rem', color: statusConfig[viewItem.status].color }}>
                    {statusConfig[viewItem.status].label}
                  </span>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* New Reservation Modal */}
      <AnimatePresence>
        {showModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
            style={{ backgroundColor: 'rgba(0,0,0,0.7)' }}
            onClick={() => setShowModal(false)}
          >
            <motion.div
              initial={{ scale: 0.95, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 20 }}
              onClick={e => e.stopPropagation()}
              className="rounded-2xl p-6 w-full max-w-2xl relative overflow-hidden max-h-[90vh] overflow-y-auto"
              style={{ backgroundColor: '#1a2016', border: '1px solid #344a2a', boxShadow: '0 24px 60px rgba(0,0,0,0.6)' }}
            >
              <div className="absolute top-0 left-8 right-8 h-px" style={{ background: 'linear-gradient(to right, transparent, #c4943d, transparent)' }} />
              <div className="flex items-center justify-between mb-6">
                <div>
                  <span style={{ fontFamily: "'Cinzel', serif", color: '#c4943d', fontSize: '0.65rem', letterSpacing: '0.2em' }}>BOOKING REQUEST</span>
                  <h2 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '1.3rem', fontWeight: 600 }}>New Reservation</h2>
                </div>
                <button onClick={() => setShowModal(false)} style={{ color: '#9a9278' }}><X size={18} /></button>
              </div>

              <form className="space-y-5" onSubmit={e => { e.preventDefault(); setShowModal(false); }}>
                {/* Guest Info */}
                <div>
                  <div style={{ fontFamily: "'Cinzel', serif", color: '#c4943d', fontSize: '0.65rem', letterSpacing: '0.15em', marginBottom: '0.75rem' }}>
                    GUEST INFORMATION
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    {[
                      { label: 'FULL NAME', placeholder: 'Guest full name', icon: User },
                      { label: 'PHONE NUMBER', placeholder: '+63 9XX XXX XXXX', icon: Phone },
                      { label: 'EMAIL ADDRESS', placeholder: 'guest@email.com', icon: Mail },
                      { label: 'NUMBER OF PAX', placeholder: '1', icon: User },
                    ].map(field => {
                      const Icon = field.icon;
                      return (
                        <div key={field.label}>
                          <label style={{ fontFamily: "'Cinzel', serif", color: '#9a9278', fontSize: '0.6rem', letterSpacing: '0.15em', display: 'block', marginBottom: '0.4rem' }}>
                            {field.label}
                          </label>
                          <div className="relative">
                            <Icon size={13} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: '#4a6a3a' }} />
                            <input
                              placeholder={field.placeholder}
                              className="w-full pl-8 pr-3 py-2.5 rounded-xl outline-none"
                              style={{ backgroundColor: '#222a1e', border: '1px solid #2a3526', color: '#e8dfc8', fontSize: '0.9rem', fontFamily: "'EB Garamond', serif" }}
                              onFocus={e => (e.target.style.borderColor = '#c4943d')}
                              onBlur={e => (e.target.style.borderColor = '#2a3526')}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Room Selection */}
                <div>
                  <div style={{ fontFamily: "'Cinzel', serif", color: '#c4943d', fontSize: '0.65rem', letterSpacing: '0.15em', marginBottom: '0.75rem' }}>
                    ROOM SELECTION
                  </div>
                  <div className="grid grid-cols-3 gap-3">
                    {['Standard', 'Premium', 'Suite'].map(type => (
                      <div
                        key={type}
                        className="p-3 rounded-xl cursor-pointer transition-all"
                        style={{ backgroundColor: '#222a1e', border: '1px solid #2a3526' }}
                        onMouseEnter={e => (e.currentTarget.style.borderColor = '#c4943d')}
                        onMouseLeave={e => (e.currentTarget.style.borderColor = '#2a3526')}
                      >
                        <BedDouble size={16} style={{ color: '#c4943d', marginBottom: '0.4rem' }} />
                        <div style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '0.78rem' }}>{type}</div>
                        <div style={{ color: '#9a9278', fontSize: '0.72rem' }}>
                          {type === 'Standard' ? '₱3,500/night' : type === 'Premium' ? '₱5,200/night' : '₱8,500/night'}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Booking Dates */}
                <div>
                  <div style={{ fontFamily: "'Cinzel', serif", color: '#c4943d', fontSize: '0.65rem', letterSpacing: '0.15em', marginBottom: '0.75rem' }}>
                    BOOKING DATES
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    {[
                      { label: 'CHECK-IN DATE', placeholder: 'YYYY-MM-DD' },
                      { label: 'CHECK-OUT DATE', placeholder: 'YYYY-MM-DD' },
                    ].map(field => (
                      <div key={field.label}>
                        <label style={{ fontFamily: "'Cinzel', serif", color: '#9a9278', fontSize: '0.6rem', letterSpacing: '0.15em', display: 'block', marginBottom: '0.4rem' }}>
                          {field.label}
                        </label>
                        <div className="relative">
                          <Calendar size={13} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: '#4a6a3a' }} />
                          <input
                            type="date"
                            className="w-full pl-8 pr-3 py-2.5 rounded-xl outline-none"
                            style={{ backgroundColor: '#222a1e', border: '1px solid #2a3526', color: '#e8dfc8', fontSize: '0.9rem', fontFamily: "'EB Garamond', serif", colorScheme: 'dark' }}
                            onFocus={e => (e.target.style.borderColor = '#c4943d')}
                            onBlur={e => (e.target.style.borderColor = '#2a3526')}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Special Requests */}
                <div>
                  <label style={{ fontFamily: "'Cinzel', serif", color: '#9a9278', fontSize: '0.6rem', letterSpacing: '0.15em', display: 'block', marginBottom: '0.4rem' }}>
                    SPECIAL REQUESTS
                  </label>
                  <textarea
                    rows={3}
                    placeholder="Any special requests or notes..."
                    className="w-full px-4 py-2.5 rounded-xl outline-none resize-none"
                    style={{ backgroundColor: '#222a1e', border: '1px solid #2a3526', color: '#e8dfc8', fontSize: '0.9rem', fontFamily: "'EB Garamond', serif" }}
                    onFocus={e => (e.target.style.borderColor = '#c4943d')}
                    onBlur={e => (e.target.style.borderColor = '#2a3526')}
                  />
                </div>

                {/* Submit */}
                <div className="flex gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowModal(false)}
                    className="flex-1 py-3 rounded-xl"
                    style={{ backgroundColor: '#222a1e', border: '1px solid #344a2a', color: '#9a9278', fontFamily: "'Cinzel', serif", fontSize: '0.72rem', letterSpacing: '0.1em' }}
                  >
                    CANCEL
                  </button>
                  <motion.button
                    type="submit"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.97 }}
                    className="flex-1 py-3 rounded-xl"
                    style={{ background: 'linear-gradient(135deg, #c4943d, #a87830)', color: '#141a11', fontFamily: "'Cinzel', serif", fontWeight: 700, fontSize: '0.72rem', letterSpacing: '0.1em' }}
                  >
                    CONFIRM RESERVATION
                  </motion.button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}