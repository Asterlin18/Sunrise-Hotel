import { useState } from 'react';
import { useNavigate } from 'react-router';
import { motion } from 'motion/react';
import {
  Menu, X, Sun, UtensilsCrossed, WashingMachine, Printer,
  CalendarCheck, Phone, Mail, MapPin, Star, ChevronRight, Waves
} from 'lucide-react';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

const HERO_IMG = 'https://images.unsplash.com/photo-1654661201774-c501d3f9d8bc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxUYWdheXRheSUyMFBoaWxpcHBpbmVzJTIwdm9sY2FuaWMlMjBsYWtlJTIwc2NlbmljJTIwYWVyaWFsJTIwdmlld3xlbnwxfHx8fDE3NzU2Njc3MTB8MA&ixlib=rb-4.1.0&q=80&w=1080';
const ABOUT_IMG = 'https://images.unsplash.com/photo-1637730827702-de34e9ae4ede?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBob3RlbCUyMGxvYmJ5JTIwaW50ZXJpb3IlMjB3YXJtJTIwbGlnaHQlMjB3b29kfGVufDF8fHx8MTc3NTY2NzcxMHww&ixlib=rb-4.1.0&q=80&w=1080';
const ROOM1_IMG = 'https://images.unsplash.com/photo-1766928210443-0be92ed5884a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3p5JTIwaG90ZWwlMjBiZWRyb29tJTIwbW9kZXJuJTIwaW50ZXJpb3IlMjBkZXNpZ258ZW58MXx8fHwxNzc1NjY3NzE5fDA&ixlib=rb-4.1.0&q=80&w=1080';
const ROOM2_IMG = 'https://images.unsplash.com/photo-1762018835071-229401da213c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmVtaXVtJTIwaG90ZWwlMjByb29tJTIwc2NlbmljJTIwbW91bnRhaW4lMjB2aWV3fGVufDF8fHx8MTc3NTY2NzcxM3ww&ixlib=rb-4.1.0&q=80&w=1080';
const ROOM3_IMG = 'https://images.unsplash.com/photo-1701422522324-69f51ab87484?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBob3RlbCUyMHN1aXRlJTIwbGl2aW5nJTIwcm9vbSUyMGZpcmVwbGFjZXxlbnwxfHx8fDE3NzU2Njc3MTR8MA&ixlib=rb-4.1.0&q=80&w=1080';
const BG_IMG = 'https://images.unsplash.com/photo-1771905261053-665863f28f57?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxQaGlsaXBwaW5lcyUyMHRyb3BpY2FsJTIwbWlzdHklMjBncmVlbiUyMG1vdW50YWlucyUyMGZvZ3xlbnwxfHx8fDE3NzU2Njc3MTl8MA&ixlib=rb-4.1.0&q=80&w=1080';

const rooms = [
  {
    name: 'Standard Room', price: '₱3,500', img: ROOM1_IMG,
    desc: 'Comfortable room with garden view, modern amenities, and cozy atmosphere.',
    features: ['Air Conditioning', 'Free WiFi', 'City View', 'Twin/Double Bed'],
  },
  {
    name: 'Premium Room', price: '₱5,200', img: ROOM2_IMG,
    desc: 'Spacious premium room with panoramic views of Taal Lake and scenic highlands.',
    features: ['Lake View Balcony', 'Premium Bedding', 'Smart TV', 'Mini Bar'],
  },
  {
    name: 'Deluxe Suite', price: '₱8,500', img: ROOM3_IMG,
    desc: 'Our finest suite featuring a private lounge area, Jacuzzi, and butler service.',
    features: ['Private Lounge', 'Jacuzzi', 'Butler Service', 'Executive Amenities'],
  },
];

const services = [
  { icon: UtensilsCrossed, label: 'Food & Beverage', desc: 'In-room dining, farm-to-table restaurant, and curated local cuisine.' },
  { icon: WashingMachine, label: 'Laundry & Housekeeping', desc: 'Express, standard, and eco-friendly cleaning services.' },
  { icon: Printer, label: 'Business Center', desc: 'Conference rooms, AV support, printing, and secretarial services.' },
  { icon: CalendarCheck, label: 'Event Planning', desc: 'Weddings, corporate events, and private celebrations with full support.' },
];

export function LandingPage() {
  const [menuOpen, setMenuOpen] = useState(false);
  const navigate = useNavigate();

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
    setMenuOpen(false);
  };

  return (
    <div style={{ fontFamily: "'EB Garamond', serif", backgroundColor: '#0f1510', color: '#e8dfc8' }}>
      {/* ── HEADER ── */}
      <header
        className="sticky top-0 z-50"
        style={{ backgroundColor: 'rgba(15, 21, 16, 0.95)', backdropFilter: 'blur(8px)', borderBottom: '1px solid #2a3526' }}
      >
        <nav className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center"
              style={{ background: 'linear-gradient(135deg, #c4943d, #e0b85a)', boxShadow: '0 0 16px rgba(196,148,61,0.45)' }}
            >
              <Sun size={20} style={{ color: '#141a11' }} />
            </div>
            <div>
              <div style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '0.9rem', fontWeight: 700, letterSpacing: '0.1em' }}>
                SUNRISE HAVEN
              </div>
              <div style={{ fontFamily: "'Noto Serif JP', serif", color: '#9a9278', fontSize: '0.6rem', letterSpacing: '0.12em' }}>
                旅館 · Tagaytay
              </div>
            </div>
          </div>

          {/* Desktop Nav */}
          <ul className="hidden md:flex items-center gap-8">
            {['about', 'rooms', 'services', 'contact'].map(s => (
              <li key={s}>
                <button
                  onClick={() => scrollTo(s)}
                  className="transition-colors"
                  style={{ fontFamily: "'Cinzel', serif", fontSize: '0.72rem', letterSpacing: '0.1em', color: '#9a9278', textTransform: 'uppercase' }}
                  onMouseEnter={e => (e.currentTarget.style.color = '#c4943d')}
                  onMouseLeave={e => (e.currentTarget.style.color = '#9a9278')}
                >
                  {s === 'about' ? 'About' : s === 'rooms' ? 'Rooms & Rates' : s === 'services' ? 'Services' : 'Contact'}
                </button>
              </li>
            ))}
          </ul>

          {/* CTA Buttons */}
          <div className="hidden md:flex items-center gap-3">
            <button
              onClick={() => navigate('/login')}
              className="px-4 py-2 rounded-lg transition-all"
              style={{ fontFamily: "'Cinzel', serif", fontSize: '0.72rem', letterSpacing: '0.08em', color: '#9a9278', border: '1px solid #344a2a' }}
              onMouseEnter={e => { e.currentTarget.style.color = '#c4943d'; e.currentTarget.style.borderColor = '#c4943d'; }}
              onMouseLeave={e => { e.currentTarget.style.color = '#9a9278'; e.currentTarget.style.borderColor = '#344a2a'; }}
            >
              Staff Login
            </button>
            <button
              onClick={() => scrollTo('rooms')}
              className="px-5 py-2 rounded-lg transition-all"
              style={{
                fontFamily: "'Cinzel', serif", fontSize: '0.72rem', letterSpacing: '0.08em',
                background: 'linear-gradient(135deg, #c4943d, #a87830)',
                color: '#141a11', fontWeight: 600,
                boxShadow: '0 0 12px rgba(196,148,61,0.3)',
              }}
              onMouseEnter={e => (e.currentTarget.style.boxShadow = '0 0 20px rgba(196,148,61,0.5)')}
              onMouseLeave={e => (e.currentTarget.style.boxShadow = '0 0 12px rgba(196,148,61,0.3)')}
            >
              Book Now
            </button>
          </div>

          {/* Mobile Menu Toggle */}
          <button
            className="md:hidden p-2 rounded"
            style={{ color: '#9a9278' }}
            onClick={() => setMenuOpen(!menuOpen)}
          >
            {menuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </nav>

        {/* Mobile Menu */}
        {menuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="md:hidden px-6 pb-4"
            style={{ borderTop: '1px solid #2a3526' }}
          >
            {['about', 'rooms', 'services', 'contact'].map(s => (
              <button
                key={s}
                onClick={() => scrollTo(s)}
                className="block w-full text-left py-3 transition-colors"
                style={{ fontFamily: "'Cinzel', serif", fontSize: '0.78rem', letterSpacing: '0.08em', color: '#9a9278', borderBottom: '1px solid #1e2519' }}
              >
                {s.charAt(0).toUpperCase() + s.slice(1)}
              </button>
            ))}
            <div className="flex gap-3 pt-3">
              <button onClick={() => navigate('/login')} className="flex-1 py-2 rounded-lg text-center" style={{ fontFamily: "'Cinzel', serif", fontSize: '0.72rem', color: '#9a9278', border: '1px solid #344a2a' }}>
                Staff Login
              </button>
              <button onClick={() => scrollTo('rooms')} className="flex-1 py-2 rounded-lg text-center" style={{ fontFamily: "'Cinzel', serif", fontSize: '0.72rem', background: 'linear-gradient(135deg, #c4943d, #a87830)', color: '#141a11', fontWeight: 600 }}>
                Book Now
              </button>
            </div>
          </motion.div>
        )}
      </header>

      {/* ── HERO ── */}
      <section
        id="hero"
        className="relative overflow-hidden"
        style={{ minHeight: '92vh', display: 'flex', alignItems: 'center' }}
      >
        {/* Background Image */}
        <div className="absolute inset-0">
          <ImageWithFallback
            src={HERO_IMG}
            alt="Tagaytay scenic view"
            className="w-full h-full object-cover"
            style={{ filter: 'brightness(0.35) saturate(0.7)' }}
          />
        </div>
        {/* Overlay gradient */}
        <div className="absolute inset-0" style={{ background: 'linear-gradient(135deg, rgba(15,21,16,0.85) 0%, rgba(15,21,16,0.3) 60%, rgba(15,21,16,0.7) 100%)' }} />
        {/* Vertical line decorations (Ghost of Tsushima) */}
        <div className="absolute left-12 top-0 bottom-0 w-px opacity-20" style={{ background: 'linear-gradient(to bottom, transparent, #c4943d, transparent)' }} />
        <div className="absolute right-12 top-0 bottom-0 w-px opacity-20" style={{ background: 'linear-gradient(to bottom, transparent, #c4943d, transparent)' }} />

        <div className="relative z-10 max-w-6xl mx-auto px-6 py-20">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
            className="max-w-3xl"
          >
            {/* Eyebrow */}
            <div className="flex items-center gap-3 mb-6">
              <div className="h-px w-12" style={{ backgroundColor: '#c4943d' }} />
              <span style={{ fontFamily: "'Cinzel', serif", color: '#c4943d', fontSize: '0.7rem', letterSpacing: '0.25em' }}>
                TAGAYTAY CITY, PHILIPPINES
              </span>
            </div>

            <h1 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: 'clamp(2rem, 5vw, 3.5rem)', fontWeight: 700, lineHeight: 1.2, marginBottom: '1.5rem', letterSpacing: '0.02em' }}>
              Discover Serenity at<br />
              <span style={{ color: '#c4943d' }}>Tagaytay's</span> Premier Escape
            </h1>

            <p style={{ color: '#b0a890', fontSize: '1.15rem', maxWidth: '520px', lineHeight: 1.8, marginBottom: '2.5rem' }}>
              Nestled amid Tagaytay's misty highlands, Sunrise Haven Hotel offers breathtaking views of Taal Volcano,
              world-class amenities, and a tranquil retreat unlike any other.
            </p>

            {/* Star Rating */}
            <div className="flex items-center gap-2 mb-8">
              {[...Array(5)].map((_, i) => (
                <Star key={i} size={16} fill="#c4943d" style={{ color: '#c4943d' }} />
              ))}
              <span style={{ color: '#9a9278', fontSize: '0.85rem', marginLeft: '8px' }}>4.9 · 2,400+ Reviews</span>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-wrap gap-4">
              <motion.button
                onClick={() => scrollTo('rooms')}
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                className="px-8 py-3.5 rounded-lg flex items-center gap-2"
                style={{
                  background: 'linear-gradient(135deg, #c4943d, #a87830)',
                  color: '#141a11', fontFamily: "'Cinzel', serif", fontWeight: 700,
                  fontSize: '0.82rem', letterSpacing: '0.1em',
                  boxShadow: '0 4px 24px rgba(196,148,61,0.4)',
                }}
              >
                Reserve Your Stay <ChevronRight size={16} />
              </motion.button>
              <motion.button
                onClick={() => scrollTo('about')}
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                className="px-8 py-3.5 rounded-lg transition-all"
                style={{
                  color: '#e8dfc8', fontFamily: "'Cinzel', serif",
                  fontSize: '0.82rem', letterSpacing: '0.08em',
                  border: '1px solid rgba(232, 223, 200, 0.3)',
                  backgroundColor: 'rgba(232, 223, 200, 0.05)',
                }}
              >
                Explore Hotel
              </motion.button>
            </div>
          </motion.div>

          {/* Floating info cards */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="absolute right-6 bottom-16 hidden xl:flex flex-col gap-3"
          >
            {[
              { label: 'Guest Rooms', value: '120+' },
              { label: 'Est. Since', value: '2017' },
              { label: 'Tagaytay City', value: 'PH' },
            ].map((item) => (
              <div
                key={item.label}
                className="px-5 py-3 rounded-xl text-center"
                style={{ backgroundColor: 'rgba(34, 42, 30, 0.8)', border: '1px solid #344a2a', backdropFilter: 'blur(8px)' }}
              >
                <div style={{ fontFamily: "'Cinzel', serif", color: '#c4943d', fontSize: '1.4rem', fontWeight: 700 }}>{item.value}</div>
                <div style={{ color: '#9a9278', fontSize: '0.65rem', letterSpacing: '0.1em', fontFamily: "'Cinzel', serif" }}>{item.label}</div>
              </div>
            ))}
          </motion.div>
        </div>

        {/* Scroll indicator */}
        <motion.div
          className="absolute bottom-8 left-1/2 -translate-x-1/2"
          animate={{ y: [0, 8, 0] }}
          transition={{ repeat: Infinity, duration: 2 }}
        >
          <Waves size={20} style={{ color: '#4a6a3a' }} />
        </motion.div>
      </section>

      {/* ── ABOUT ── */}
      <section id="about" className="py-20 relative">
        <div className="max-w-6xl mx-auto px-6 grid md:grid-cols-2 gap-12 items-center">
          {/* Image */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="rounded-2xl overflow-hidden" style={{ border: '1px solid #344a2a' }}>
              <ImageWithFallback src={ABOUT_IMG} alt="Sunrise Haven Hotel interior" className="w-full h-80 object-cover" style={{ filter: 'saturate(0.85)' }} />
            </div>
            {/* Decorative corner */}
            <div className="absolute -top-3 -left-3 w-16 h-16" style={{ borderTop: '2px solid #c4943d', borderLeft: '2px solid #c4943d', borderRadius: '4px 0 0 0' }} />
            <div className="absolute -bottom-3 -right-3 w-16 h-16" style={{ borderBottom: '2px solid #c4943d', borderRight: '2px solid #c4943d', borderRadius: '0 0 4px 0' }} />
          </motion.div>

          {/* Text */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="h-px w-8" style={{ backgroundColor: '#c4943d' }} />
              <span style={{ fontFamily: "'Cinzel', serif", color: '#c4943d', fontSize: '0.65rem', letterSpacing: '0.25em' }}>EST. 2017</span>
            </div>
            <h2 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '2rem', fontWeight: 600, marginBottom: '1rem', letterSpacing: '0.03em' }}>
              About Sunrise Haven
            </h2>
            <p style={{ color: '#b0a890', lineHeight: 1.9, marginBottom: '1.5rem', fontSize: '1.05rem' }}>
              Founded in 2017, Sunrise Haven Hotel was born from a vision to blend modern Philippine hospitality with the natural splendor of Tagaytay. Our founders — seasoned veterans of the tourism and hospitality industries — sought to create a sanctuary where guests could reconnect with nature without sacrificing comfort.
            </p>
            <p style={{ color: '#9a9278', lineHeight: 1.9, marginBottom: '2rem', fontSize: '1rem' }}>
              Today, we proudly serve leisure travelers, business guests, and event organizers seeking a distinctive Tagaytay experience, just an hour from Metro Manila.
            </p>

            <ul className="grid grid-cols-2 gap-3">
              {['120 Guest Rooms & Suites', 'On-Site Restaurant & Bar', 'Conference & Event Halls', 'Outdoor Pool & Fitness Center', 'Free Shuttle to City Center', '24/7 Concierge Service'].map(feat => (
                <li key={feat} className="flex items-start gap-2">
                  <ChevronRight size={14} style={{ color: '#c4943d', flexShrink: 0, marginTop: '5px' }} />
                  <span style={{ color: '#9a9278', fontSize: '0.9rem' }}>{feat}</span>
                </li>
              ))}
            </ul>
          </motion.div>
        </div>
      </section>

      {/* Decorative divider */}
      <div className="max-w-4xl mx-auto px-6 flex items-center gap-4">
        <div className="flex-1 h-px" style={{ backgroundColor: '#2a3526' }} />
        <span style={{ fontFamily: "'Noto Serif JP', serif", color: '#4a6a3a', fontSize: '0.85rem' }}>✦</span>
        <div className="flex-1 h-px" style={{ backgroundColor: '#2a3526' }} />
      </div>

      {/* ── ROOMS ── */}
      <section id="rooms" className="py-20">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <span style={{ fontFamily: "'Cinzel', serif", color: '#c4943d', fontSize: '0.68rem', letterSpacing: '0.28em' }}>ACCOMMODATIONS</span>
            <h2 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '2rem', fontWeight: 600, marginTop: '0.5rem', letterSpacing: '0.03em' }}>
              Rooms & Rates
            </h2>
            <p style={{ color: '#9a9278', maxWidth: '480px', margin: '0.75rem auto 0', lineHeight: 1.8 }}>
              Each room is designed with your comfort in mind, offering modern amenities alongside the natural beauty of Tagaytay.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-6">
            {rooms.map((room, i) => (
              <motion.div
                key={room.name}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.12 }}
                className="group rounded-2xl overflow-hidden"
                style={{ backgroundColor: '#1a2016', border: '1px solid #2a3526', transition: 'border-color 0.3s' }}
                onMouseEnter={e => (e.currentTarget.style.borderColor = '#c4943d')}
                onMouseLeave={e => (e.currentTarget.style.borderColor = '#2a3526')}
              >
                <div className="relative overflow-hidden h-52">
                  <ImageWithFallback
                    src={room.img}
                    alt={room.name}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    style={{ filter: 'saturate(0.8) brightness(0.85)' }}
                  />
                  <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(15,21,16,0.8) 0%, transparent 60%)' }} />
                  <div className="absolute bottom-4 left-4">
                    <span style={{ fontFamily: "'Cinzel', serif", color: '#c4943d', fontSize: '1.4rem', fontWeight: 700 }}>
                      {room.price}
                    </span>
                    <span style={{ color: '#9a9278', fontSize: '0.75rem' }}>/night</span>
                  </div>
                </div>
                <div className="p-5">
                  <h3 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '1rem', fontWeight: 600, marginBottom: '0.5rem', letterSpacing: '0.04em' }}>
                    {room.name}
                  </h3>
                  <p style={{ color: '#9a9278', fontSize: '0.9rem', lineHeight: 1.7, marginBottom: '1rem' }}>{room.desc}</p>
                  <ul className="grid grid-cols-2 gap-1.5 mb-5">
                    {room.features.map(f => (
                      <li key={f} className="flex items-center gap-1.5">
                        <span style={{ color: '#6a9954', fontSize: '0.65rem' }}>●</span>
                        <span style={{ color: '#9a9278', fontSize: '0.78rem' }}>{f}</span>
                      </li>
                    ))}
                  </ul>
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.97 }}
                    className="w-full py-2.5 rounded-xl"
                    style={{
                      fontFamily: "'Cinzel', serif", fontSize: '0.72rem', letterSpacing: '0.1em',
                      background: 'linear-gradient(135deg, #c4943d, #a87830)',
                      color: '#141a11', fontWeight: 700,
                    }}
                  >
                    Book This Room
                  </motion.button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── SERVICES ── */}
      <section id="services" className="py-20" style={{ backgroundColor: '#141a11' }}>
        <div className="max-w-7xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <span style={{ fontFamily: "'Cinzel', serif", color: '#c4943d', fontSize: '0.68rem', letterSpacing: '0.28em' }}>WHAT WE OFFER</span>
            <h2 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '2rem', fontWeight: 600, marginTop: '0.5rem' }}>
              Our Services
            </h2>
          </motion.div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {services.map((svc, i) => {
              const Icon = svc.icon;
              return (
                <motion.div
                  key={svc.label}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="p-6 rounded-xl group cursor-default"
                  style={{ backgroundColor: '#1e2519', border: '1px solid #2a3526', transition: 'all 0.3s' }}
                  onMouseEnter={e => { e.currentTarget.style.borderColor = '#4a6a3a'; e.currentTarget.style.backgroundColor = '#222a1e'; }}
                  onMouseLeave={e => { e.currentTarget.style.borderColor = '#2a3526'; e.currentTarget.style.backgroundColor = '#1e2519'; }}
                >
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center mb-4"
                    style={{ backgroundColor: 'rgba(196,148,61,0.12)', border: '1px solid rgba(196,148,61,0.2)' }}
                  >
                    <Icon size={22} style={{ color: '#c4943d' }} />
                  </div>
                  <h3 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '0.85rem', fontWeight: 600, marginBottom: '0.5rem', letterSpacing: '0.05em' }}>
                    {svc.label}
                  </h3>
                  <p style={{ color: '#9a9278', fontSize: '0.88rem', lineHeight: 1.7 }}>{svc.desc}</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── CONTACT ── */}
      <section id="contact" className="py-20" style={{ backgroundColor: '#0f1510' }}>
        <div className="max-w-6xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <span style={{ fontFamily: "'Cinzel', serif", color: '#c4943d', fontSize: '0.68rem', letterSpacing: '0.28em' }}>REACH US</span>
            <h2 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '2rem', fontWeight: 600, marginTop: '0.5rem' }}>
              Get In Touch
            </h2>
            <p style={{ color: '#9a9278', maxWidth: '400px', margin: '0.75rem auto 0', lineHeight: 1.8 }}>
              Whether planning a stay or a private event, our team is ready to assist you.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-5 mb-12">
            {[
              { icon: Phone, label: 'Phone', value: '+63 912 345-6789', sub: 'Mon–Sun 7AM–10PM' },
              { icon: Mail, label: 'Email', value: 'info@sunrisehaven.com', sub: 'Response within 2 hours' },
              { icon: MapPin, label: 'Address', value: '123 Tagaytay View Rd', sub: 'Tagaytay City, Philippines' },
            ].map((item, i) => {
              const Icon = item.icon;
              return (
                <motion.div
                  key={item.label}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="p-6 rounded-xl text-center"
                  style={{ backgroundColor: '#1a2016', border: '1px solid #2a3526' }}
                >
                  <div className="w-12 h-12 rounded-xl flex items-center justify-center mx-auto mb-4" style={{ backgroundColor: 'rgba(106,153,84,0.15)', border: '1px solid rgba(106,153,84,0.25)' }}>
                    <Icon size={22} style={{ color: '#6a9954' }} />
                  </div>
                  <div style={{ fontFamily: "'Cinzel', serif", color: '#c4943d', fontSize: '0.7rem', letterSpacing: '0.15em', marginBottom: '0.5rem' }}>{item.label}</div>
                  <div style={{ color: '#e8dfc8', fontSize: '0.95rem' }}>{item.value}</div>
                  <div style={{ color: '#9a9278', fontSize: '0.8rem', marginTop: '0.25rem' }}>{item.sub}</div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── FOOTER ── */}
      <footer style={{ backgroundColor: '#0a0f0b', borderTop: '1px solid #1e2519', padding: '2.5rem 1.5rem' }}>
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #c4943d, #e0b85a)' }}>
                  <Sun size={16} style={{ color: '#141a11' }} />
                </div>
                <span style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '0.85rem', letterSpacing: '0.08em' }}>SUNRISE HAVEN</span>
              </div>
              <p style={{ color: '#9a9278', fontSize: '0.85rem', lineHeight: 1.8 }}>
                Tagaytay City's premier hotel retreat since 2017. Experience warmth, serenity, and world-class hospitality.
              </p>
            </div>
            <div>
              <h5 style={{ fontFamily: "'Cinzel', serif", color: '#c4943d', fontSize: '0.7rem', letterSpacing: '0.15em', marginBottom: '1rem' }}>QUICK LINKS</h5>
              <ul className="space-y-2">
                {['Terms & Conditions', 'Privacy Policy', 'FAQ', 'Careers'].map(l => (
                  <li key={l}>
                    <a href="#" style={{ color: '#9a9278', fontSize: '0.88rem', transition: 'color 0.2s' }}
                      onMouseEnter={e => (e.currentTarget.style.color = '#c4943d')}
                      onMouseLeave={e => (e.currentTarget.style.color = '#9a9278')}
                    >{l}</a>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h5 style={{ fontFamily: "'Cinzel', serif", color: '#c4943d', fontSize: '0.7rem', letterSpacing: '0.15em', marginBottom: '1rem' }}>STAFF ACCESS</h5>
              <button
                onClick={() => navigate('/login')}
                className="px-5 py-2 rounded-lg w-full"
                style={{ fontFamily: "'Cinzel', serif", fontSize: '0.72rem', letterSpacing: '0.08em', color: '#e8dfc8', border: '1px solid #344a2a', backgroundColor: '#1a2016' }}
              >
                Management System Login
              </button>
              <p style={{ color: '#4a6a3a', fontSize: '0.7rem', fontFamily: "'Noto Serif JP', serif", marginTop: '1rem', letterSpacing: '0.1em' }}>
                旭の宿 · Sunrise Haven Hotel
              </p>
            </div>
          </div>
          <div style={{ borderTop: '1px solid #1e2519', paddingTop: '1.5rem', textAlign: 'center' }}>
            <p style={{ color: '#4a6a3a', fontSize: '0.78rem', fontFamily: "'Cormorant Garamond', serif", letterSpacing: '0.08em' }}>
              © 2026 Sunrise Haven Hotel — All Rights Reserved · Tagaytay City, Philippines
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
