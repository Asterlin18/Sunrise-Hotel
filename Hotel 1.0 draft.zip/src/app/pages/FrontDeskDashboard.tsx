import { useState } from 'react';
import { useNavigate } from 'react-router';
import { motion } from 'motion/react';
import {
  CheckCircle2, Clock, XCircle, BedDouble, Users, ArrowLeftRight,
  ChevronRight, Search, Bell, Calendar
} from 'lucide-react';

const todayArrivals = [
  { id: 'RES-2026-089', name: 'Maria Santos', room: '305', type: 'Premium', time: '2:00 PM', nights: 3, status: 'confirmed' },
  { id: 'RES-2026-091', name: 'Ana Reyes', room: '418', type: 'Suite', time: '3:30 PM', nights: 2, status: 'confirmed' },
  { id: 'RES-2026-093', name: 'Roberto Villanueva', room: '207', type: 'Standard', time: '4:00 PM', nights: 1, status: 'pending' },
  { id: 'RES-2026-095', name: 'Elena Cruz', room: '112', type: 'Standard', time: '5:00 PM', nights: 4, status: 'confirmed' },
];

const todayDepartures = [
  { id: 'RES-2026-080', name: 'Juan dela Cruz', room: '212', type: 'Premium', time: '11:00 AM', nights: 3, status: 'checked-out' },
  { id: 'RES-2026-082', name: 'Patricia Lim', room: '307', type: 'Suite', time: '12:00 PM', nights: 5, status: 'pending-checkout' },
  { id: 'RES-2026-084', name: 'Fernando Aquino', room: '109', type: 'Standard', time: '1:00 PM', nights: 2, status: 'pending-checkout' },
];

const roomStatus = [
  { floor: 1, rooms: [
    { num: '101', status: 'available' }, { num: '102', status: 'occupied' }, { num: '103', status: 'available' },
    { num: '104', status: 'maintenance' }, { num: '105', status: 'occupied' }, { num: '106', status: 'occupied' },
    { num: '107', status: 'available' }, { num: '108', status: 'occupied' }, { num: '109', status: 'checkout' },
    { num: '110', status: 'available' },
  ]},
  { floor: 2, rooms: [
    { num: '201', status: 'occupied' }, { num: '202', status: 'occupied' }, { num: '203', status: 'available' },
    { num: '204', status: 'occupied' }, { num: '205', status: 'maintenance' }, { num: '206', status: 'occupied' },
    { num: '207', status: 'available' }, { num: '208', status: 'occupied' }, { num: '209', status: 'occupied' },
    { num: '210', status: 'checkout' },
  ]},
  { floor: 3, rooms: [
    { num: '301', status: 'occupied' }, { num: '302', status: 'available' }, { num: '303', status: 'occupied' },
    { num: '304', status: 'occupied' }, { num: '305', status: 'occupied' }, { num: '306', status: 'available' },
    { num: '307', status: 'checkout' }, { num: '308', status: 'occupied' },
  ]},
];

const roomColors: Record<string, { bg: string; border: string; text: string; label: string }> = {
  available: { bg: 'rgba(106,153,84,0.15)', border: '#3d6b32', text: '#6a9954', label: 'Available' },
  occupied: { bg: 'rgba(58,95,122,0.15)', border: '#2a4a5a', text: '#5a8faa', label: 'Occupied' },
  maintenance: { bg: 'rgba(139,90,43,0.15)', border: '#5a3825', text: '#9a6a3a', label: 'Maintenance' },
  checkout: { bg: 'rgba(196,148,61,0.15)', border: '#7a5a20', text: '#c4943d', label: 'Checkout' },
};

export function FrontDeskDashboard() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFloor, setActiveFloor] = useState(1);

  const currentFloor = roomStatus.find(f => f.floor === activeFloor);

  return (
    <div className="p-6 space-y-6" style={{ fontFamily: "'EB Garamond', serif" }}>
      {/* Header */}
      <div className="flex items-start justify-between flex-wrap gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <div className="h-px w-6" style={{ backgroundColor: '#3a5f7a' }} />
            <span style={{ fontFamily: "'Cinzel', serif", color: '#5a8faa', fontSize: '0.65rem', letterSpacing: '0.2em' }}>
              FRONT DESK OPERATIONS
            </span>
          </div>
          <h1 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '1.6rem', fontWeight: 600, letterSpacing: '0.04em' }}>
            Front Desk Dashboard
          </h1>
          <p style={{ color: '#9a9278', fontSize: '0.9rem' }}>
            {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })} · Shift: Morning
          </p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => navigate('/frontdesk/checkinout')}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl"
            style={{ fontFamily: "'Cinzel', serif", fontSize: '0.7rem', letterSpacing: '0.08em', backgroundColor: '#3a5f7a', color: '#e8dfc8', fontWeight: 700 }}
          >
            <ArrowLeftRight size={14} /> Check-In / Out
          </button>
          <button
            onClick={() => navigate('/frontdesk/reservations')}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl"
            style={{ fontFamily: "'Cinzel', serif", fontSize: '0.7rem', letterSpacing: '0.08em', color: '#e8dfc8', border: '1px solid #344a2a', backgroundColor: '#1e2519' }}
          >
            <Calendar size={14} /> Reservations
          </button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'ARRIVALS TODAY', value: 4, color: '#6a9954', icon: CheckCircle2, sub: '2 confirmed' },
          { label: 'DEPARTURES TODAY', value: 3, color: '#c4943d', icon: ArrowLeftRight, sub: '1 checked out' },
          { label: 'ROOMS OCCUPIED', value: 74, color: '#5a8faa', icon: BedDouble, sub: 'of 120 rooms' },
          { label: 'GUESTS IN-HOUSE', value: 127, color: '#9a6a3a', icon: Users, sub: 'active guests' },
        ].map((stat) => {
          const Icon = stat.icon;
          return (
            <motion.div
              key={stat.label}
              whileHover={{ y: -2 }}
              className="rounded-2xl p-5 relative overflow-hidden"
              style={{ backgroundColor: '#1a2016', border: '1px solid #2a3526' }}
            >
              <div className="absolute top-0 left-0 right-0 h-px" style={{ background: `linear-gradient(to right, transparent, ${stat.color}55, transparent)` }} />
              <div className="flex items-center justify-between mb-3">
                <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ backgroundColor: `${stat.color}18`, border: `1px solid ${stat.color}30` }}>
                  <Icon size={17} style={{ color: stat.color }} />
                </div>
              </div>
              <div style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '1.8rem', fontWeight: 700, lineHeight: 1 }}>{stat.value}</div>
              <div style={{ fontFamily: "'Cinzel', serif", color: stat.color, fontSize: '0.6rem', letterSpacing: '0.12em', marginTop: '0.3rem' }}>{stat.label}</div>
              <div style={{ color: '#9a9278', fontSize: '0.78rem', marginTop: '0.25rem' }}>{stat.sub}</div>
            </motion.div>
          );
        })}
      </div>

      {/* Main Grid */}
      <div className="grid lg:grid-cols-5 gap-5">
        {/* Arrivals */}
        <div className="lg:col-span-3 rounded-2xl p-5" style={{ backgroundColor: '#1a2016', border: '1px solid #2a3526' }}>
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '0.85rem', letterSpacing: '0.08em' }}>Today's Arrivals</h3>
              <p style={{ color: '#9a9278', fontSize: '0.78rem' }}>{todayArrivals.length} guests expected</p>
            </div>
            <button onClick={() => navigate('/frontdesk/checkinout')} style={{ color: '#6a9954', fontFamily: "'Cinzel', serif", fontSize: '0.65rem', letterSpacing: '0.1em' }} className="flex items-center gap-1">
              Manage <ChevronRight size={12} />
            </button>
          </div>

          {/* Search bar */}
          <div className="relative mb-4">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: '#4a6a3a' }} />
            <input
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search guest or reservation..."
              className="w-full pl-9 pr-4 py-2.5 rounded-xl outline-none"
              style={{ backgroundColor: '#222a1e', border: '1px solid #2a3526', color: '#e8dfc8', fontSize: '0.9rem', fontFamily: "'EB Garamond', serif" }}
              onFocus={e => (e.target.style.borderColor = '#3a5f7a')}
              onBlur={e => (e.target.style.borderColor = '#2a3526')}
            />
          </div>

          <div className="space-y-2">
            {todayArrivals
              .filter(a => !searchQuery || a.name.toLowerCase().includes(searchQuery.toLowerCase()))
              .map((arrival) => (
                <motion.div
                  key={arrival.id}
                  whileHover={{ x: 2 }}
                  className="flex items-center justify-between px-4 py-3 rounded-xl"
                  style={{ backgroundColor: '#222a1e', border: '1px solid #2a3526' }}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
                      style={{ background: 'linear-gradient(135deg, #3a5f7a, #2a4a5a)', color: '#e8dfc8', fontFamily: "'Cinzel', serif", fontSize: '0.72rem' }}
                    >
                      {arrival.name.split(' ').map(n => n[0]).join('')}
                    </div>
                    <div>
                      <div style={{ color: '#e8dfc8', fontSize: '0.92rem' }}>{arrival.name}</div>
                      <div style={{ color: '#9a9278', fontSize: '0.72rem', fontFamily: "'Cinzel', serif", letterSpacing: '0.06em' }}>
                        Room {arrival.room} · {arrival.type} · {arrival.nights}N
                      </div>
                    </div>
                  </div>
                  <div className="text-right flex items-center gap-3">
                    <div>
                      <div style={{ color: '#c4943d', fontSize: '0.8rem', fontFamily: "'Cinzel', serif" }}>{arrival.time}</div>
                      <div
                        className="text-center px-2 py-0.5 rounded"
                        style={{
                          fontSize: '0.65rem', fontFamily: "'Cinzel', serif", letterSpacing: '0.06em',
                          color: arrival.status === 'confirmed' ? '#6a9954' : '#c4943d',
                          backgroundColor: arrival.status === 'confirmed' ? 'rgba(106,153,84,0.15)' : 'rgba(196,148,61,0.15)',
                        }}
                      >
                        {arrival.status.toUpperCase()}
                      </div>
                    </div>
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => navigate('/frontdesk/checkinout')}
                      className="px-3 py-1.5 rounded-lg"
                      style={{ backgroundColor: '#3a5f7a', color: '#e8dfc8', fontFamily: "'Cinzel', serif", fontSize: '0.65rem', letterSpacing: '0.08em' }}
                    >
                      CHECK IN
                    </motion.button>
                  </div>
                </motion.div>
              ))}
          </div>
        </div>

        {/* Departures */}
        <div className="lg:col-span-2 rounded-2xl p-5" style={{ backgroundColor: '#1a2016', border: '1px solid #2a3526' }}>
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '0.85rem', letterSpacing: '0.08em' }}>Today's Departures</h3>
              <p style={{ color: '#9a9278', fontSize: '0.78rem' }}>{todayDepartures.length} guests</p>
            </div>
          </div>

          <div className="space-y-2 mb-5">
            {todayDepartures.map((dep) => (
              <motion.div
                key={dep.id}
                whileHover={{ x: 2 }}
                className="px-4 py-3 rounded-xl"
                style={{ backgroundColor: '#222a1e', border: '1px solid #2a3526' }}
              >
                <div className="flex items-center justify-between mb-1">
                  <span style={{ color: '#e8dfc8', fontSize: '0.9rem' }}>{dep.name}</span>
                  <span
                    className="px-2 py-0.5 rounded text-center"
                    style={{
                      fontSize: '0.62rem', fontFamily: "'Cinzel', serif",
                      color: dep.status === 'checked-out' ? '#6a9954' : '#c4943d',
                      backgroundColor: dep.status === 'checked-out' ? 'rgba(106,153,84,0.15)' : 'rgba(196,148,61,0.15)',
                    }}
                  >
                    {dep.status === 'checked-out' ? 'DONE' : 'PENDING'}
                  </span>
                </div>
                <div style={{ color: '#9a9278', fontSize: '0.72rem', fontFamily: "'Cinzel', serif", letterSpacing: '0.05em' }}>
                  Room {dep.room} · By {dep.time}
                </div>
                {dep.status !== 'checked-out' && (
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    onClick={() => navigate('/frontdesk/checkinout')}
                    className="mt-2 w-full py-1.5 rounded-lg"
                    style={{ backgroundColor: 'rgba(196,148,61,0.15)', border: '1px solid rgba(196,148,61,0.3)', color: '#c4943d', fontFamily: "'Cinzel', serif", fontSize: '0.62rem', letterSpacing: '0.08em' }}
                  >
                    PROCESS CHECK-OUT
                  </motion.button>
                )}
              </motion.div>
            ))}
          </div>

          {/* Alerts */}
          <div className="rounded-xl p-4" style={{ backgroundColor: 'rgba(139,53,53,0.08)', border: '1px solid rgba(139,53,53,0.25)' }}>
            <div className="flex items-center gap-2 mb-2">
              <Bell size={13} style={{ color: '#c87a7a' }} />
              <span style={{ fontFamily: "'Cinzel', serif", color: '#c87a7a', fontSize: '0.68rem', letterSpacing: '0.1em' }}>ATTENTION</span>
            </div>
            <p style={{ color: '#9a9278', fontSize: '0.82rem', lineHeight: 1.6 }}>
              2 guests have late check-out requests pending approval. Room 212 requires housekeeping priority.
            </p>
          </div>
        </div>
      </div>

      {/* Floor Plan Mini */}
      <div className="rounded-2xl p-5" style={{ backgroundColor: '#1a2016', border: '1px solid #2a3526' }}>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '0.85rem', letterSpacing: '0.08em' }}>Room Status Overview</h3>
            <p style={{ color: '#9a9278', fontSize: '0.78rem' }}>Quick floor view</p>
          </div>
          <div className="flex gap-1.5">
            {[1, 2, 3].map(f => (
              <button
                key={f}
                onClick={() => setActiveFloor(f)}
                className="px-3 py-1 rounded-lg transition-all"
                style={{
                  fontFamily: "'Cinzel', serif", fontSize: '0.65rem', letterSpacing: '0.08em',
                  backgroundColor: activeFloor === f ? 'rgba(196,148,61,0.15)' : '#222a1e',
                  color: activeFloor === f ? '#c4943d' : '#9a9278',
                  border: activeFloor === f ? '1px solid rgba(196,148,61,0.3)' : '1px solid #2a3526',
                }}
              >
                Floor {f}
              </button>
            ))}
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          {currentFloor?.rooms.map(room => {
            const cfg = roomColors[room.status];
            return (
              <motion.div
                key={room.num}
                whileHover={{ scale: 1.08 }}
                className="w-14 h-14 rounded-xl flex flex-col items-center justify-center cursor-pointer"
                style={{ backgroundColor: cfg.bg, border: `1px solid ${cfg.border}` }}
              >
                <span style={{ fontFamily: "'Cinzel', serif", color: cfg.text, fontSize: '0.75rem', fontWeight: 600 }}>{room.num}</span>
                <span style={{ color: cfg.text, fontSize: '0.55rem', letterSpacing: '0.06em', opacity: 0.8 }}>{cfg.label.toUpperCase().slice(0, 4)}</span>
              </motion.div>
            );
          })}
        </div>

        {/* Legend */}
        <div className="flex flex-wrap gap-4 mt-4">
          {Object.entries(roomColors).map(([key, cfg]) => (
            <div key={key} className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-sm" style={{ backgroundColor: cfg.bg, border: `1px solid ${cfg.border}` }} />
              <span style={{ color: '#9a9278', fontSize: '0.75rem' }}>{cfg.label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
