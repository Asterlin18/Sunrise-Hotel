import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  CheckCircle2, Clock, ArrowRight, BedDouble, User, Calendar,
  Search, Phone, CreditCard, LogIn, LogOut, ChevronRight, Check, X
} from 'lucide-react';

type ActiveTab = 'checkin' | 'checkout';
type Step = 0 | 1 | 2 | 3;

const PENDING_CHECKINS = [
  { id: 'RES-2026-089', guest: 'Maria Santos', phone: '+63 912 345-6789', room: '305', type: 'Premium', arrival: '2:00 PM', nights: 3, checkOut: 'Apr 13' },
  { id: 'RES-2026-093', guest: 'Roberto Villanueva', phone: '+63 921 678-9012', room: '207', type: 'Standard', arrival: '4:00 PM', nights: 1, checkOut: 'Apr 9' },
  { id: 'RES-2026-095', guest: 'Elena Cruz', phone: '+63 919 345-6781', room: '112', type: 'Standard', arrival: '5:00 PM', nights: 4, checkOut: 'Apr 12' },
];

const PENDING_CHECKOUTS = [
  { id: 'RES-2026-082', guest: 'Patricia Lim', phone: '+63 918 765-4321', room: '307', type: 'Premium', checkIn: 'Apr 3', nights: 5, total: '₱26,000', balance: '₱0' },
  { id: 'RES-2026-084', guest: 'Fernando Aquino', phone: '+63 920 876-5432', room: '109', type: 'Standard', checkIn: 'Apr 6', nights: 2, total: '₱7,000', balance: '₱0' },
];

const CHECKIN_STEPS = ['Verify Reservation', 'Assign Room', 'ID Verification', 'Complete'];
const CHECKOUT_STEPS = ['Select Guest', 'Review Charges', 'Payment', 'Complete'];

type GuestItem = typeof PENDING_CHECKINS[0] | typeof PENDING_CHECKOUTS[0];

export function CheckInOutPage() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('checkin');
  const [selectedItem, setSelectedItem] = useState<GuestItem | null>(null);
  const [step, setStep] = useState<Step>(0);
  const [search, setSearch] = useState('');
  const [checkedIn, setCheckedIn] = useState<Set<string>>(new Set());
  const [checkedOut, setCheckedOut] = useState<Set<string>>(new Set());

  const startProcess = (item: GuestItem) => {
    setSelectedItem(item);
    setStep(0);
  };

  const completeProcess = () => {
    if (selectedItem) {
      if (activeTab === 'checkin') setCheckedIn(prev => new Set([...prev, selectedItem.id]));
      else setCheckedOut(prev => new Set([...prev, selectedItem.id]));
    }
    setSelectedItem(null);
    setStep(0);
  };

  const steps = activeTab === 'checkin' ? CHECKIN_STEPS : CHECKOUT_STEPS;

  return (
    <div className="p-6 space-y-5" style={{ fontFamily: "'EB Garamond', serif" }}>
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 mb-1">
          <div className="h-px w-6" style={{ backgroundColor: '#c4943d' }} />
          <span style={{ fontFamily: "'Cinzel', serif", color: '#c4943d', fontSize: '0.65rem', letterSpacing: '0.2em' }}>GUEST PROCESSING</span>
        </div>
        <h1 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '1.6rem', fontWeight: 600, letterSpacing: '0.04em' }}>
          Check-In / Check-Out
        </h1>
        <p style={{ color: '#9a9278', fontSize: '0.9rem' }}>
          {PENDING_CHECKINS.length} arrivals · {PENDING_CHECKOUTS.length} departures today
        </p>
      </div>

      {/* Tab Switcher */}
      <div className="flex gap-1 p-1 rounded-2xl w-fit" style={{ backgroundColor: '#1a2016', border: '1px solid #2a3526' }}>
        {(['checkin', 'checkout'] as ActiveTab[]).map(tab => (
          <motion.button
            key={tab}
            onClick={() => { setActiveTab(tab); setSelectedItem(null); setStep(0); }}
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl transition-all"
            style={{
              backgroundColor: activeTab === tab ? (tab === 'checkin' ? '#3a5f7a' : 'rgba(196,148,61,0.2)') : 'transparent',
              color: activeTab === tab ? (tab === 'checkin' ? '#e8dfc8' : '#c4943d') : '#9a9278',
              fontFamily: "'Cinzel', serif", fontSize: '0.72rem', letterSpacing: '0.08em',
            }}
          >
            {tab === 'checkin' ? <LogIn size={15} /> : <LogOut size={15} />}
            {tab === 'checkin' ? 'Check-In' : 'Check-Out'}
          </motion.button>
        ))}
      </div>

      <div className="grid lg:grid-cols-5 gap-5">
        {/* Guest List */}
        <div className="lg:col-span-2 space-y-4">
          {/* Search */}
          <div className="relative">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: '#4a6a3a' }} />
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search guest or reservation..."
              className="w-full pl-9 pr-4 py-2.5 rounded-xl outline-none"
              style={{ backgroundColor: '#1a2016', border: '1px solid #2a3526', color: '#e8dfc8', fontSize: '0.9rem', fontFamily: "'EB Garamond', serif" }}
              onFocus={e => (e.target.style.borderColor = '#c4943d')}
              onBlur={e => (e.target.style.borderColor = '#2a3526')}
            />
          </div>

          {/* List */}
          <div className="space-y-2">
            {(activeTab === 'checkin' ? PENDING_CHECKINS : PENDING_CHECKOUTS)
              .filter(item => !search || item.guest.toLowerCase().includes(search.toLowerCase()))
              .map(item => {
                const isProcessed = activeTab === 'checkin' ? checkedIn.has(item.id) : checkedOut.has(item.id);
                const isSelected = selectedItem?.id === item.id;
                return (
                  <motion.div
                    key={item.id}
                    whileHover={{ x: 2 }}
                    onClick={() => !isProcessed && startProcess(item)}
                    className="rounded-xl p-4 relative overflow-hidden"
                    style={{
                      backgroundColor: isSelected ? (activeTab === 'checkin' ? 'rgba(58,95,122,0.15)' : 'rgba(196,148,61,0.1)') : '#1a2016',
                      border: `1px solid ${isSelected ? (activeTab === 'checkin' ? '#3a5f7a' : '#7a5a20') : '#2a3526'}`,
                      cursor: isProcessed ? 'default' : 'pointer',
                      opacity: isProcessed ? 0.5 : 1,
                    }}
                  >
                    {isProcessed && (
                      <div className="absolute top-2 right-2">
                        <CheckCircle2 size={16} style={{ color: '#6a9954' }} />
                      </div>
                    )}
                    <div className="flex items-center gap-3">
                      <div
                        className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                        style={{ background: activeTab === 'checkin' ? 'linear-gradient(135deg, #3a5f7a, #2a4a5a)' : 'linear-gradient(135deg, rgba(196,148,61,0.3), rgba(168,120,48,0.3))', color: '#e8dfc8', fontFamily: "'Cinzel', serif", fontSize: '0.75rem', fontWeight: 600 }}
                      >
                        {item.guest.split(' ').map(n => n[0]).join('')}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div style={{ color: '#e8dfc8', fontSize: '0.92rem' }}>{item.guest}</div>
                        <div style={{ color: '#9a9278', fontSize: '0.72rem', fontFamily: "'Cinzel', serif", letterSpacing: '0.05em' }}>
                          {item.id} · Room {item.room}
                        </div>
                      </div>
                      <ChevronRight size={14} style={{ color: '#4a6a3a', flexShrink: 0 }} />
                    </div>
                    <div className="flex items-center gap-4 mt-3 pt-3" style={{ borderTop: '1px solid #1e2519' }}>
                      <div>
                        <div style={{ color: '#9a9278', fontSize: '0.6rem', fontFamily: "'Cinzel', serif", letterSpacing: '0.1em' }}>{activeTab === 'checkin' ? 'ARRIVAL' : 'CHECKED IN'}</div>
                        <div style={{ color: '#c4943d', fontSize: '0.8rem', fontFamily: "'Cinzel', serif" }}>
                          {'arrival' in item ? item.arrival : item.checkIn}
                        </div>
                      </div>
                      <div>
                        <div style={{ color: '#9a9278', fontSize: '0.6rem', fontFamily: "'Cinzel', serif", letterSpacing: '0.1em' }}>ROOM TYPE</div>
                        <div style={{ color: '#e8dfc8', fontSize: '0.8rem' }}>{item.type}</div>
                      </div>
                      {'total' in item && (
                        <div>
                          <div style={{ color: '#9a9278', fontSize: '0.6rem', fontFamily: "'Cinzel', serif", letterSpacing: '0.1em' }}>TOTAL</div>
                          <div style={{ color: '#6a9954', fontSize: '0.8rem', fontFamily: "'Cinzel', serif" }}>{item.total}</div>
                        </div>
                      )}
                    </div>
                  </motion.div>
                );
              })}
          </div>
        </div>

        {/* Process Panel */}
        <div className="lg:col-span-3">
          {!selectedItem ? (
            <div className="h-full rounded-2xl flex items-center justify-center" style={{ backgroundColor: '#1a2016', border: '1px solid #2a3526', minHeight: '400px' }}>
              <div className="text-center px-8">
                <div className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4" style={{ backgroundColor: 'rgba(196,148,61,0.08)', border: '1px solid rgba(196,148,61,0.15)' }}>
                  {activeTab === 'checkin' ? <LogIn size={28} style={{ color: '#4a6a3a' }} /> : <LogOut size={28} style={{ color: '#4a6a3a' }} />}
                </div>
                <p style={{ fontFamily: "'Cinzel', serif", color: '#9a9278', fontSize: '0.8rem', letterSpacing: '0.1em' }}>
                  SELECT A GUEST FROM THE LIST
                </p>
                <p style={{ color: '#4a6a3a', fontSize: '0.82rem', marginTop: '0.5rem' }}>
                  to begin the {activeTab === 'checkin' ? 'check-in' : 'check-out'} process
                </p>
              </div>
            </div>
          ) : (
            <div className="rounded-2xl overflow-hidden" style={{ backgroundColor: '#1a2016', border: '1px solid #344a2a' }}>
              {/* Top bar */}
              <div className="absolute h-px w-full" style={{ background: 'linear-gradient(to right, transparent, #c4943d, transparent)' }} />

              {/* Step Indicator */}
              <div className="px-6 pt-6 pb-4" style={{ borderBottom: '1px solid #2a3526' }}>
                <div className="flex items-center gap-2 mb-4">
                  <span style={{ fontFamily: "'Cinzel', serif", color: '#c4943d', fontSize: '0.62rem', letterSpacing: '0.18em' }}>
                    {activeTab === 'checkin' ? 'CHECK-IN PROCESS' : 'CHECK-OUT PROCESS'}
                  </span>
                  <span style={{ color: '#9a9278', fontSize: '0.78rem' }}>· {selectedItem.guest}</span>
                </div>
                <div className="flex items-center">
                  {steps.map((s, i) => (
                    <div key={s} className="flex items-center flex-1">
                      <div className="flex flex-col items-center">
                        <motion.div
                          animate={{
                            backgroundColor: i < step ? '#6a9954' : i === step ? '#c4943d' : '#2a3526',
                            borderColor: i < step ? '#6a9954' : i === step ? '#c4943d' : '#344a2a',
                          }}
                          className="w-8 h-8 rounded-full flex items-center justify-center border-2"
                          style={{ fontFamily: "'Cinzel', serif", fontSize: '0.7rem', fontWeight: 600, color: i <= step ? '#141a11' : '#9a9278' }}
                        >
                          {i < step ? <Check size={14} /> : i + 1}
                        </motion.div>
                        <span style={{ color: i === step ? '#c4943d' : '#4a6a3a', fontSize: '0.55rem', fontFamily: "'Cinzel', serif", letterSpacing: '0.06em', marginTop: '4px', textAlign: 'center', width: '60px' }}>
                          {s}
                        </span>
                      </div>
                      {i < steps.length - 1 && (
                        <div className="flex-1 h-px mx-1" style={{ backgroundColor: i < step ? '#6a9954' : '#2a3526' }} />
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Step Content */}
              <div className="p-6">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={step}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.2 }}
                  >
                    {step === 0 && (
                      <div className="space-y-4">
                        <h3 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '1rem', letterSpacing: '0.05em' }}>
                          {steps[0]}
                        </h3>
                        {/* Reservation details */}
                        <div className="rounded-xl p-4" style={{ backgroundColor: '#222a1e', border: '1px solid #2a3526' }}>
                          <div className="grid grid-cols-2 gap-4">
                            {[
                              { label: 'RESERVATION ID', value: selectedItem.id, icon: Calendar },
                              { label: 'GUEST NAME', value: selectedItem.guest, icon: User },
                              { label: 'PHONE', value: selectedItem.phone, icon: Phone },
                              { label: 'ROOM', value: `${selectedItem.room} · ${selectedItem.type}`, icon: BedDouble },
                              { label: 'NIGHTS', value: `${selectedItem.nights} night(s)`, icon: Clock },
                              { label: 'CHECK-OUT', value: 'checkOut' in selectedItem ? selectedItem.checkOut : 'N/A', icon: Calendar },
                            ].map(info => {
                              const Icon = info.icon;
                              return (
                                <div key={info.label} className="flex items-start gap-3">
                                  <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0" style={{ backgroundColor: 'rgba(196,148,61,0.1)' }}>
                                    <Icon size={14} style={{ color: '#c4943d' }} />
                                  </div>
                                  <div>
                                    <div style={{ fontFamily: "'Cinzel', serif", color: '#9a9278', fontSize: '0.58rem', letterSpacing: '0.1em' }}>{info.label}</div>
                                    <div style={{ color: '#e8dfc8', fontSize: '0.88rem' }}>{info.value}</div>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      </div>
                    )}

                    {step === 1 && (
                      <div className="space-y-4">
                        <h3 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '1rem', letterSpacing: '0.05em' }}>
                          {steps[1]}
                        </h3>
                        {activeTab === 'checkin' ? (
                          <div className="rounded-xl p-4" style={{ backgroundColor: '#222a1e', border: '1px solid #2a3526' }}>
                            <p style={{ color: '#9a9278', fontSize: '0.9rem', marginBottom: '1rem' }}>
                              Assigned room for this reservation:
                            </p>
                            <div className="flex items-center gap-4 p-4 rounded-xl" style={{ backgroundColor: 'rgba(106,153,84,0.1)', border: '1px solid rgba(106,153,84,0.25)' }}>
                              <BedDouble size={24} style={{ color: '#6a9954' }} />
                              <div>
                                <div style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '1.3rem', fontWeight: 700 }}>Room {selectedItem.room}</div>
                                <div style={{ color: '#6a9954', fontSize: '0.8rem' }}>{selectedItem.type} · Ready for occupancy</div>
                              </div>
                            </div>
                            <div className="mt-3 space-y-2">
                              {['WiFi Password: SunriseHaven2026', 'Breakfast: Included · 6AM–10AM', 'Pool hours: 8AM–8PM', 'Checkout: 12:00 PM'].map(info => (
                                <div key={info} className="flex items-center gap-2" style={{ color: '#9a9278', fontSize: '0.85rem' }}>
                                  <Check size={13} style={{ color: '#6a9954', flexShrink: 0 }} />
                                  {info}
                                </div>
                              ))}
                            </div>
                          </div>
                        ) : (
                          <div className="space-y-3">
                            <div className="p-4 rounded-xl" style={{ backgroundColor: '#222a1e', border: '1px solid #2a3526' }}>
                              <p style={{ fontFamily: "'Cinzel', serif", color: '#9a9278', fontSize: '0.62rem', letterSpacing: '0.12em', marginBottom: '0.75rem' }}>CHARGE SUMMARY</p>
                              {[
                                { label: `Room ${selectedItem.room} (${selectedItem.nights} nights)`, amount: 'total' in selectedItem ? selectedItem.total : '—' },
                                { label: 'Room Service', amount: '₱850' },
                                { label: 'Tax & Fees (10%)', amount: '₱785' },
                              ].map(charge => (
                                <div key={charge.label} className="flex justify-between py-2" style={{ borderBottom: '1px solid #1e2519', color: '#e8dfc8', fontSize: '0.9rem' }}>
                                  <span style={{ color: '#9a9278' }}>{charge.label}</span>
                                  <span style={{ color: '#c4943d', fontFamily: "'Cinzel', serif" }}>{charge.amount}</span>
                                </div>
                              ))}
                              <div className="flex justify-between pt-3 mt-1">
                                <span style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '0.8rem', letterSpacing: '0.08em' }}>TOTAL DUE</span>
                                <span style={{ fontFamily: "'Cinzel', serif", color: '#c4943d', fontSize: '1.1rem', fontWeight: 700 }}>
                                  {'total' in selectedItem ? selectedItem.total : '—'}
                                </span>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    )}

                    {step === 2 && (
                      <div className="space-y-4">
                        <h3 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '1rem', letterSpacing: '0.05em' }}>
                          {steps[2]}
                        </h3>
                        {activeTab === 'checkin' ? (
                          <div className="space-y-3">
                            <p style={{ color: '#9a9278', fontSize: '0.9rem' }}>Please verify the guest's valid ID:</p>
                            <div className="grid grid-cols-2 gap-3">
                              {["Passport", "Driver's License", "National ID", "Company ID"].map(idType => (
                                <label key={idType} className="flex items-center gap-3 p-3 rounded-xl cursor-pointer" style={{ backgroundColor: '#222a1e', border: '1px solid #2a3526' }}>
                                  <input type="radio" name="idType" style={{ accentColor: '#c4943d' }} />
                                  <span style={{ color: '#e8dfc8', fontSize: '0.88rem' }}>{idType}</span>
                                </label>
                              ))}
                            </div>
                            <div>
                              <label style={{ fontFamily: "'Cinzel', serif", color: '#9a9278', fontSize: '0.6rem', letterSpacing: '0.12em', display: 'block', marginBottom: '0.4rem' }}>ID NUMBER</label>
                              <input
                                placeholder="Enter ID number..."
                                className="w-full px-4 py-2.5 rounded-xl outline-none"
                                style={{ backgroundColor: '#222a1e', border: '1px solid #2a3526', color: '#e8dfc8', fontSize: '0.9rem' }}
                                onFocus={e => (e.target.style.borderColor = '#c4943d')}
                                onBlur={e => (e.target.style.borderColor = '#2a3526')}
                              />
                            </div>
                          </div>
                        ) : (
                          <div className="space-y-4">
                            <p style={{ color: '#9a9278', fontSize: '0.9rem' }}>Process payment for guest departure:</p>
                            <div className="grid grid-cols-2 gap-3">
                              {['Cash', 'Credit Card', 'Debit Card', 'GCash'].map(method => (
                                <label key={method} className="flex items-center gap-3 p-3 rounded-xl cursor-pointer" style={{ backgroundColor: '#222a1e', border: '1px solid #2a3526' }}>
                                  <input type="radio" name="payment" style={{ accentColor: '#c4943d' }} />
                                  <CreditCard size={14} style={{ color: '#4a6a3a' }} />
                                  <span style={{ color: '#e8dfc8', fontSize: '0.88rem' }}>{method}</span>
                                </label>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    )}

                    {step === 3 && (
                      <div className="text-center py-6 space-y-4">
                        <motion.div
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          transition={{ type: 'spring', stiffness: 200 }}
                          className="w-20 h-20 rounded-full flex items-center justify-center mx-auto"
                          style={{ backgroundColor: 'rgba(106,153,84,0.15)', border: '2px solid #6a9954' }}
                        >
                          <CheckCircle2 size={36} style={{ color: '#6a9954' }} />
                        </motion.div>
                        <div>
                          <h3 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '1.1rem', letterSpacing: '0.06em' }}>
                            {activeTab === 'checkin' ? 'Check-In Complete!' : 'Check-Out Complete!'}
                          </h3>
                          <p style={{ color: '#9a9278', fontSize: '0.9rem', marginTop: '0.5rem' }}>
                            {activeTab === 'checkin'
                              ? `${selectedItem.guest} has been successfully checked in to Room ${selectedItem.room}.`
                              : `${selectedItem.guest} has been successfully checked out. Room ${selectedItem.room} is now available for cleaning.`}
                          </p>
                        </div>
                        <div className="px-4 py-3 rounded-xl" style={{ backgroundColor: '#222a1e', border: '1px solid #2a3526' }}>
                          <div style={{ fontFamily: "'Cinzel', serif", color: '#9a9278', fontSize: '0.6rem', letterSpacing: '0.12em', marginBottom: '0.4rem' }}>
                            {activeTab === 'checkin' ? 'KEY CARD ISSUED' : 'RECEIPT NUMBER'}
                          </div>
                          <div style={{ fontFamily: "'Cinzel', serif", color: '#c4943d', fontSize: '1rem', fontWeight: 700, letterSpacing: '0.1em' }}>
                            {activeTab === 'checkin' ? `KEY-${selectedItem.room}-${Date.now().toString().slice(-6)}` : `RCP-${Date.now().toString().slice(-8)}`}
                          </div>
                        </div>
                      </div>
                    )}
                  </motion.div>
                </AnimatePresence>

                {/* Navigation Buttons */}
                <div className="flex gap-3 mt-6 pt-4" style={{ borderTop: '1px solid #1e2519' }}>
                  {step > 0 && step < 3 && (
                    <button
                      onClick={() => setStep((step - 1) as Step)}
                      className="px-5 py-2.5 rounded-xl"
                      style={{ backgroundColor: '#222a1e', border: '1px solid #344a2a', color: '#9a9278', fontFamily: "'Cinzel', serif", fontSize: '0.72rem', letterSpacing: '0.08em' }}
                    >
                      BACK
                    </button>
                  )}
                  {step < 3 ? (
                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.97 }}
                      onClick={() => setStep((step + 1) as Step)}
                      className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl"
                      style={{ background: 'linear-gradient(135deg, #c4943d, #a87830)', color: '#141a11', fontFamily: "'Cinzel', serif", fontWeight: 700, fontSize: '0.72rem', letterSpacing: '0.1em' }}
                    >
                      {step === 2 ? (activeTab === 'checkin' ? 'COMPLETE CHECK-IN' : 'CONFIRM CHECK-OUT') : 'CONTINUE'}
                      <ArrowRight size={14} />
                    </motion.button>
                  ) : (
                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.97 }}
                      onClick={completeProcess}
                      className="flex-1 py-2.5 rounded-xl"
                      style={{ backgroundColor: 'rgba(106,153,84,0.15)', border: '1px solid rgba(106,153,84,0.3)', color: '#6a9954', fontFamily: "'Cinzel', serif", fontWeight: 700, fontSize: '0.72rem', letterSpacing: '0.1em' }}
                    >
                      DONE — NEXT GUEST
                    </motion.button>
                  )}
                  <button
                    onClick={() => { setSelectedItem(null); setStep(0); }}
                    className="p-2.5 rounded-xl"
                    style={{ backgroundColor: 'rgba(139,53,53,0.1)', border: '1px solid rgba(139,53,53,0.2)', color: '#c87a7a' }}
                  >
                    <X size={16} />
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}