import { useState } from 'react';
import { motion } from 'motion/react';
import {
  BedDouble, Tag, Shield, Bell, Globe, Palette, Save,
  Plus, Pencil, Trash2, ChevronRight, User, Lock, Toggle
} from 'lucide-react';

type SettingsTab = 'roomtypes' | 'pricing' | 'roles' | 'notifications' | 'system';

const ROOM_TYPES = [
  { id: 1, name: 'Standard Room', code: 'STD', capacity: 2, basePrice: 3500, count: 60, features: ['WiFi', 'AC', 'TV', 'Garden View'] },
  { id: 2, name: 'Premium Room', code: 'PRM', capacity: 3, basePrice: 5200, count: 40, features: ['WiFi', 'AC', 'Smart TV', 'Lake View', 'Mini Bar', 'Balcony'] },
  { id: 3, name: 'Deluxe Suite', code: 'STE', capacity: 4, basePrice: 8500, count: 20, features: ['WiFi', 'AC', 'Smart TV', 'Panoramic View', 'Jacuzzi', 'Butler', 'Lounge'] },
];

const USER_ROLES = [
  { id: 1, name: 'Administrator', level: 'Full Access', users: 2, perms: ['All Modules', 'User Management', 'Financial Reports', 'Settings', 'System Logs'] },
  { id: 2, name: 'Front Desk', level: 'Limited Access', users: 5, perms: ['Reservations', 'Check-In/Out', 'Guest Management', 'Room Status'] },
  { id: 3, name: 'Housekeeping', level: 'View Only', users: 8, perms: ['Room Status', 'Cleaning Schedule', 'Maintenance Requests'] },
  { id: 4, name: 'Accountant', level: 'Reports Only', users: 1, perms: ['Financial Reports', 'Revenue Analytics', 'Billing'] },
];

const PRICING_SEASONS = [
  { name: 'Regular Season', period: 'Jan – Mar, Jun – Sep', multiplier: '1.0x', color: '#6a9954' },
  { name: 'Peak Season', period: 'Apr – May (Holy Week)', multiplier: '1.5x', color: '#c4943d' },
  { name: 'Holiday Season', period: 'Oct – Dec (Christmas)', multiplier: '1.35x', color: '#9a6aaa' },
  { name: 'Special Events', period: 'Variable dates', multiplier: '1.25x', color: '#5a8faa' },
];

const SYSTEM_SETTINGS = [
  { group: 'Reservation Settings', items: [
    { label: 'Minimum Advance Booking', value: '24 hours', type: 'select' },
    { label: 'Maximum Booking Window', value: '12 months', type: 'select' },
    { label: 'Cancellation Period', value: '48 hours', type: 'select' },
    { label: 'Auto-Confirm Reservations', value: true, type: 'toggle' },
  ]},
  { group: 'Check-In/Out Settings', items: [
    { label: 'Standard Check-In Time', value: '2:00 PM', type: 'select' },
    { label: 'Standard Check-Out Time', value: '12:00 PM', type: 'select' },
    { label: 'Late Check-Out Fee', value: '₱500/hour', type: 'text' },
    { label: 'Early Check-In Available', value: true, type: 'toggle' },
  ]},
  { group: 'Payment Settings', items: [
    { label: 'Accepted Currencies', value: 'PHP, USD', type: 'select' },
    { label: 'Tax Rate', value: '10% VAT', type: 'text' },
    { label: 'Service Charge', value: '10%', type: 'text' },
    { label: 'Online Payment', value: true, type: 'toggle' },
  ]},
];

export function SettingsPage() {
  const [activeTab, setActiveTab] = useState<SettingsTab>('roomtypes');
  const [editingRoom, setEditingRoom] = useState<number | null>(null);

  const tabs = [
    { id: 'roomtypes' as SettingsTab, label: 'Room Types', icon: BedDouble },
    { id: 'pricing' as SettingsTab, label: 'Pricing', icon: Tag },
    { id: 'roles' as SettingsTab, label: 'User Roles', icon: Shield },
    { id: 'notifications' as SettingsTab, label: 'Notifications', icon: Bell },
    { id: 'system' as SettingsTab, label: 'System', icon: Globe },
  ];

  return (
    <div className="p-6 space-y-5" style={{ fontFamily: "'EB Garamond', serif" }}>
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 mb-1">
          <div className="h-px w-6" style={{ backgroundColor: '#c4943d' }} />
          <span style={{ fontFamily: "'Cinzel', serif", color: '#c4943d', fontSize: '0.65rem', letterSpacing: '0.2em' }}>SYSTEM CONFIGURATION</span>
        </div>
        <h1 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '1.6rem', fontWeight: 600, letterSpacing: '0.04em' }}>
          Settings
        </h1>
        <p style={{ color: '#9a9278', fontSize: '0.9rem' }}>Configure your hotel management system</p>
      </div>

      <div className="flex gap-5 flex-col lg:flex-row">
        {/* Sidebar Tabs */}
        <div className="lg:w-52 flex-shrink-0">
          <div className="rounded-2xl overflow-hidden" style={{ backgroundColor: '#1a2016', border: '1px solid #2a3526' }}>
            {tabs.map(tab => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <motion.button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className="w-full flex items-center gap-3 px-4 py-3.5 transition-all relative"
                  style={{
                    backgroundColor: isActive ? 'rgba(196,148,61,0.1)' : 'transparent',
                    borderRight: isActive ? '2px solid #c4943d' : '2px solid transparent',
                    color: isActive ? '#c4943d' : '#9a9278',
                    borderBottom: '1px solid #1e2519',
                  }}
                  whileHover={{ x: 2 }}
                >
                  <Icon size={16} />
                  <span style={{ fontFamily: "'Cinzel', serif", fontSize: '0.72rem', letterSpacing: '0.06em' }}>{tab.label}</span>
                  {isActive && <ChevronRight size={12} className="ml-auto" />}
                </motion.button>
              );
            })}
          </div>
        </div>

        {/* Content Panel */}
        <div className="flex-1">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, x: 16 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.2 }}
          >
            {/* ── ROOM TYPES ── */}
            {activeTab === 'roomtypes' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '1rem', letterSpacing: '0.05em' }}>Room Types</h2>
                    <p style={{ color: '#9a9278', fontSize: '0.85rem' }}>Manage your room categories and configurations</p>
                  </div>
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    className="flex items-center gap-2 px-4 py-2 rounded-xl"
                    style={{ background: 'linear-gradient(135deg, #c4943d, #a87830)', color: '#141a11', fontFamily: "'Cinzel', serif", fontSize: '0.68rem', letterSpacing: '0.08em', fontWeight: 700 }}
                  >
                    <Plus size={13} /> Add Type
                  </motion.button>
                </div>

                {ROOM_TYPES.map(type => (
                  <div key={type.id} className="rounded-2xl p-5" style={{ backgroundColor: '#1a2016', border: '1px solid #2a3526' }}>
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <div className="flex items-center gap-3">
                          <div
                            className="px-2.5 py-1 rounded-lg"
                            style={{ backgroundColor: 'rgba(196,148,61,0.1)', border: '1px solid rgba(196,148,61,0.2)', fontFamily: "'Cinzel', serif", color: '#c4943d', fontSize: '0.65rem', letterSpacing: '0.1em' }}
                          >
                            {type.code}
                          </div>
                          <h3 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '0.95rem', letterSpacing: '0.04em' }}>{type.name}</h3>
                        </div>
                        <p style={{ color: '#9a9278', fontSize: '0.85rem', marginTop: '0.25rem' }}>
                          {type.count} rooms · Max {type.capacity} guests
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <motion.button
                          whileHover={{ scale: 1.05 }}
                          onClick={() => setEditingRoom(editingRoom === type.id ? null : type.id)}
                          className="p-2 rounded-lg"
                          style={{ backgroundColor: 'rgba(196,148,61,0.1)', color: '#c4943d' }}
                        >
                          <Pencil size={14} />
                        </motion.button>
                        <motion.button
                          whileHover={{ scale: 1.05 }}
                          className="p-2 rounded-lg"
                          style={{ backgroundColor: 'rgba(139,53,53,0.1)', color: '#c87a7a' }}
                        >
                          <Trash2 size={14} />
                        </motion.button>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 mb-4">
                      <div className="px-4 py-3 rounded-xl" style={{ backgroundColor: '#222a1e' }}>
                        <div style={{ fontFamily: "'Cinzel', serif", color: '#9a9278', fontSize: '0.58rem', letterSpacing: '0.12em' }}>BASE RATE/NIGHT</div>
                        {editingRoom === type.id ? (
                          <input
                            defaultValue={type.basePrice}
                            className="mt-1 w-full outline-none bg-transparent"
                            style={{ color: '#c4943d', fontSize: '1.1rem', fontFamily: "'Cinzel', serif", fontWeight: 700 }}
                          />
                        ) : (
                          <div style={{ color: '#c4943d', fontSize: '1.1rem', fontFamily: "'Cinzel', serif", fontWeight: 700, marginTop: '2px' }}>
                            ₱{type.basePrice.toLocaleString()}
                          </div>
                        )}
                      </div>
                      <div className="px-4 py-3 rounded-xl" style={{ backgroundColor: '#222a1e' }}>
                        <div style={{ fontFamily: "'Cinzel', serif", color: '#9a9278', fontSize: '0.58rem', letterSpacing: '0.12em' }}>MAX CAPACITY</div>
                        <div style={{ color: '#e8dfc8', fontSize: '1.1rem', fontFamily: "'Cinzel', serif", fontWeight: 700, marginTop: '2px' }}>
                          {type.capacity} guests
                        </div>
                      </div>
                    </div>

                    <div>
                      <div style={{ fontFamily: "'Cinzel', serif", color: '#9a9278', fontSize: '0.6rem', letterSpacing: '0.12em', marginBottom: '0.5rem' }}>STANDARD AMENITIES</div>
                      <div className="flex flex-wrap gap-2">
                        {type.features.map(f => (
                          <span key={f} className="px-2.5 py-1 rounded-lg" style={{ backgroundColor: 'rgba(106,153,84,0.1)', border: '1px solid rgba(106,153,84,0.2)', color: '#6a9954', fontSize: '0.72rem', fontFamily: "'Cinzel', serif" }}>
                            {f}
                          </span>
                        ))}
                        {editingRoom === type.id && (
                          <button className="px-2.5 py-1 rounded-lg" style={{ backgroundColor: 'rgba(196,148,61,0.1)', border: '1px dashed rgba(196,148,61,0.3)', color: '#c4943d', fontSize: '0.72rem' }}>
                            + Add
                          </button>
                        )}
                      </div>
                    </div>

                    {editingRoom === type.id && (
                      <motion.div
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="flex gap-3 mt-4 pt-4"
                        style={{ borderTop: '1px solid #2a3526' }}
                      >
                        <motion.button
                          whileHover={{ scale: 1.02 }}
                          onClick={() => setEditingRoom(null)}
                          className="flex items-center gap-2 px-4 py-2 rounded-xl"
                          style={{ background: 'linear-gradient(135deg, #c4943d, #a87830)', color: '#141a11', fontFamily: "'Cinzel', serif", fontSize: '0.68rem', fontWeight: 700, letterSpacing: '0.08em' }}
                        >
                          <Save size={13} /> Save Changes
                        </motion.button>
                        <button
                          onClick={() => setEditingRoom(null)}
                          className="px-4 py-2 rounded-xl"
                          style={{ backgroundColor: '#222a1e', border: '1px solid #344a2a', color: '#9a9278', fontFamily: "'Cinzel', serif", fontSize: '0.68rem' }}
                        >
                          Cancel
                        </button>
                      </motion.div>
                    )}
                  </div>
                ))}
              </div>
            )}

            {/* ── PRICING ── */}
            {activeTab === 'pricing' && (
              <div className="space-y-4">
                <div>
                  <h2 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '1rem', letterSpacing: '0.05em' }}>Pricing & Seasons</h2>
                  <p style={{ color: '#9a9278', fontSize: '0.85rem' }}>Configure seasonal rates and pricing modifiers</p>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  {PRICING_SEASONS.map(season => (
                    <div key={season.name} className="rounded-2xl p-5" style={{ backgroundColor: '#1a2016', border: '1px solid #2a3526' }}>
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h3 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '0.9rem', letterSpacing: '0.04em' }}>{season.name}</h3>
                          <p style={{ color: '#9a9278', fontSize: '0.82rem', marginTop: '0.2rem' }}>{season.period}</p>
                        </div>
                        <span
                          className="px-3 py-1 rounded-lg"
                          style={{ backgroundColor: `${season.color}18`, border: `1px solid ${season.color}30`, color: season.color, fontFamily: "'Cinzel', serif", fontSize: '0.8rem', fontWeight: 700 }}
                        >
                          {season.multiplier}
                        </span>
                      </div>
                      <div className="space-y-2">
                        {ROOM_TYPES.map(rt => (
                          <div key={rt.id} className="flex justify-between items-center py-2" style={{ borderBottom: '1px solid #1e2519' }}>
                            <span style={{ color: '#9a9278', fontSize: '0.85rem' }}>{rt.name}</span>
                            <span style={{ color: season.color, fontSize: '0.9rem', fontFamily: "'Cinzel', serif" }}>
                              ₱{(rt.basePrice * parseFloat(season.multiplier)).toLocaleString()}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Discount Codes */}
                <div className="rounded-2xl p-5" style={{ backgroundColor: '#1a2016', border: '1px solid #2a3526' }}>
                  <div className="flex items-center justify-between mb-4">
                    <h3 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '0.9rem', letterSpacing: '0.04em' }}>Promotional Codes</h3>
                    <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg" style={{ backgroundColor: 'rgba(196,148,61,0.1)', color: '#c4943d', fontFamily: "'Cinzel', serif", fontSize: '0.65rem', letterSpacing: '0.08em' }}>
                      <Plus size={12} /> Add Code
                    </button>
                  </div>
                  <div className="grid grid-cols-3 gap-3">
                    {['HAVEN10', 'VIP2026', 'TAGAYTAY15'].map(code => (
                      <div key={code} className="px-4 py-3 rounded-xl" style={{ backgroundColor: '#222a1e', border: '1px solid #2a3526' }}>
                        <div style={{ fontFamily: "'Cinzel', serif", color: '#c4943d', fontSize: '0.85rem', fontWeight: 700, letterSpacing: '0.08em' }}>{code}</div>
                        <div style={{ color: '#9a9278', fontSize: '0.72rem', marginTop: '0.2rem' }}>10% off · Active</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* ── USER ROLES ── */}
            {activeTab === 'roles' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '1rem', letterSpacing: '0.05em' }}>User Roles & Permissions</h2>
                    <p style={{ color: '#9a9278', fontSize: '0.85rem' }}>Manage access levels for each role</p>
                  </div>
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    className="flex items-center gap-2 px-4 py-2 rounded-xl"
                    style={{ background: 'linear-gradient(135deg, #c4943d, #a87830)', color: '#141a11', fontFamily: "'Cinzel', serif", fontSize: '0.68rem', letterSpacing: '0.08em', fontWeight: 700 }}
                  >
                    <Plus size={13} /> Add Role
                  </motion.button>
                </div>

                {USER_ROLES.map(role => {
                  const levelColors: Record<string, string> = {
                    'Full Access': '#c4943d',
                    'Limited Access': '#6a9954',
                    'View Only': '#9a9278',
                    'Reports Only': '#5a8faa',
                  };
                  const color = levelColors[role.level] || '#9a9278';
                  return (
                    <div key={role.id} className="rounded-2xl p-5" style={{ backgroundColor: '#1a2016', border: '1px solid #2a3526' }}>
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: `${color}18`, border: `1px solid ${color}30` }}>
                            <Shield size={18} style={{ color }} />
                          </div>
                          <div>
                            <h3 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '0.92rem', letterSpacing: '0.04em' }}>{role.name}</h3>
                            <div className="flex items-center gap-2 mt-0.5">
                              <span className="px-2 py-0.5 rounded" style={{ backgroundColor: `${color}15`, color, fontFamily: "'Cinzel', serif", fontSize: '0.6rem', letterSpacing: '0.08em' }}>
                                {role.level}
                              </span>
                              <span style={{ color: '#9a9278', fontSize: '0.78rem' }}>{role.users} user{role.users > 1 ? 's' : ''}</span>
                            </div>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <button className="p-2 rounded-lg" style={{ backgroundColor: 'rgba(196,148,61,0.1)', color: '#c4943d' }}><Pencil size={14} /></button>
                          {role.level !== 'Full Access' && (
                            <button className="p-2 rounded-lg" style={{ backgroundColor: 'rgba(139,53,53,0.1)', color: '#c87a7a' }}><Trash2 size={14} /></button>
                          )}
                        </div>
                      </div>
                      <div>
                        <div style={{ fontFamily: "'Cinzel', serif", color: '#9a9278', fontSize: '0.6rem', letterSpacing: '0.12em', marginBottom: '0.5rem' }}>MODULE ACCESS</div>
                        <div className="flex flex-wrap gap-2">
                          {role.perms.map(perm => (
                            <span key={perm} className="px-2.5 py-1 rounded-lg" style={{ backgroundColor: '#222a1e', border: '1px solid #2a3526', color: '#9a9278', fontSize: '0.72rem', fontFamily: "'Cinzel', serif" }}>
                              {perm}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* ── NOTIFICATIONS ── */}
            {activeTab === 'notifications' && (
              <div className="space-y-4">
                <div>
                  <h2 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '1rem', letterSpacing: '0.05em' }}>Notification Settings</h2>
                  <p style={{ color: '#9a9278', fontSize: '0.85rem' }}>Configure system alerts and communications</p>
                </div>
                {[
                  { label: 'New Reservation Alerts', desc: 'Get notified when a new booking is made', enabled: true },
                  { label: 'Check-In Reminders', desc: 'Alerts 2 hours before expected guest arrival', enabled: true },
                  { label: 'Check-Out Alerts', desc: 'Notifications for pending check-outs', enabled: true },
                  { label: 'Payment Confirmations', desc: 'Receive payment processing updates', enabled: false },
                  { label: 'Room Status Updates', desc: 'Notify when rooms are cleaned or flagged', enabled: true },
                  { label: 'Cancellation Alerts', desc: 'Get notified when reservations are cancelled', enabled: true },
                  { label: 'Daily Summary Report', desc: 'Receive daily operations summary at 10 PM', enabled: false },
                  { label: 'Low Occupancy Alerts', desc: 'Alert when occupancy falls below 50%', enabled: false },
                ].map(item => (
                  <div key={item.label} className="flex items-center justify-between px-5 py-4 rounded-xl" style={{ backgroundColor: '#1a2016', border: '1px solid #2a3526' }}>
                    <div>
                      <div style={{ color: '#e8dfc8', fontSize: '0.92rem' }}>{item.label}</div>
                      <div style={{ color: '#9a9278', fontSize: '0.8rem', marginTop: '0.2rem' }}>{item.desc}</div>
                    </div>
                    <button
                      className="relative w-12 h-6 rounded-full transition-all flex-shrink-0 ml-4"
                      style={{ backgroundColor: item.enabled ? 'rgba(106,153,84,0.3)' : '#222a1e', border: item.enabled ? '1px solid #6a9954' : '1px solid #344a2a' }}
                    >
                      <div
                        className="absolute top-0.5 w-5 h-5 rounded-full transition-all"
                        style={{ backgroundColor: item.enabled ? '#6a9954' : '#344a2a', left: item.enabled ? '25px' : '1px' }}
                      />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* ── SYSTEM ── */}
            {activeTab === 'system' && (
              <div className="space-y-5">
                <div>
                  <h2 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '1rem', letterSpacing: '0.05em' }}>System Settings</h2>
                  <p style={{ color: '#9a9278', fontSize: '0.85rem' }}>Hotel operational parameters and defaults</p>
                </div>

                {SYSTEM_SETTINGS.map(group => (
                  <div key={group.group} className="rounded-2xl overflow-hidden" style={{ backgroundColor: '#1a2016', border: '1px solid #2a3526' }}>
                    <div className="px-5 py-3" style={{ borderBottom: '1px solid #2a3526', backgroundColor: '#141a11' }}>
                      <span style={{ fontFamily: "'Cinzel', serif", color: '#c4943d', fontSize: '0.68rem', letterSpacing: '0.15em' }}>
                        {group.group.toUpperCase()}
                      </span>
                    </div>
                    <div className="divide-y" style={{ borderColor: '#1e2519' }}>
                      {group.items.map(item => (
                        <div key={item.label} className="flex items-center justify-between px-5 py-3.5">
                          <span style={{ color: '#e8dfc8', fontSize: '0.9rem' }}>{item.label}</span>
                          {item.type === 'toggle' ? (
                            <button
                              className="relative w-12 h-6 rounded-full transition-all flex-shrink-0"
                              style={{ backgroundColor: item.value ? 'rgba(106,153,84,0.3)' : '#222a1e', border: item.value ? '1px solid #6a9954' : '1px solid #344a2a' }}
                            >
                              <div
                                className="absolute top-0.5 w-5 h-5 rounded-full transition-all"
                                style={{ backgroundColor: item.value ? '#6a9954' : '#344a2a', left: item.value ? '25px' : '1px' }}
                              />
                            </button>
                          ) : (
                            <div className="flex items-center gap-2">
                              <span style={{ color: '#c4943d', fontSize: '0.88rem', fontFamily: "'Cinzel', serif" }}>{String(item.value)}</span>
                              <button className="p-1 rounded" style={{ color: '#4a6a3a' }}><Pencil size={12} /></button>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                ))}

                {/* System Info */}
                <div className="rounded-2xl p-5" style={{ backgroundColor: '#1a2016', border: '1px solid #2a3526' }}>
                  <div style={{ fontFamily: "'Cinzel', serif", color: '#c4943d', fontSize: '0.68rem', letterSpacing: '0.15em', marginBottom: '1rem' }}>SYSTEM INFORMATION</div>
                  {[
                    { label: 'System Version', value: 'HMS v2.4.1' },
                    { label: 'Hotel Name', value: 'Sunrise Haven Hotel' },
                    { label: 'Location', value: 'Tagaytay City, Philippines' },
                    { label: 'Database', value: 'PostgreSQL 16.2' },
                    { label: 'Last Backup', value: 'Today, 3:00 AM' },
                    { label: 'License', value: 'Sunrise Haven © 2026' },
                  ].map(info => (
                    <div key={info.label} className="flex justify-between py-2.5" style={{ borderBottom: '1px solid #1e2519' }}>
                      <span style={{ color: '#9a9278', fontSize: '0.88rem' }}>{info.label}</span>
                      <span style={{ color: '#e8dfc8', fontSize: '0.88rem', fontFamily: info.label === 'System Version' ? "'Cinzel', serif" : 'inherit' }}>
                        {info.value}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </div>
  );
}
