import { useState } from 'react';
import type { ComponentType } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  BedDouble, Wrench, CheckCircle2, Clock, X, Users, Star,
  ChevronDown, Grid3X3, List, Filter
} from 'lucide-react';

type RoomStatus = 'available' | 'occupied' | 'maintenance' | 'checkout';
type RoomType = 'Standard' | 'Premium' | 'Suite';

interface Room {
  number: string;
  type: RoomType;
  floor: number;
  status: RoomStatus;
  price: string;
  capacity: number;
  amenities: string[];
  lastCleaned: string;
  guest?: string;
  checkOut?: string;
}

const ALL_ROOMS: Room[] = [
  // Floor 1
  { number: '101', type: 'Standard', floor: 1, status: 'available', price: '₱3,500', capacity: 2, amenities: ['WiFi', 'AC', 'TV', 'Garden View'], lastCleaned: '7:30 AM' },
  { number: '102', type: 'Standard', floor: 1, status: 'occupied', price: '₱3,500', capacity: 2, amenities: ['WiFi', 'AC', 'TV', 'Garden View'], lastCleaned: '8:00 AM', guest: 'Roberto Villanueva', checkOut: 'Apr 11' },
  { number: '103', type: 'Standard', floor: 1, status: 'available', price: '₱3,500', capacity: 2, amenities: ['WiFi', 'AC', 'TV', 'City View'], lastCleaned: '8:15 AM' },
  { number: '104', type: 'Standard', floor: 1, status: 'maintenance', price: '₱3,500', capacity: 2, amenities: ['WiFi', 'AC', 'TV', 'City View'], lastCleaned: 'N/A' },
  { number: '105', type: 'Premium', floor: 1, status: 'occupied', price: '₱5,200', capacity: 3, amenities: ['WiFi', 'AC', 'Smart TV', 'Lake View', 'Mini Bar', 'Balcony'], lastCleaned: '9:00 AM', guest: 'Patricia Lim', checkOut: 'Apr 12' },
  { number: '106', type: 'Premium', floor: 1, status: 'available', price: '₱5,200', capacity: 3, amenities: ['WiFi', 'AC', 'Smart TV', 'Lake View', 'Mini Bar', 'Balcony'], lastCleaned: '7:45 AM' },
  { number: '107', type: 'Standard', floor: 1, status: 'available', price: '₱3,500', capacity: 2, amenities: ['WiFi', 'AC', 'TV', 'Pool View'], lastCleaned: '8:30 AM' },
  { number: '108', type: 'Standard', floor: 1, status: 'checkout', price: '₱3,500', capacity: 2, amenities: ['WiFi', 'AC', 'TV', 'City View'], lastCleaned: 'Due', guest: 'Fernando Aquino', checkOut: 'Today' },
  // Floor 2
  { number: '201', type: 'Standard', floor: 2, status: 'occupied', price: '₱3,500', capacity: 2, amenities: ['WiFi', 'AC', 'TV', 'City View'], lastCleaned: '8:00 AM', guest: 'Maria Santos', checkOut: 'Apr 13' },
  { number: '202', type: 'Premium', floor: 2, status: 'available', price: '₱5,200', capacity: 3, amenities: ['WiFi', 'AC', 'Smart TV', 'Lake View', 'Mini Bar'], lastCleaned: '8:20 AM' },
  { number: '203', type: 'Premium', floor: 2, status: 'occupied', price: '₱5,200', capacity: 3, amenities: ['WiFi', 'AC', 'Smart TV', 'Volcano View', 'Mini Bar'], lastCleaned: '9:15 AM', guest: 'Juan dela Cruz', checkOut: 'Apr 12' },
  { number: '204', type: 'Premium', floor: 2, status: 'available', price: '₱5,200', capacity: 3, amenities: ['WiFi', 'AC', 'Smart TV', 'Lake View', 'Balcony'], lastCleaned: '7:55 AM' },
  { number: '205', type: 'Standard', floor: 2, status: 'maintenance', price: '₱3,500', capacity: 2, amenities: ['WiFi', 'AC', 'TV', 'Garden View'], lastCleaned: 'N/A' },
  { number: '206', type: 'Suite', floor: 2, status: 'occupied', price: '₱8,500', capacity: 4, amenities: ['WiFi', 'AC', 'Smart TV', 'Panoramic View', 'Jacuzzi', 'Butler', 'Lounge'], lastCleaned: '10:00 AM', guest: 'Ana Reyes', checkOut: 'Apr 14' },
  { number: '207', type: 'Standard', floor: 2, status: 'available', price: '₱3,500', capacity: 2, amenities: ['WiFi', 'AC', 'TV', 'Pool View'], lastCleaned: '8:10 AM' },
  // Floor 3
  { number: '301', type: 'Premium', floor: 3, status: 'occupied', price: '₱5,200', capacity: 3, amenities: ['WiFi', 'AC', 'Smart TV', 'Lake View', 'Balcony'], lastCleaned: '9:30 AM', guest: 'Sofia Garcia', checkOut: 'Apr 25' },
  { number: '302', type: 'Standard', floor: 3, status: 'available', price: '₱3,500', capacity: 2, amenities: ['WiFi', 'AC', 'TV', 'City View'], lastCleaned: '8:45 AM' },
  { number: '303', type: 'Suite', floor: 3, status: 'available', price: '₱8,500', capacity: 4, amenities: ['WiFi', 'AC', 'Smart TV', 'Volcano View', 'Jacuzzi', 'Butler'], lastCleaned: '8:50 AM' },
  { number: '304', type: 'Premium', floor: 3, status: 'occupied', price: '₱5,200', capacity: 3, amenities: ['WiFi', 'AC', 'Smart TV', 'Lake View', 'Mini Bar'], lastCleaned: '9:00 AM', guest: 'Lucia Fernandez', checkOut: 'Apr 18' },
  { number: '305', type: 'Standard', floor: 3, status: 'checkout', price: '₱3,500', capacity: 2, amenities: ['WiFi', 'AC', 'TV', 'Pool View'], lastCleaned: 'Due', guest: 'Emmanuel Bautista', checkOut: 'Today' },
];

const statusConfig: Record<RoomStatus, { label: string; color: string; bg: string; border: string; icon: ComponentType<any> }> = {
  available: { label: 'Available', color: '#6a9954', bg: 'rgba(106,153,84,0.12)', border: '#3d6b32', icon: CheckCircle2 },
  occupied: { label: 'Occupied', color: '#5a8faa', bg: 'rgba(58,95,122,0.12)', border: '#2a4a5a', icon: Users },
  maintenance: { label: 'Maintenance', color: '#c4943d', bg: 'rgba(196,148,61,0.12)', border: '#7a5a20', icon: Wrench },
  checkout: { label: 'Checkout', color: '#c87a7a', bg: 'rgba(139,53,53,0.12)', border: '#5a2a2a', icon: Clock },
};

const typeColors: Record<RoomType, string> = {
  Standard: '#9a9278',
  Premium: '#c4943d',
  Suite: '#9a6aaa',
};

export function RoomsPage() {
  const [statusFilter, setStatusFilter] = useState<RoomStatus | 'all'>('all');
  const [typeFilter, setTypeFilter] = useState<RoomType | 'all'>('all');
  const [floorFilter, setFloorFilter] = useState<number | 'all'>('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null);

  const filtered = ALL_ROOMS.filter(r => {
    const matchStatus = statusFilter === 'all' || r.status === statusFilter;
    const matchType = typeFilter === 'all' || r.type === typeFilter;
    const matchFloor = floorFilter === 'all' || r.floor === floorFilter;
    return matchStatus && matchType && matchFloor;
  });

  const stats = {
    available: ALL_ROOMS.filter(r => r.status === 'available').length,
    occupied: ALL_ROOMS.filter(r => r.status === 'occupied').length,
    maintenance: ALL_ROOMS.filter(r => r.status === 'maintenance').length,
    checkout: ALL_ROOMS.filter(r => r.status === 'checkout').length,
  };

  return (
    <div className="p-6 space-y-5" style={{ fontFamily: "'EB Garamond', serif" }}>
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 mb-1">
          <div className="h-px w-6" style={{ backgroundColor: '#c4943d' }} />
          <span style={{ fontFamily: "'Cinzel', serif", color: '#c4943d', fontSize: '0.65rem', letterSpacing: '0.2em' }}>ROOM INVENTORY</span>
        </div>
        <h1 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '1.6rem', fontWeight: 600, letterSpacing: '0.04em' }}>
          Room Management
        </h1>
        <p style={{ color: '#9a9278', fontSize: '0.9rem' }}>{ALL_ROOMS.length} rooms across 4 floors</p>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {(Object.entries(stats) as [RoomStatus, number][]).map(([status, count]) => {
          const cfg = statusConfig[status];
          const Icon = cfg.icon;
          return (
            <motion.button
              key={status}
              whileHover={{ y: -1 }}
              onClick={() => setStatusFilter(statusFilter === status ? 'all' : status)}
              className="flex items-center gap-3 p-4 rounded-xl text-left"
              style={{
                backgroundColor: statusFilter === status ? cfg.bg : '#1a2016',
                border: `1px solid ${statusFilter === status ? cfg.border : '#2a3526'}`,
              }}
            >
              <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ backgroundColor: cfg.bg }}>
                <Icon size={16} style={{ color: cfg.color }} />
              </div>
              <div>
                <div style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '1.3rem', fontWeight: 700, lineHeight: 1 }}>{count}</div>
                <div style={{ fontFamily: "'Cinzel', serif", color: cfg.color, fontSize: '0.6rem', letterSpacing: '0.1em' }}>{cfg.label.toUpperCase()}</div>
              </div>
            </motion.button>
          );
        })}
      </div>

      {/* Filter Bar */}
      <div className="rounded-2xl p-4" style={{ backgroundColor: '#1a2016', border: '1px solid #2a3526' }}>
        <div className="flex flex-wrap gap-3 items-center">
          <Filter size={14} style={{ color: '#4a6a3a' }} />

          {/* Floor Filter */}
          <div className="flex gap-1.5">
            {(['all', 1, 2, 3] as (number | 'all')[]).map(f => (
              <button
                key={String(f)}
                onClick={() => setFloorFilter(f)}
                className="px-3 py-1.5 rounded-lg transition-all"
                style={{
                  fontFamily: "'Cinzel', serif", fontSize: '0.62rem', letterSpacing: '0.08em',
                  backgroundColor: floorFilter === f ? 'rgba(196,148,61,0.15)' : '#222a1e',
                  color: floorFilter === f ? '#c4943d' : '#9a9278',
                  border: floorFilter === f ? '1px solid rgba(196,148,61,0.3)' : '1px solid #2a3526',
                }}
              >
                {f === 'all' ? 'All Floors' : `Floor ${f}`}
              </button>
            ))}
          </div>

          <div className="h-4 w-px" style={{ backgroundColor: '#2a3526' }} />

          {/* Type filter */}
          <div className="flex gap-1.5">
            {(['all', 'Standard', 'Premium', 'Suite'] as (RoomType | 'all')[]).map(t => (
              <button
                key={t}
                onClick={() => setTypeFilter(t)}
                className="px-3 py-1.5 rounded-lg transition-all"
                style={{
                  fontFamily: "'Cinzel', serif", fontSize: '0.62rem', letterSpacing: '0.08em',
                  backgroundColor: typeFilter === t ? 'rgba(196,148,61,0.15)' : '#222a1e',
                  color: typeFilter === t ? '#c4943d' : '#9a9278',
                  border: typeFilter === t ? '1px solid rgba(196,148,61,0.3)' : '1px solid #2a3526',
                }}
              >
                {t === 'all' ? 'All Types' : t}
              </button>
            ))}
          </div>

          <div className="ml-auto flex gap-1.5">
            {[{ mode: 'grid' as const, icon: Grid3X3 }, { mode: 'list' as const, icon: List }].map(({ mode, icon: Icon }) => (
              <button
                key={mode}
                onClick={() => setViewMode(mode)}
                className="p-2 rounded-lg"
                style={{
                  backgroundColor: viewMode === mode ? 'rgba(196,148,61,0.15)' : '#222a1e',
                  color: viewMode === mode ? '#c4943d' : '#9a9278',
                  border: viewMode === mode ? '1px solid rgba(196,148,61,0.3)' : '1px solid #2a3526',
                }}
              >
                <Icon size={15} />
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Room Grid / List */}
      {viewMode === 'grid' ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
          {filtered.map((room, i) => {
            const cfg = statusConfig[room.status];
            const StatusIcon = cfg.icon;
            return (
              <motion.div
                key={room.number}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.03 }}
                whileHover={{ y: -3, scale: 1.02 }}
                onClick={() => setSelectedRoom(room)}
                className="rounded-2xl p-4 cursor-pointer relative overflow-hidden"
                style={{ backgroundColor: '#1a2016', border: `1px solid ${statusFilter === room.status || statusFilter === 'all' ? cfg.border : '#2a3526'}` }}
              >
                {/* Floor plan grid lines decoration */}
                <div className="absolute inset-0 opacity-5" style={{
                  backgroundImage: 'linear-gradient(#4a6a3a 1px, transparent 1px), linear-gradient(90deg, #4a6a3a 1px, transparent 1px)',
                  backgroundSize: '12px 12px'
                }} />
                <div className="relative">
                  <div className="flex items-center justify-between mb-3">
                    <span style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '1.2rem', fontWeight: 700 }}>
                      {room.number}
                    </span>
                    <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ backgroundColor: cfg.bg }}>
                      <StatusIcon size={13} style={{ color: cfg.color }} />
                    </div>
                  </div>
                  <div style={{ fontFamily: "'Cinzel', serif", color: typeColors[room.type], fontSize: '0.6rem', letterSpacing: '0.1em', marginBottom: '0.25rem' }}>
                    {room.type.toUpperCase()}
                  </div>
                  <div style={{ color: '#c4943d', fontSize: '0.8rem', marginBottom: '0.25rem' }}>{room.price}/night</div>
                  {room.guest && (
                    <div style={{ color: '#9a9278', fontSize: '0.72rem' }} className="truncate">{room.guest}</div>
                  )}
                  <div
                    className="mt-2 px-2 py-0.5 rounded text-center"
                    style={{ backgroundColor: cfg.bg, fontSize: '0.58rem', fontFamily: "'Cinzel', serif", color: cfg.color, letterSpacing: '0.08em' }}
                  >
                    {cfg.label.toUpperCase()}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      ) : (
        <div className="rounded-2xl overflow-hidden" style={{ backgroundColor: '#1a2016', border: '1px solid #2a3526' }}>
          <table className="w-full">
            <thead>
              <tr style={{ borderBottom: '1px solid #2a3526', backgroundColor: '#141a11' }}>
                {['Room No.', 'Type', 'Floor', 'Status', 'Price/Night', 'Capacity', 'Guest / Last Cleaned', 'Check-Out'].map(h => (
                  <th key={h} className="px-4 py-3 text-left" style={{ fontFamily: "'Cinzel', serif", fontSize: '0.6rem', letterSpacing: '0.12em', color: '#9a9278' }}>
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((room, i) => {
                const cfg = statusConfig[room.status];
                const StatusIcon = cfg.icon;
                return (
                  <motion.tr
                    key={room.number}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: i * 0.03 }}
                    onClick={() => setSelectedRoom(room)}
                    style={{ borderBottom: '1px solid #1e2519', cursor: 'pointer' }}
                    onMouseEnter={e => (e.currentTarget.style.backgroundColor = '#222a1e')}
                    onMouseLeave={e => (e.currentTarget.style.backgroundColor = 'transparent')}
                  >
                    <td className="px-4 py-3">
                      <span style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '0.9rem', fontWeight: 600 }}>Room {room.number}</span>
                    </td>
                    <td className="px-4 py-3">
                      <span style={{ fontFamily: "'Cinzel', serif", color: typeColors[room.type], fontSize: '0.72rem', letterSpacing: '0.06em' }}>{room.type}</span>
                    </td>
                    <td className="px-4 py-3" style={{ color: '#9a9278', fontSize: '0.88rem' }}>Floor {room.floor}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg w-fit" style={{ backgroundColor: cfg.bg }}>
                        <StatusIcon size={11} style={{ color: cfg.color }} />
                        <span style={{ fontFamily: "'Cinzel', serif", fontSize: '0.62rem', color: cfg.color, letterSpacing: '0.06em' }}>{cfg.label}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3" style={{ color: '#c4943d', fontSize: '0.9rem' }}>{room.price}</td>
                    <td className="px-4 py-3" style={{ color: '#9a9278', fontSize: '0.88rem' }}>{room.capacity} pax</td>
                    <td className="px-4 py-3" style={{ color: '#9a9278', fontSize: '0.88rem' }}>{room.guest || room.lastCleaned}</td>
                    <td className="px-4 py-3" style={{ color: '#9a9278', fontSize: '0.88rem' }}>{room.checkOut || '—'}</td>
                  </motion.tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Room Detail Modal */}
      <AnimatePresence>
        {selectedRoom && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
            style={{ backgroundColor: 'rgba(0,0,0,0.7)' }}
            onClick={() => setSelectedRoom(null)}
          >
            <motion.div
              initial={{ scale: 0.95, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 20 }}
              onClick={e => e.stopPropagation()}
              className="rounded-2xl p-6 w-full max-w-md relative overflow-hidden"
              style={{ backgroundColor: '#1a2016', border: '1px solid #344a2a', boxShadow: '0 24px 60px rgba(0,0,0,0.6)' }}
            >
              <div className="absolute top-0 left-8 right-8 h-px" style={{ background: 'linear-gradient(to right, transparent, #c4943d, transparent)' }} />
              {/* Floor plan grid bg */}
              <div className="absolute inset-0 opacity-3" style={{
                backgroundImage: 'linear-gradient(#4a6a3a 1px, transparent 1px), linear-gradient(90deg, #4a6a3a 1px, transparent 1px)',
                backgroundSize: '20px 20px'
              }} />

              <div className="relative">
                <div className="flex items-start justify-between mb-5">
                  <div>
                    <span style={{ fontFamily: "'Cinzel', serif", color: '#c4943d', fontSize: '0.65rem', letterSpacing: '0.2em' }}>ROOM PROFILE</span>
                    <h2 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '2rem', fontWeight: 700, lineHeight: 1 }}>
                      Room {selectedRoom.number}
                    </h2>
                    <span style={{ fontFamily: "'Cinzel', serif", color: typeColors[selectedRoom.type], fontSize: '0.72rem', letterSpacing: '0.1em' }}>
                      {selectedRoom.type} · Floor {selectedRoom.floor}
                    </span>
                  </div>
                  <button onClick={() => setSelectedRoom(null)} style={{ color: '#9a9278' }}><X size={18} /></button>
                </div>

                {/* Status Badge */}
                <div
                  className="flex items-center gap-2 px-4 py-2.5 rounded-xl mb-5"
                  style={{ backgroundColor: statusConfig[selectedRoom.status].bg, border: `1px solid ${statusConfig[selectedRoom.status].border}` }}
                >
                  {(() => { const Icon = statusConfig[selectedRoom.status].icon; return <Icon size={15} style={{ color: statusConfig[selectedRoom.status].color }} />; })()}
                  <span style={{ fontFamily: "'Cinzel', serif", color: statusConfig[selectedRoom.status].color, fontSize: '0.72rem', letterSpacing: '0.1em' }}>
                    {statusConfig[selectedRoom.status].label.toUpperCase()}
                  </span>
                  {selectedRoom.guest && (
                    <span style={{ color: '#9a9278', fontSize: '0.82rem', marginLeft: 'auto' }}>
                      {selectedRoom.guest}
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-4 mb-5">
                  {[
                    { label: 'NIGHTLY RATE', value: selectedRoom.price },
                    { label: 'CAPACITY', value: `${selectedRoom.capacity} guests` },
                    { label: 'LAST CLEANED', value: selectedRoom.lastCleaned },
                    { label: 'CHECK-OUT', value: selectedRoom.checkOut || 'N/A' },
                  ].map(info => (
                    <div key={info.label} className="px-4 py-3 rounded-xl" style={{ backgroundColor: '#222a1e' }}>
                      <div style={{ fontFamily: "'Cinzel', serif", color: '#9a9278', fontSize: '0.58rem', letterSpacing: '0.12em', marginBottom: '0.25rem' }}>{info.label}</div>
                      <div style={{ color: '#e8dfc8', fontSize: '0.9rem' }}>{info.value}</div>
                    </div>
                  ))}
                </div>

                <div>
                  <div style={{ fontFamily: "'Cinzel', serif", color: '#9a9278', fontSize: '0.6rem', letterSpacing: '0.12em', marginBottom: '0.5rem' }}>AMENITIES</div>
                  <div className="flex flex-wrap gap-2">
                    {selectedRoom.amenities.map(a => (
                      <span key={a} className="px-2.5 py-1 rounded-lg" style={{ backgroundColor: 'rgba(106,153,84,0.1)', border: '1px solid rgba(106,153,84,0.2)', color: '#6a9954', fontSize: '0.75rem', fontFamily: "'Cinzel', serif", letterSpacing: '0.05em' }}>
                        {a}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="flex gap-3 mt-5">
                  {selectedRoom.status === 'available' && (
                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      className="flex-1 py-2.5 rounded-xl"
                      style={{ background: 'linear-gradient(135deg, #c4943d, #a87830)', color: '#141a11', fontFamily: "'Cinzel', serif", fontWeight: 700, fontSize: '0.7rem', letterSpacing: '0.1em' }}
                    >
                      ASSIGN GUEST
                    </motion.button>
                  )}
                  {selectedRoom.status === 'checkout' && (
                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      className="flex-1 py-2.5 rounded-xl"
                      style={{ backgroundColor: 'rgba(106,153,84,0.15)', border: '1px solid rgba(106,153,84,0.3)', color: '#6a9954', fontFamily: "'Cinzel', serif", fontSize: '0.7rem', letterSpacing: '0.1em' }}
                    >
                      MARK CLEANED
                    </motion.button>
                  )}
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    className="flex-1 py-2.5 rounded-xl"
                    style={{ backgroundColor: '#222a1e', border: '1px solid #344a2a', color: '#c4943d', fontFamily: "'Cinzel', serif", fontSize: '0.7rem', letterSpacing: '0.1em' }}
                  >
                    EDIT DETAILS
                  </motion.button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}