import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Search, Phone, Mail, MapPin, Calendar, BedDouble,
  Star, ChevronRight, X, Plus, User, Filter
} from 'lucide-react';

interface Guest {
  id: string;
  name: string;
  phone: string;
  email: string;
  address: string;
  nationality: string;
  totalStays: number;
  totalSpent: string;
  lastStay: string;
  status: 'active' | 'vip' | 'inactive';
  stays: {
    id: string;
    room: string;
    type: string;
    checkIn: string;
    checkOut: string;
    amount: string;
    nights: number;
  }[];
}

const GUESTS: Guest[] = [
  {
    id: 'G-001', name: 'Maria Santos', phone: '+63 912 345-6789', email: 'maria.santos@email.com',
    address: 'Makati City, Metro Manila', nationality: 'Filipino', totalStays: 5, totalSpent: '₱68,500',
    lastStay: 'Apr 10–13, 2026', status: 'vip',
    stays: [
      { id: 'RES-2026-089', room: '305', type: 'Premium', checkIn: '2026-04-10', checkOut: '2026-04-13', amount: '₱15,600', nights: 3 },
      { id: 'RES-2025-156', room: '202', type: 'Premium', checkIn: '2025-12-24', checkOut: '2025-12-27', amount: '₱15,600', nights: 3 },
      { id: 'RES-2025-087', room: '418', type: 'Suite', checkIn: '2025-08-10', checkOut: '2025-08-15', amount: '₱42,500', nights: 5 },
    ]
  },
  {
    id: 'G-002', name: 'Juan dela Cruz', phone: '+63 917 234-5678', email: 'juan.delacruz@email.com',
    address: 'Quezon City, Metro Manila', nationality: 'Filipino', totalStays: 2, totalSpent: '₱14,200',
    lastStay: 'Apr 11–12, 2026', status: 'active',
    stays: [
      { id: 'RES-2026-087', room: '212', type: 'Standard', checkIn: '2026-04-11', checkOut: '2026-04-12', amount: '₱3,500', nights: 1 },
      { id: 'RES-2025-210', room: '108', type: 'Standard', checkIn: '2025-11-02', checkOut: '2025-11-05', amount: '₱10,500', nights: 3 },
    ]
  },
  {
    id: 'G-003', name: 'Ana Reyes', phone: '+63 920 876-5432', email: 'ana.reyes@email.com',
    address: 'BGC, Taguig City', nationality: 'Filipino', totalStays: 3, totalSpent: '₱47,300',
    lastStay: 'Apr 12–14, 2026', status: 'vip',
    stays: [
      { id: 'RES-2026-091', room: '418', type: 'Suite', checkIn: '2026-04-12', checkOut: '2026-04-14', amount: '₱17,000', nights: 2 },
      { id: 'RES-2025-189', room: '303', type: 'Suite', checkIn: '2025-09-15', checkOut: '2025-09-19', amount: '₱34,000', nights: 4 },
    ]
  },
  {
    id: 'G-004', name: 'Carlos Mañalac', phone: '+63 915 543-2109', email: 'carlos.manalac@email.com',
    address: 'Pasig City, Metro Manila', nationality: 'Filipino', totalStays: 1, totalSpent: '₱7,000',
    lastStay: 'Apr 8–10, 2026', status: 'active',
    stays: [
      { id: 'RES-2026-090', room: '110', type: 'Standard', checkIn: '2026-04-08', checkOut: '2026-04-10', amount: '₱7,000', nights: 2 },
    ]
  },
  {
    id: 'G-005', name: 'Sofia Garcia', phone: '+63 913 234-5670', email: 'sofia.garcia@email.com',
    address: 'Alabang, Muntinlupa', nationality: 'Filipino', totalStays: 4, totalSpent: '₱89,700',
    lastStay: 'Apr 20–25, 2026', status: 'vip',
    stays: [
      { id: 'RES-2026-007', room: '502', type: 'Suite', checkIn: '2026-04-20', checkOut: '2026-04-25', amount: '₱42,500', nights: 5 },
    ]
  },
  {
    id: 'G-006', name: 'Roberto Villanueva', phone: '+63 921 678-9012', email: 'roberto@email.com',
    address: 'Mandaluyong City', nationality: 'Filipino', totalStays: 1, totalSpent: '₱7,000',
    lastStay: 'Apr 9–11, 2026', status: 'inactive',
    stays: [
      { id: 'RES-2026-006', room: '207', type: 'Standard', checkIn: '2026-04-09', checkOut: '2026-04-11', amount: '₱7,000', nights: 2 },
    ]
  },
];

const statusConfig = {
  vip: { label: 'VIP', color: '#c4943d', bg: 'rgba(196,148,61,0.12)', border: 'rgba(196,148,61,0.3)' },
  active: { label: 'Active', color: '#6a9954', bg: 'rgba(106,153,84,0.12)', border: 'rgba(106,153,84,0.3)' },
  inactive: { label: 'Inactive', color: '#9a9278', bg: 'rgba(154,146,120,0.12)', border: 'rgba(154,146,120,0.3)' },
};

export function GuestsPage() {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'vip' | 'active' | 'inactive'>('all');
  const [selectedGuest, setSelectedGuest] = useState<Guest | null>(null);

  const filtered = GUESTS.filter(g => {
    const matchSearch = !search || g.name.toLowerCase().includes(search.toLowerCase()) || g.email.toLowerCase().includes(search.toLowerCase()) || g.phone.includes(search);
    const matchStatus = statusFilter === 'all' || g.status === statusFilter;
    return matchSearch && matchStatus;
  });

  return (
    <div className="p-6 space-y-5" style={{ fontFamily: "'EB Garamond', serif" }}>
      {/* Header */}
      <div className="flex items-start justify-between flex-wrap gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <div className="h-px w-6" style={{ backgroundColor: '#c4943d' }} />
            <span style={{ fontFamily: "'Cinzel', serif", color: '#c4943d', fontSize: '0.65rem', letterSpacing: '0.2em' }}>GUEST REGISTRY</span>
          </div>
          <h1 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '1.6rem', fontWeight: 600, letterSpacing: '0.04em' }}>
            Guest Profiles
          </h1>
          <p style={{ color: '#9a9278', fontSize: '0.9rem' }}>{filtered.length} guests found</p>
        </div>
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.97 }}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl"
          style={{ background: 'linear-gradient(135deg, #c4943d, #a87830)', color: '#141a11', fontFamily: "'Cinzel', serif", fontWeight: 700, fontSize: '0.72rem', letterSpacing: '0.1em' }}
        >
          <Plus size={15} /> Add Guest
        </motion.button>
      </div>

      {/* Filter Bar */}
      <div className="rounded-2xl p-4" style={{ backgroundColor: '#1a2016', border: '1px solid #2a3526' }}>
        <div className="flex flex-wrap gap-3">
          <div className="relative flex-1 min-w-56">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: '#4a6a3a' }} />
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search by name, email, or phone..."
              className="w-full pl-9 pr-4 py-2.5 rounded-xl outline-none"
              style={{ backgroundColor: '#222a1e', border: '1px solid #2a3526', color: '#e8dfc8', fontSize: '0.9rem', fontFamily: "'EB Garamond', serif" }}
              onFocus={e => (e.target.style.borderColor = '#c4943d')}
              onBlur={e => (e.target.style.borderColor = '#2a3526')}
            />
          </div>
          <div className="flex gap-1.5">
            {(['all', 'vip', 'active', 'inactive'] as const).map(s => (
              <button
                key={s}
                onClick={() => setStatusFilter(s)}
                className="px-3 py-2 rounded-xl transition-all"
                style={{
                  fontFamily: "'Cinzel', serif", fontSize: '0.62rem', letterSpacing: '0.08em',
                  backgroundColor: statusFilter === s ? 'rgba(196,148,61,0.15)' : '#222a1e',
                  color: statusFilter === s ? '#c4943d' : '#9a9278',
                  border: statusFilter === s ? '1px solid rgba(196,148,61,0.3)' : '1px solid #2a3526',
                }}
              >
                {s === 'all' ? 'All Guests' : statusConfig[s].label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Guest Cards Grid */}
      <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">
        {filtered.map((guest, i) => {
          const cfg = statusConfig[guest.status];
          return (
            <motion.div
              key={guest.id}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.06 }}
              whileHover={{ y: -3 }}
              onClick={() => setSelectedGuest(guest)}
              className="rounded-2xl p-5 cursor-pointer relative overflow-hidden group"
              style={{ backgroundColor: '#1a2016', border: '1px solid #2a3526', transition: 'border-color 0.3s' }}
              onMouseEnter={e => (e.currentTarget.style.borderColor = '#4a6a3a')}
              onMouseLeave={e => (e.currentTarget.style.borderColor = '#2a3526')}
            >
              <div className="absolute top-0 left-0 right-0 h-px" style={{ background: 'linear-gradient(to right, transparent, rgba(196,148,61,0.3), transparent)' }} />

              <div className="flex items-start gap-4">
                {/* Avatar */}
                <div
                  className="w-14 h-14 rounded-2xl flex items-center justify-center flex-shrink-0"
                  style={{
                    background: `linear-gradient(135deg, ${cfg.bg} 0%, rgba(26,32,22,0) 100%)`,
                    border: `1px solid ${cfg.border}`,
                    fontSize: '1.1rem',
                    color: cfg.color,
                    fontFamily: "'Cinzel', serif",
                    fontWeight: 700,
                  }}
                >
                  {guest.name.split(' ').map(n => n[0]).join('')}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <h3 style={{ color: '#e8dfc8', fontSize: '1rem', fontFamily: "'Cinzel', serif", fontWeight: 600, letterSpacing: '0.03em' }}>
                      {guest.name}
                    </h3>
                    <div className="flex items-center gap-1 px-2 py-0.5 rounded-lg flex-shrink-0" style={{ backgroundColor: cfg.bg, border: `1px solid ${cfg.border}` }}>
                      {guest.status === 'vip' && <Star size={10} fill={cfg.color} style={{ color: cfg.color }} />}
                      <span style={{ fontFamily: "'Cinzel', serif", fontSize: '0.58rem', color: cfg.color, letterSpacing: '0.1em' }}>{cfg.label}</span>
                    </div>
                  </div>
                  <div style={{ color: '#9a9278', fontSize: '0.8rem', marginTop: '0.2rem' }} className="truncate">{guest.email}</div>
                  <div style={{ color: '#9a9278', fontSize: '0.8rem' }}>{guest.phone}</div>
                </div>
              </div>

              <div className="mt-4 pt-4 grid grid-cols-3 gap-3" style={{ borderTop: '1px solid #1e2519' }}>
                {[
                  { label: 'TOTAL STAYS', value: guest.totalStays },
                  { label: 'TOTAL SPENT', value: guest.totalSpent },
                  { label: 'LAST STAY', value: guest.lastStay.split(' ')[0] + '...' },
                ].map(stat => (
                  <div key={stat.label}>
                    <div style={{ fontFamily: "'Cinzel', serif", color: '#c4943d', fontSize: '0.95rem', fontWeight: 600 }}>{stat.value}</div>
                    <div style={{ fontFamily: "'Cinzel', serif", color: '#4a6a3a', fontSize: '0.55rem', letterSpacing: '0.1em' }}>{stat.label}</div>
                  </div>
                ))}
              </div>

              <button
                className="mt-4 w-full flex items-center justify-center gap-1 py-2 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity"
                style={{ backgroundColor: 'rgba(196,148,61,0.1)', border: '1px solid rgba(196,148,61,0.2)', color: '#c4943d', fontFamily: "'Cinzel', serif", fontSize: '0.65rem', letterSpacing: '0.1em' }}
              >
                View Full Profile <ChevronRight size={12} />
              </button>
            </motion.div>
          );
        })}
      </div>

      {/* Guest Profile Modal */}
      <AnimatePresence>
        {selectedGuest && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
            style={{ backgroundColor: 'rgba(0,0,0,0.75)' }}
            onClick={() => setSelectedGuest(null)}
          >
            <motion.div
              initial={{ scale: 0.95, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 20 }}
              onClick={e => e.stopPropagation()}
              className="rounded-2xl w-full max-w-xl max-h-[90vh] overflow-y-auto relative"
              style={{ backgroundColor: '#1a2016', border: '1px solid #344a2a', boxShadow: '0 24px 60px rgba(0,0,0,0.6)' }}
            >
              {/* Header */}
              <div className="p-6 sticky top-0 z-10" style={{ backgroundColor: '#1a2016', borderBottom: '1px solid #2a3526' }}>
                <div className="absolute top-0 left-8 right-8 h-px" style={{ background: 'linear-gradient(to right, transparent, #c4943d, transparent)' }} />
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-4">
                    <div
                      className="w-16 h-16 rounded-2xl flex items-center justify-center"
                      style={{
                        background: 'linear-gradient(135deg, rgba(196,148,61,0.2), rgba(106,153,84,0.1))',
                        border: '1px solid rgba(196,148,61,0.3)',
                        fontFamily: "'Cinzel', serif", color: '#c4943d', fontSize: '1.3rem', fontWeight: 700,
                      }}
                    >
                      {selectedGuest.name.split(' ').map(n => n[0]).join('')}
                    </div>
                    <div>
                      <span style={{ fontFamily: "'Cinzel', serif", color: '#c4943d', fontSize: '0.62rem', letterSpacing: '0.2em' }}>GUEST FILE · {selectedGuest.id}</span>
                      <h2 style={{ fontFamily: "'Cinzel', serif", color: '#e8dfc8', fontSize: '1.3rem', fontWeight: 600, letterSpacing: '0.03em' }}>
                        {selectedGuest.name}
                      </h2>
                      <div
                        className="flex items-center gap-1 px-2 py-0.5 rounded w-fit mt-1"
                        style={{ backgroundColor: statusConfig[selectedGuest.status].bg }}
                      >
                        {selectedGuest.status === 'vip' && <Star size={10} fill="#c4943d" style={{ color: '#c4943d' }} />}
                        <span style={{ fontFamily: "'Cinzel', serif", fontSize: '0.6rem', color: statusConfig[selectedGuest.status].color }}>
                          {statusConfig[selectedGuest.status].label}
                        </span>
                      </div>
                    </div>
                  </div>
                  <button onClick={() => setSelectedGuest(null)} style={{ color: '#9a9278' }}><X size={18} /></button>
                </div>
              </div>

              <div className="p-6 space-y-5">
                {/* Contact Info */}
                <div>
                  <div style={{ fontFamily: "'Cinzel', serif", color: '#c4943d', fontSize: '0.62rem', letterSpacing: '0.18em', marginBottom: '0.75rem' }}>CONTACT INFORMATION</div>
                  <div className="grid grid-cols-2 gap-3">
                    {[
                      { icon: Phone, label: 'Phone', value: selectedGuest.phone },
                      { icon: Mail, label: 'Email', value: selectedGuest.email },
                      { icon: MapPin, label: 'Address', value: selectedGuest.address },
                      { icon: User, label: 'Nationality', value: selectedGuest.nationality },
                    ].map(field => {
                      const Icon = field.icon;
                      return (
                        <div key={field.label} className="flex items-start gap-3 p-3 rounded-xl" style={{ backgroundColor: '#222a1e' }}>
                          <Icon size={14} style={{ color: '#4a6a3a', flexShrink: 0, marginTop: '3px' }} />
                          <div>
                            <div style={{ fontFamily: "'Cinzel', serif", color: '#9a9278', fontSize: '0.58rem', letterSpacing: '0.1em' }}>{field.label}</div>
                            <div style={{ color: '#e8dfc8', fontSize: '0.85rem' }}>{field.value}</div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { label: 'TOTAL STAYS', value: selectedGuest.totalStays, color: '#5a8faa' },
                    { label: 'TOTAL SPENT', value: selectedGuest.totalSpent, color: '#c4943d' },
                    { label: 'LAST STAY', value: selectedGuest.lastStay, color: '#6a9954' },
                  ].map(s => (
                    <div key={s.label} className="p-3 rounded-xl text-center" style={{ backgroundColor: '#222a1e', border: '1px solid #2a3526' }}>
                      <div style={{ fontFamily: "'Cinzel', serif", color: s.color, fontSize: '1.2rem', fontWeight: 700 }}>{s.value}</div>
                      <div style={{ fontFamily: "'Cinzel', serif", color: '#9a9278', fontSize: '0.55rem', letterSpacing: '0.1em', marginTop: '0.2rem' }}>{s.label}</div>
                    </div>
                  ))}
                </div>

                {/* Stay History */}
                <div>
                  <div style={{ fontFamily: "'Cinzel', serif", color: '#c4943d', fontSize: '0.62rem', letterSpacing: '0.18em', marginBottom: '0.75rem' }}>
                    STAY HISTORY
                  </div>
                  <div className="space-y-2">
                    {selectedGuest.stays.map(stay => (
                      <div key={stay.id} className="flex items-center justify-between px-4 py-3 rounded-xl" style={{ backgroundColor: '#222a1e', border: '1px solid #2a3526' }}>
                        <div className="flex items-center gap-3">
                          <BedDouble size={14} style={{ color: '#4a6a3a' }} />
                          <div>
                            <div style={{ color: '#e8dfc8', fontSize: '0.88rem' }}>Room {stay.room} · {stay.type}</div>
                            <div style={{ color: '#9a9278', fontSize: '0.72rem', fontFamily: "'Cinzel', serif", letterSpacing: '0.04em' }}>
                              {stay.checkIn} → {stay.checkOut} · {stay.nights} nights
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div style={{ color: '#c4943d', fontSize: '0.9rem', fontFamily: "'Cinzel', serif" }}>{stay.amount}</div>
                          <div style={{ color: '#4a6a3a', fontSize: '0.62rem', fontFamily: "'Cinzel', serif", letterSpacing: '0.06em' }}>{stay.id}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
