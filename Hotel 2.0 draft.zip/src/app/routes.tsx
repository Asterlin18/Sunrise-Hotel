import { createBrowserRouter } from "react-router";
import { LandingPage } from "./pages/LandingPage";
import { AdminDashboard } from "./pages/AdminDashboard";
import { FrontDeskDashboard } from "./pages/FrontDeskDashboard";
import { ReservationForm } from "./pages/ReservationForm";
import { GuestProfile } from "./pages/GuestProfile";
import { ReservationRecords } from "./pages/ReservationRecords";
import { RoomManagement } from "./pages/RoomManagement";
import { CheckInOut } from "./pages/CheckInOut";
import { Reports } from "./pages/Reports";
import { Settings } from "./pages/Settings";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: LandingPage,
  },
  {
    path: "/admin",
    Component: AdminDashboard,
  },
  {
    path: "/frontdesk",
    Component: FrontDeskDashboard,
  },
  {
    path: "/reservations",
    Component: ReservationRecords,
  },
  {
    path: "/reserve",
    Component: ReservationForm,
  },
  {
    path: "/guests/:id",
    Component: GuestProfile,
  },
  {
    path: "/rooms",
    Component: RoomManagement,
  },
  {
    path: "/checkinout",
    Component: CheckInOut,
  },
  {
    path: "/reports",
    Component: Reports,
  },
  {
    path: "/settings",
    Component: Settings,
  },
]);
