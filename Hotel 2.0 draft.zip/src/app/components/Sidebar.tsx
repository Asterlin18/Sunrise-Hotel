import { Link, useLocation } from 'react-router';
import { 
  LayoutDashboard, 
  Calendar, 
  DoorOpen, 
  Users, 
  ClipboardCheck, 
  FileText, 
  Settings,
  Hotel
} from 'lucide-react';

interface SidebarProps {
  role: 'admin' | 'frontdesk';
}

export function Sidebar({ role }: SidebarProps) {
  const location = useLocation();

  const adminLinks = [
    { path: '/admin', label: 'Dashboard', icon: LayoutDashboard },
    { path: '/reservations', label: 'Reservations', icon: Calendar },
    { path: '/rooms', label: 'Room Management', icon: DoorOpen },
    { path: '/checkinout', label: 'Check-In/Out', icon: ClipboardCheck },
    { path: '/reports', label: 'Reports', icon: FileText },
    { path: '/settings', label: 'Settings', icon: Settings },
  ];

  const frontdeskLinks = [
    { path: '/frontdesk', label: 'Dashboard', icon: LayoutDashboard },
    { path: '/reservations', label: 'Reservations', icon: Calendar },
    { path: '/reserve', label: 'New Booking', icon: Hotel },
    { path: '/checkinout', label: 'Check-In/Out', icon: ClipboardCheck },
  ];

  const links = role === 'admin' ? adminLinks : frontdeskLinks;

  return (
    <aside className="w-64 bg-stone-800 text-stone-100 min-h-screen fixed left-0 top-0 shadow-lg">
      <div className="p-6 border-b border-stone-700">
        <Link to="/" className="flex items-center space-x-3">
          <Hotel className="w-8 h-8 text-amber-500" />
          <div>
            <h1 className="font-semibold text-lg">Sunrise Haven</h1>
            <p className="text-xs text-stone-400">{role === 'admin' ? 'Admin' : 'Front Desk'} Portal</p>
          </div>
        </Link>
      </div>

      <nav className="mt-6">
        {links.map((link) => {
          const Icon = link.icon;
          const isActive = location.pathname === link.path;
          
          return (
            <Link
              key={link.path}
              to={link.path}
              className={`flex items-center px-6 py-3 transition-colors ${
                isActive
                  ? 'bg-amber-700 text-white border-l-4 border-amber-400'
                  : 'text-stone-300 hover:bg-stone-700 hover:text-white'
              }`}
            >
              <Icon className="w-5 h-5 mr-3" />
              <span>{link.label}</span>
            </Link>
          );
        })}
      </nav>

      <div className="absolute bottom-0 w-full p-6 border-t border-stone-700">
        <Link 
          to="/" 
          className="text-stone-400 hover:text-white text-sm flex items-center transition-colors"
        >
          <span>← Back to Website</span>
        </Link>
      </div>
    </aside>
  );
}
