import { Sidebar } from '../components/Sidebar';
import { DoorOpen, CheckCircle, AlertCircle, Clock, Edit } from 'lucide-react';

export function RoomManagement() {
  const rooms = [
    // Floor 1 - Standard Rooms
    { number: '101', floor: 1, type: 'Standard', status: 'Occupied', guest: 'Juan dela Cruz', price: '₱3,500', checkOut: '2026-04-12' },
    { number: '102', floor: 1, type: 'Standard', status: 'Available', guest: null, price: '₱3,500', checkOut: null },
    { number: '103', floor: 1, type: 'Standard', status: 'Available', guest: null, price: '₱3,500', checkOut: null },
    { number: '104', floor: 1, type: 'Standard', status: 'Occupied', guest: 'Maria Santos', price: '₱3,500', checkOut: '2026-04-09' },
    { number: '105', floor: 1, type: 'Standard', status: 'Maintenance', guest: null, price: '₱3,500', checkOut: null },
    
    // Floor 2 - Premium Rooms
    { number: '201', floor: 2, type: 'Premium', status: 'Available', guest: null, price: '₱5,500', checkOut: null },
    { number: '202', floor: 2, type: 'Premium', status: 'Occupied', guest: 'Pedro Reyes', price: '₱5,500', checkOut: '2026-04-11' },
    { number: '203', floor: 2, type: 'Premium', status: 'Occupied', guest: 'Miguel Torres', price: '₱5,500', checkOut: '2026-04-10' },
    { number: '204', floor: 2, type: 'Premium', status: 'Available', guest: null, price: '₱5,500', checkOut: null },
    { number: '205', floor: 2, type: 'Premium', status: 'Reserved', guest: 'Carlos Mendoza', price: '₱5,500', checkOut: null },
    
    // Floor 3 - Premium Rooms
    { number: '301', floor: 3, type: 'Premium', status: 'Available', guest: null, price: '₱5,500', checkOut: null },
    { number: '302', floor: 3, type: 'Premium', status: 'Occupied', guest: 'Ana Garcia', price: '₱5,500', checkOut: '2026-04-13' },
    { number: '303', floor: 3, type: 'Premium', status: 'Cleaning', guest: null, price: '₱5,500', checkOut: null },
    { number: '304', floor: 3, type: 'Premium', status: 'Available', guest: null, price: '₱5,500', checkOut: null },
    
    // Floor 5 - Suites
    { number: '501', floor: 5, type: 'Suite', status: 'Occupied', guest: 'David Kim', price: '₱8,500', checkOut: '2026-04-10' },
    { number: '502', floor: 5, type: 'Suite', status: 'Available', guest: null, price: '₱8,500', checkOut: null },
    { number: '503', floor: 5, type: 'Suite', status: 'Reserved', guest: 'Jose Mercado', price: '₱8,500', checkOut: null },
    { number: '504', floor: 5, type: 'Suite', status: 'Available', guest: null, price: '₱8,500', checkOut: null },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Available': return 'bg-emerald-100 border-emerald-300 text-emerald-800';
      case 'Occupied': return 'bg-blue-100 border-blue-300 text-blue-800';
      case 'Reserved': return 'bg-amber-100 border-amber-300 text-amber-800';
      case 'Cleaning': return 'bg-purple-100 border-purple-300 text-purple-800';
      case 'Maintenance': return 'bg-red-100 border-red-300 text-red-800';
      default: return 'bg-stone-100 border-stone-300 text-stone-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Available': return <CheckCircle className="w-5 h-5" />;
      case 'Occupied': return <DoorOpen className="w-5 h-5" />;
      case 'Reserved': return <Clock className="w-5 h-5" />;
      case 'Maintenance': return <AlertCircle className="w-5 h-5" />;
      default: return <DoorOpen className="w-5 h-5" />;
    }
  };

  const summary = {
    total: rooms.length,
    available: rooms.filter(r => r.status === 'Available').length,
    occupied: rooms.filter(r => r.status === 'Occupied').length,
    reserved: rooms.filter(r => r.status === 'Reserved').length,
    cleaning: rooms.filter(r => r.status === 'Cleaning').length,
    maintenance: rooms.filter(r => r.status === 'Maintenance').length,
  };

  const groupedByFloor = rooms.reduce((acc, room) => {
    if (!acc[room.floor]) acc[room.floor] = [];
    acc[room.floor].push(room);
    return acc;
  }, {} as Record<number, typeof rooms>);

  return (
    <div className="flex min-h-screen bg-stone-100">
      <Sidebar role="admin" />
      
      <main className="ml-64 flex-1 p-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-stone-800 mb-2">Room Management</h1>
          <p className="text-stone-600">Manage room availability and status</p>
        </div>

        {/* Summary Cards */}
        <div className="grid md:grid-cols-6 gap-4 mb-8">
          <div className="bg-white rounded-lg shadow-md p-6 border-t-4 border-stone-600">
            <p className="text-sm text-stone-600 mb-2">Total Rooms</p>
            <p className="text-3xl font-bold text-stone-800">{summary.total}</p>
          </div>
          <div className="bg-white rounded-lg shadow-md p-6 border-t-4 border-emerald-600">
            <p className="text-sm text-stone-600 mb-2">Available</p>
            <p className="text-3xl font-bold text-emerald-700">{summary.available}</p>
          </div>
          <div className="bg-white rounded-lg shadow-md p-6 border-t-4 border-blue-600">
            <p className="text-sm text-stone-600 mb-2">Occupied</p>
            <p className="text-3xl font-bold text-blue-700">{summary.occupied}</p>
          </div>
          <div className="bg-white rounded-lg shadow-md p-6 border-t-4 border-amber-600">
            <p className="text-sm text-stone-600 mb-2">Reserved</p>
            <p className="text-3xl font-bold text-amber-700">{summary.reserved}</p>
          </div>
          <div className="bg-white rounded-lg shadow-md p-6 border-t-4 border-purple-600">
            <p className="text-sm text-stone-600 mb-2">Cleaning</p>
            <p className="text-3xl font-bold text-purple-700">{summary.cleaning}</p>
          </div>
          <div className="bg-white rounded-lg shadow-md p-6 border-t-4 border-red-600">
            <p className="text-sm text-stone-600 mb-2">Maintenance</p>
            <p className="text-3xl font-bold text-red-700">{summary.maintenance}</p>
          </div>
        </div>

        {/* Legend */}
        <div className="bg-white rounded-lg shadow-md p-4 mb-6">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-stone-800">Status Legend:</h3>
            <div className="flex items-center space-x-6">
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 bg-emerald-500 rounded"></div>
                <span className="text-sm text-stone-700">Available</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 bg-blue-500 rounded"></div>
                <span className="text-sm text-stone-700">Occupied</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 bg-amber-500 rounded"></div>
                <span className="text-sm text-stone-700">Reserved</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 bg-purple-500 rounded"></div>
                <span className="text-sm text-stone-700">Cleaning</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 bg-red-500 rounded"></div>
                <span className="text-sm text-stone-700">Maintenance</span>
              </div>
            </div>
          </div>
        </div>

        {/* Rooms by Floor */}
        <div className="space-y-6">
          {Object.entries(groupedByFloor).sort(([a], [b]) => Number(b) - Number(a)).map(([floor, floorRooms]) => (
            <div key={floor} className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-semibold text-stone-800 mb-6">
                Floor {floor} - {floorRooms[0].type} Rooms
              </h2>
              <div className="grid md:grid-cols-5 gap-4">
                {floorRooms.map((room) => (
                  <div 
                    key={room.number}
                    className={`p-4 rounded-lg border-2 ${getStatusColor(room.status)} relative group hover:shadow-lg transition-shadow`}
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <p className="text-2xl font-bold">{room.number}</p>
                        <p className="text-xs opacity-75">{room.type}</p>
                      </div>
                      <div className="opacity-75">
                        {getStatusIcon(room.status)}
                      </div>
                    </div>
                    
                    <div className="mb-3">
                      <p className="text-sm font-medium mb-1">{room.status}</p>
                      {room.guest && (
                        <p className="text-xs opacity-75">{room.guest}</p>
                      )}
                      {room.checkOut && (
                        <p className="text-xs opacity-75 mt-1">Until {room.checkOut}</p>
                      )}
                    </div>

                    <div className="pt-3 border-t border-current/20">
                      <p className="text-sm font-medium">{room.price}/night</p>
                    </div>

                    <button className="absolute top-2 right-2 p-1 bg-white rounded opacity-0 group-hover:opacity-100 transition-opacity">
                      <Edit className="w-4 h-4 text-stone-600" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
