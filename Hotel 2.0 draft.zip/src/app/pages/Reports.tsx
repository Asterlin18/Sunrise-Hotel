import { Sidebar } from '../components/Sidebar';
import { BarChart3, TrendingUp, Users, DollarSign, Calendar, DoorOpen } from 'lucide-react';

export function Reports() {
  const monthlyData = [
    { month: 'Jan', reservations: 245, revenue: 1850000, occupancy: 68 },
    { month: 'Feb', reservations: 268, revenue: 2100000, occupancy: 72 },
    { month: 'Mar', reservations: 312, revenue: 2450000, occupancy: 78 },
    { month: 'Apr', reservations: 156, revenue: 1200000, occupancy: 75 },
  ];

  const roomTypeStats = [
    { type: 'Standard', total: 60, occupied: 45, revenue: 630000, percentage: 75 },
    { type: 'Premium', total: 40, occupied: 30, revenue: 825000, percentage: 75 },
    { type: 'Suite', total: 20, occupied: 12, revenue: 510000, percentage: 60 },
  ];

  const topGuests = [
    { name: 'Juan dela Cruz', stays: 4, totalSpent: 57000, lastVisit: '2026-04-08' },
    { name: 'Maria Santos', stays: 3, totalSpent: 45500, lastVisit: '2026-03-15' },
    { name: 'Pedro Reyes', stays: 3, totalSpent: 38000, lastVisit: '2026-02-20' },
    { name: 'Ana Garcia', stays: 2, totalSpent: 51000, lastVisit: '2026-04-11' },
    { name: 'David Kim', stays: 2, totalSpent: 68000, lastVisit: '2026-04-05' },
  ];

  return (
    <div className="flex min-h-screen bg-stone-100">
      <Sidebar role="admin" />
      
      <main className="ml-64 flex-1 p-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-stone-800 mb-2">Reports & Analytics</h1>
          <p className="text-stone-600">Business performance and statistics</p>
        </div>

        {/* Summary Cards */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow-md p-6 border-t-4 border-emerald-600">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-emerald-100 p-3 rounded-lg">
                <Calendar className="w-6 h-6 text-emerald-700" />
              </div>
              <TrendingUp className="w-5 h-5 text-emerald-600" />
            </div>
            <h3 className="text-3xl font-bold text-stone-800 mb-1">156</h3>
            <p className="text-stone-600 text-sm">Total Reservations (April)</p>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6 border-t-4 border-blue-600">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-blue-100 p-3 rounded-lg">
                <DoorOpen className="w-6 h-6 text-blue-700" />
              </div>
              <TrendingUp className="w-5 h-5 text-blue-600" />
            </div>
            <h3 className="text-3xl font-bold text-stone-800 mb-1">75%</h3>
            <p className="text-stone-600 text-sm">Occupancy Rate</p>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6 border-t-4 border-purple-600">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-purple-100 p-3 rounded-lg">
                <DollarSign className="w-6 h-6 text-purple-700" />
              </div>
              <TrendingUp className="w-5 h-5 text-purple-600" />
            </div>
            <h3 className="text-3xl font-bold text-stone-800 mb-1">₱2.3M</h3>
            <p className="text-stone-600 text-sm">Revenue This Month</p>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6 border-t-4 border-amber-600">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-amber-100 p-3 rounded-lg">
                <Users className="w-6 h-6 text-amber-700" />
              </div>
              <TrendingUp className="w-5 h-5 text-amber-600" />
            </div>
            <h3 className="text-3xl font-bold text-stone-800 mb-1">312</h3>
            <p className="text-stone-600 text-sm">Total Guests (April)</p>
          </div>
        </div>

        {/* Monthly Performance */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8 border-l-4 border-emerald-600">
          <div className="flex items-center mb-6">
            <BarChart3 className="w-6 h-6 text-emerald-700 mr-3" />
            <h2 className="text-xl font-semibold text-stone-800">Monthly Performance (2026)</h2>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-stone-100">
                <tr>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-stone-800">Month</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-stone-800">Reservations</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-stone-800">Revenue</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-stone-800">Occupancy Rate</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-stone-800">Trend</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-200">
                {monthlyData.map((data, index) => (
                  <tr key={data.month} className={index % 2 === 0 ? 'bg-white' : 'bg-stone-50'}>
                    <td className="px-6 py-4 font-medium text-stone-800">{data.month} 2026</td>
                    <td className="px-6 py-4 text-stone-700">{data.reservations}</td>
                    <td className="px-6 py-4 font-medium text-stone-800">₱{(data.revenue / 1000000).toFixed(2)}M</td>
                    <td className="px-6 py-4">
                      <div className="flex items-center">
                        <div className="w-32 bg-stone-200 rounded-full h-2 mr-3">
                          <div 
                            className="bg-emerald-600 h-2 rounded-full" 
                            style={{ width: `${data.occupancy}%` }}
                          ></div>
                        </div>
                        <span className="text-sm font-medium text-stone-800">{data.occupancy}%</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="flex items-center text-emerald-600 text-sm font-medium">
                        <TrendingUp className="w-4 h-4 mr-1" />
                        {index > 0 ? `+${((data.revenue / monthlyData[index-1].revenue - 1) * 100).toFixed(1)}%` : '--'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Room Type Performance */}
          <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-blue-600">
            <h2 className="text-xl font-semibold text-stone-800 mb-6">Room Type Performance</h2>
            <div className="space-y-4">
              {roomTypeStats.map((room) => (
                <div key={room.type} className="p-4 bg-stone-50 rounded-lg">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-semibold text-stone-800">{room.type} Rooms</h3>
                    <span className="text-sm text-stone-600">{room.occupied}/{room.total} Occupied</span>
                  </div>
                  
                  <div className="mb-3">
                    <div className="w-full bg-stone-200 rounded-full h-3">
                      <div 
                        className="bg-blue-600 h-3 rounded-full" 
                        style={{ width: `${room.percentage}%` }}
                      ></div>
                    </div>
                    <p className="text-xs text-stone-600 mt-1">{room.percentage}% Occupancy</p>
                  </div>

                  <div className="flex justify-between items-center pt-3 border-t border-stone-200">
                    <span className="text-sm text-stone-600">Revenue (April)</span>
                    <span className="text-lg font-bold text-blue-700">₱{(room.revenue / 1000).toFixed(0)}K</span>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-6 pt-6 border-t border-stone-200">
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <p className="text-2xl font-bold text-blue-700">87</p>
                  <p className="text-xs text-stone-600">Rooms Occupied</p>
                </div>
                <div className="text-center p-4 bg-emerald-50 rounded-lg">
                  <p className="text-2xl font-bold text-emerald-700">₱1.97M</p>
                  <p className="text-xs text-stone-600">Total Revenue</p>
                </div>
              </div>
            </div>
          </div>

          {/* Top Guests */}
          <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-purple-600">
            <h2 className="text-xl font-semibold text-stone-800 mb-6">Top Guests</h2>
            <div className="space-y-3">
              {topGuests.map((guest, index) => (
                <div key={guest.name} className="p-4 bg-stone-50 rounded-lg border border-stone-200 hover:shadow-md transition-shadow">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center">
                      <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center mr-3">
                        <span className="text-purple-700 font-bold">#{index + 1}</span>
                      </div>
                      <div>
                        <h3 className="font-semibold text-stone-800">{guest.name}</h3>
                        <p className="text-xs text-stone-600">Last visit: {guest.lastVisit}</p>
                      </div>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3 mt-3">
                    <div className="text-center p-2 bg-white rounded">
                      <p className="text-lg font-bold text-purple-700">{guest.stays}</p>
                      <p className="text-xs text-stone-600">Total Stays</p>
                    </div>
                    <div className="text-center p-2 bg-white rounded">
                      <p className="text-lg font-bold text-purple-700">₱{(guest.totalSpent / 1000).toFixed(1)}K</p>
                      <p className="text-xs text-stone-600">Total Spent</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
