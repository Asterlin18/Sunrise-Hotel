import { Sidebar } from '../components/Sidebar';
import { Settings as SettingsIcon, DoorOpen, DollarSign, Users, Save } from 'lucide-react';

export function Settings() {
  const roomTypes = [
    { id: 1, name: 'Standard Room', basePrice: 3500, capacity: 2, amenities: 'Queen bed, WiFi, AC, Cable TV' },
    { id: 2, name: 'Premium Room', basePrice: 5500, capacity: 3, amenities: 'King bed, City view, Mini bar, Work desk' },
    { id: 3, name: 'Suite', basePrice: 8500, capacity: 4, amenities: 'Living room, Kitchenette, Balcony, Premium amenities' },
  ];

  const userRoles = [
    { id: 1, name: 'Admin', permissions: 'Full system access' },
    { id: 2, name: 'Front Desk', permissions: 'Reservations, Check-in/out, Guest management' },
    { id: 3, name: 'Manager', permissions: 'Reports, Room management, Settings' },
    { id: 4, name: 'Housekeeping', permissions: 'Room status updates' },
  ];

  const pricingSeasons = [
    { season: 'Regular Season', multiplier: '1.0x', period: 'Jan-May, Sep-Nov' },
    { season: 'Peak Season', multiplier: '1.5x', period: 'Jun-Aug, Dec' },
    { season: 'Holiday Special', multiplier: '2.0x', period: 'Dec 24-31, Easter Week' },
  ];

  return (
    <div className="flex min-h-screen bg-stone-100">
      <Sidebar role="admin" />
      
      <main className="ml-64 flex-1 p-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-stone-800 mb-2">System Settings</h1>
          <p className="text-stone-600">Configure room types, pricing, and user roles</p>
        </div>

        {/* Room Types Configuration */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8 border-l-4 border-emerald-600">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center">
              <DoorOpen className="w-6 h-6 text-emerald-700 mr-3" />
              <h2 className="text-xl font-semibold text-stone-800">Room Types</h2>
            </div>
            <button className="px-4 py-2 bg-emerald-600 text-white rounded-lg font-medium hover:bg-emerald-700 transition-colors">
              Add Room Type
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-stone-100">
                <tr>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-stone-800">Room Type</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-stone-800">Base Price/Night</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-stone-800">Max Capacity</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-stone-800">Amenities</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-stone-800">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-200">
                {roomTypes.map((room) => (
                  <tr key={room.id} className="hover:bg-stone-50">
                    <td className="px-6 py-4">
                      <input 
                        type="text" 
                        defaultValue={room.name}
                        className="font-medium text-stone-800 bg-transparent border-b border-transparent hover:border-stone-300 focus:border-emerald-500 focus:outline-none"
                      />
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center">
                        <span className="text-stone-600 mr-2">₱</span>
                        <input 
                          type="number" 
                          defaultValue={room.basePrice}
                          className="w-24 text-stone-800 bg-transparent border-b border-transparent hover:border-stone-300 focus:border-emerald-500 focus:outline-none"
                        />
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <input 
                        type="number" 
                        defaultValue={room.capacity}
                        className="w-16 text-stone-800 bg-transparent border-b border-transparent hover:border-stone-300 focus:border-emerald-500 focus:outline-none"
                      />
                    </td>
                    <td className="px-6 py-4">
                      <input 
                        type="text" 
                        defaultValue={room.amenities}
                        className="w-full text-sm text-stone-700 bg-transparent border-b border-transparent hover:border-stone-300 focus:border-emerald-500 focus:outline-none"
                      />
                    </td>
                    <td className="px-6 py-4">
                      <button className="px-4 py-2 text-emerald-600 hover:bg-emerald-50 rounded transition-colors text-sm font-medium">
                        Save
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Pricing Configuration */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8 border-l-4 border-blue-600">
          <div className="flex items-center mb-6">
            <DollarSign className="w-6 h-6 text-blue-700 mr-3" />
            <h2 className="text-xl font-semibold text-stone-800">Seasonal Pricing</h2>
          </div>

          <div className="grid md:grid-cols-3 gap-6 mb-6">
            {pricingSeasons.map((pricing) => (
              <div key={pricing.season} className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                <h3 className="font-semibold text-stone-800 mb-3">{pricing.season}</h3>
                <div className="mb-3">
                  <label className="block text-xs text-stone-600 mb-1">Price Multiplier</label>
                  <input 
                    type="text" 
                    defaultValue={pricing.multiplier}
                    className="w-full px-3 py-2 border border-stone-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-xs text-stone-600 mb-1">Period</label>
                  <input 
                    type="text" 
                    defaultValue={pricing.period}
                    className="w-full px-3 py-2 border border-stone-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                  />
                </div>
              </div>
            ))}
          </div>

          <div className="bg-stone-50 rounded-lg p-4">
            <h4 className="font-medium text-stone-800 mb-3">Additional Pricing Rules</h4>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="flex items-center space-x-3 mb-2">
                  <input type="checkbox" defaultChecked className="rounded border-stone-300 text-blue-600 focus:ring-blue-500" />
                  <span className="text-sm text-stone-700">Weekend surcharge (Fri-Sat)</span>
                </label>
                <input 
                  type="number" 
                  defaultValue="10"
                  className="w-full px-3 py-2 border border-stone-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Percentage"
                />
              </div>
              <div>
                <label className="flex items-center space-x-3 mb-2">
                  <input type="checkbox" className="rounded border-stone-300 text-blue-600 focus:ring-blue-500" />
                  <span className="text-sm text-stone-700">Early bird discount (30+ days)</span>
                </label>
                <input 
                  type="number" 
                  defaultValue="15"
                  className="w-full px-3 py-2 border border-stone-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Percentage"
                />
              </div>
            </div>
          </div>

          <div className="mt-6 text-right">
            <button className="px-6 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors">
              <Save className="w-4 h-4 inline-block mr-2" />
              Save Pricing Settings
            </button>
          </div>
        </div>

        {/* User Roles Configuration */}
        <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-purple-600">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center">
              <Users className="w-6 h-6 text-purple-700 mr-3" />
              <h2 className="text-xl font-semibold text-stone-800">User Roles & Permissions</h2>
            </div>
            <button className="px-4 py-2 bg-purple-600 text-white rounded-lg font-medium hover:bg-purple-700 transition-colors">
              Add Role
            </button>
          </div>

          <div className="space-y-4">
            {userRoles.map((role) => (
              <div key={role.id} className="p-4 bg-purple-50 rounded-lg border border-purple-200">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="mb-3">
                      <label className="block text-xs text-stone-600 mb-1">Role Name</label>
                      <input 
                        type="text" 
                        defaultValue={role.name}
                        className="w-full max-w-xs px-3 py-2 border border-stone-300 rounded focus:ring-2 focus:ring-purple-500 focus:border-transparent font-medium"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-stone-600 mb-1">Permissions</label>
                      <input 
                        type="text" 
                        defaultValue={role.permissions}
                        className="w-full px-3 py-2 border border-stone-300 rounded focus:ring-2 focus:ring-purple-500 focus:border-transparent text-sm"
                      />
                    </div>
                  </div>
                  <div className="ml-4">
                    <button className="px-4 py-2 text-purple-600 hover:bg-purple-100 rounded transition-colors text-sm font-medium">
                      Edit
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-6 text-right">
            <button className="px-6 py-2 bg-purple-600 text-white rounded-lg font-medium hover:bg-purple-700 transition-colors">
              <Save className="w-4 h-4 inline-block mr-2" />
              Save Role Settings
            </button>
          </div>
        </div>

        {/* System Preferences */}
        <div className="bg-white rounded-lg shadow-md p-6 mt-8 border-l-4 border-amber-600">
          <div className="flex items-center mb-6">
            <SettingsIcon className="w-6 h-6 text-amber-700 mr-3" />
            <h2 className="text-xl font-semibold text-stone-800">System Preferences</h2>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-stone-700 mb-2">Default Check-In Time</label>
              <input 
                type="time" 
                defaultValue="14:00"
                className="w-full px-4 py-2 border border-stone-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-stone-700 mb-2">Default Check-Out Time</label>
              <input 
                type="time" 
                defaultValue="12:00"
                className="w-full px-4 py-2 border border-stone-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-stone-700 mb-2">Currency</label>
              <select className="w-full px-4 py-2 border border-stone-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent">
                <option value="PHP">PHP (₱)</option>
                <option value="USD">USD ($)</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-stone-700 mb-2">Date Format</label>
              <select className="w-full px-4 py-2 border border-stone-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent">
                <option value="YYYY-MM-DD">YYYY-MM-DD</option>
                <option value="MM/DD/YYYY">MM/DD/YYYY</option>
                <option value="DD/MM/YYYY">DD/MM/YYYY</option>
              </select>
            </div>
          </div>

          <div className="mt-6 space-y-3">
            <label className="flex items-center space-x-3">
              <input type="checkbox" defaultChecked className="rounded border-stone-300 text-amber-600 focus:ring-amber-500" />
              <span className="text-sm text-stone-700">Send email confirmation for new reservations</span>
            </label>
            <label className="flex items-center space-x-3">
              <input type="checkbox" defaultChecked className="rounded border-stone-300 text-amber-600 focus:ring-amber-500" />
              <span className="text-sm text-stone-700">Require deposit for all bookings</span>
            </label>
            <label className="flex items-center space-x-3">
              <input type="checkbox" className="rounded border-stone-300 text-amber-600 focus:ring-amber-500" />
              <span className="text-sm text-stone-700">Allow walk-in guests without reservation</span>
            </label>
          </div>

          <div className="mt-6 text-right">
            <button className="px-6 py-2 bg-amber-600 text-white rounded-lg font-medium hover:bg-amber-700 transition-colors">
              <Save className="w-4 h-4 inline-block mr-2" />
              Save System Settings
            </button>
          </div>
        </div>
      </main>
    </div>
  );
}
