import { Link } from 'react-router';
import { Hotel, MapPin, Phone, Mail, Clock, Wifi, Coffee, UtensilsCrossed } from 'lucide-react';

export function LandingPage() {
  return (
    <div className="min-h-screen bg-stone-50">
      {/* Header */}
      <header className="bg-gradient-to-r from-emerald-700 to-emerald-600 text-white shadow-lg">
        <nav className="max-w-7xl mx-auto px-4 py-6 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <Hotel className="w-10 h-10" />
            <div>
              <h1 className="text-2xl font-semibold">Sunrise Haven Hotel</h1>
              <p className="text-sm text-emerald-100">Your Tranquil Escape in Tagaytay</p>
            </div>
          </div>

          <ul className="hidden md:flex space-x-8">
            <li><a href="#about" className="hover:text-emerald-200 transition-colors">About</a></li>
            <li><a href="#rooms" className="hover:text-emerald-200 transition-colors">Rooms</a></li>
            <li><a href="#services" className="hover:text-emerald-200 transition-colors">Services</a></li>
            <li><a href="#contact" className="hover:text-emerald-200 transition-colors">Contact</a></li>
          </ul>

          <div className="flex space-x-4">
            <Link 
              to="/frontdesk" 
              className="px-6 py-2 bg-white text-emerald-700 rounded-lg font-medium hover:bg-emerald-50 transition-colors"
            >
              Staff Login
            </Link>
            <Link 
              to="/reserve" 
              className="px-6 py-2 bg-amber-600 text-white rounded-lg font-medium hover:bg-amber-700 transition-colors"
            >
              Book Now
            </Link>
          </div>
        </nav>
      </header>

      {/* Hero Section */}
      <section 
        className="relative py-32 bg-cover bg-center"
        style={{
          backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.4)), url('https://images.unsplash.com/photo-1691892591399-10a156347ade?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxUYWdheXRheSUyMFBoaWxpcHBpbmVzJTIwc2NlbmljJTIwdmlld3xlbnwxfHx8fDE3NzU2NzQ0MjN8MA&ixlib=rb-4.1.0&q=80&w=1080')`
        }}
      >
        <div className="max-w-4xl mx-auto text-center text-white px-6">
          <h2 className="text-5xl font-bold mb-6">Discover Serenity at Tagaytay's Premier Getaway</h2>
          <p className="text-xl mb-8 text-stone-100">
            Experience comfortable rooms, world-class amenities, and breathtaking views of the volcanic plains.
          </p>
          <Link 
            to="/reserve" 
            className="inline-block px-8 py-4 bg-emerald-600 rounded-lg font-semibold text-lg hover:bg-emerald-700 transition-colors shadow-xl"
          >
            Reserve Your Stay
          </Link>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-white">
        <div className="max-w-6xl mx-auto px-4 grid md:grid-cols-2 gap-12 items-center">
          <div>
            <img 
              src="https://images.unsplash.com/photo-1774192621035-20d11389f781?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob3RlbCUyMGxvYmJ5JTIwbW9kZXJuJTIwZWxlZ2FudHxlbnwxfHx8fDE3NzU2NzQ0MjR8MA&ixlib=rb-4.1.0&q=80&w=1080" 
              alt="Hotel Lobby" 
              className="rounded-lg shadow-xl"
            />
          </div>
          <div>
            <h2 className="text-4xl font-semibold mb-6 text-stone-800">About Sunrise Haven</h2>
            <p className="mb-6 text-stone-600 text-lg leading-relaxed">
              Founded in 2017, Sunrise Haven Hotel blends modern hospitality with the natural beauty of Tagaytay. 
              From cozy rooms to full-service event spaces, we cater to both leisure and business travelers.
            </p>
            <div className="space-y-3 text-stone-700">
              <div className="flex items-center">
                <div className="w-2 h-2 bg-emerald-600 rounded-full mr-3"></div>
                <span>120 guest rooms & suites</span>
              </div>
              <div className="flex items-center">
                <div className="w-2 h-2 bg-emerald-600 rounded-full mr-3"></div>
                <span>On-site restaurant & bar</span>
              </div>
              <div className="flex items-center">
                <div className="w-2 h-2 bg-emerald-600 rounded-full mr-3"></div>
                <span>Conference & event halls</span>
              </div>
              <div className="flex items-center">
                <div className="w-2 h-2 bg-emerald-600 rounded-full mr-3"></div>
                <span>Outdoor pool & fitness center</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Room Types Section */}
      <section id="rooms" className="py-20 bg-stone-100">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-4xl font-semibold mb-12 text-center text-stone-800">Room Types & Rates</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { type: 'Standard Room', price: '₱3,500', image: 'https://images.unsplash.com/photo-1629140727571-9b5c6f6267b4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBob3RlbCUyMHJvb20lMjBpbnRlcmlvcnxlbnwxfHx8fDE3NzU1NDY1NTB8MA&ixlib=rb-4.1.0&q=80&w=1080', features: ['Queen bed', 'Free WiFi', 'Air conditioning', 'Cable TV'] },
              { type: 'Premium Room', price: '₱5,500', image: 'https://images.unsplash.com/photo-1629140727571-9b5c6f6267b4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBob3RlbCUyMHJvb20lMjBpbnRlcmlvcnxlbnwxfHx8fDE3NzU1NDY1NTB8MA&ixlib=rb-4.1.0&q=80&w=1080', features: ['King bed', 'City view', 'Mini bar', 'Work desk'] },
              { type: 'Suite', price: '₱8,500', image: 'https://images.unsplash.com/photo-1629140727571-9b5c6f6267b4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBob3RlbCUyMHJvb20lMjBpbnRlcmlvcnxlbnwxfHx8fDE3NzU1NDY1NTB8MA&ixlib=rb-4.1.0&q=80&w=1080', features: ['Living room', 'Kitchenette', 'Balcony', 'Premium amenities'] },
            ].map((room) => (
              <div key={room.type} className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
                <img src={room.image} alt={room.type} className="w-full h-56 object-cover" />
                <div className="p-6">
                  <h3 className="text-2xl font-semibold mb-2 text-stone-800">{room.type}</h3>
                  <p className="text-3xl font-bold text-emerald-700 mb-4">{room.price}<span className="text-base text-stone-500">/night</span></p>
                  <ul className="space-y-2 mb-6">
                    {room.features.map((feature) => (
                      <li key={feature} className="flex items-center text-stone-600">
                        <div className="w-1.5 h-1.5 bg-emerald-600 rounded-full mr-2"></div>
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <Link 
                    to="/reserve" 
                    className="block w-full text-center px-6 py-3 bg-emerald-600 text-white rounded-lg font-medium hover:bg-emerald-700 transition-colors"
                  >
                    Book Now
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-4xl font-semibold mb-12 text-center text-stone-800">Our Services</h2>
          <div className="grid md:grid-cols-4 gap-8">
            {[
              { icon: UtensilsCrossed, title: 'Food & Beverage', desc: 'In-room dining and on-site restaurant' },
              { icon: Wifi, title: 'Free WiFi', desc: 'High-speed internet access' },
              { icon: Coffee, title: 'Room Service', desc: '24/7 room service available' },
              { icon: Clock, title: '24hr Front Desk', desc: 'Always ready to assist' },
            ].map((service) => {
              const Icon = service.icon;
              return (
                <div key={service.title} className="bg-emerald-50 rounded-lg p-6 text-center hover:shadow-lg transition-shadow">
                  <Icon className="w-12 h-12 mx-auto text-emerald-700 mb-4" />
                  <h3 className="text-xl font-semibold mb-2 text-stone-800">{service.title}</h3>
                  <p className="text-stone-600">{service.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-emerald-700 text-white">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-4xl font-semibold mb-12 text-center">Get in Touch</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-emerald-800 rounded-lg p-8 text-center">
              <Phone className="w-10 h-10 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Phone</h3>
              <a href="tel:+639123456789" className="hover:text-emerald-200 transition-colors">
                +63 912 345-6789
              </a>
            </div>
            <div className="bg-emerald-800 rounded-lg p-8 text-center">
              <Mail className="w-10 h-10 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Email</h3>
              <a href="mailto:info@sunrisehaven.com" className="hover:text-emerald-200 transition-colors">
                info@sunrisehaven.com
              </a>
            </div>
            <div className="bg-emerald-800 rounded-lg p-8 text-center">
              <MapPin className="w-10 h-10 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Address</h3>
              <p>123 Tagaytay View Rd<br />Tagaytay City, Philippines</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-stone-900 text-stone-300 py-8">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p>&copy; 2026 Sunrise Haven Hotel – All rights reserved.</p>
          <div className="mt-4 space-x-6">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-white transition-colors">FAQ</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
