import { Sidebar } from '../components/Sidebar';
import { ArrowLeft, User, Mail, Phone, MapPin, Calendar, CreditCard, FileText } from 'lucide-react';
import { Link, useParams } from 'react-router';

export function GuestProfile() {
  const { id } = useParams();

  // Mock guest data - in a real app, this would be fetched based on the ID
  const guest = {
    id: 'RES-2024-001',
    firstName: 'Juan',
    lastName: 'dela Cruz',
    email: 'juan.delacruz@email.com',
    phone: '+63 912 345 6789',
    address: '123 Main Street, Makati City, Metro Manila, Philippines',
    idType: 'Passport',
    idNumber: 'P1234567',
    currentReservation: {
      reservationId: 'RES-2024-001',
      room: '101',
      roomType: 'Standard Room',
      checkIn: '2026-04-08',
      checkOut: '2026-04-12',
      nights: 4,
      adults: 2,
      children: 0,
      amount: '₱14,000',
      deposit: '₱7,000',
      balance: '₱7,000',
      status: 'Confirmed',
      paymentMethod: 'Credit Card',
    },
    stayHistory: [
      { reservationId: 'RES-2023-142', checkIn: '2025-12-20', checkOut: '2025-12-24', room: '205', amount: '₱22,000', status: 'Completed' },
      { reservationId: 'RES-2023-089', checkIn: '2025-08-15', checkOut: '2025-08-18', room: '312', amount: '₱10,500', status: 'Completed' },
      { reservationId: 'RES-2023-045', checkIn: '2025-06-10', checkOut: '2025-06-13', room: '101', amount: '₱10,500', status: 'Completed' },
    ],
  };

  return (
    <div className="flex min-h-screen bg-stone-100">
      <Sidebar role="admin" />
      
      <main className="ml-64 flex-1 p-8">
        {/* Header */}
        <div className="mb-8">
          <Link to="/reservations" className="text-emerald-600 hover:text-emerald-700 font-medium mb-4 inline-flex items-center">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Reservations
          </Link>
          <h1 className="text-3xl font-bold text-stone-800 mt-4 mb-2">Guest Profile</h1>
          <p className="text-stone-600">Complete guest information and reservation history</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {/* Guest Information Card */}
          <div className="md:col-span-1">
            <div className="bg-white rounded-lg shadow-md p-6 border-t-4 border-emerald-600">
              <div className="text-center mb-6">
                <div className="w-24 h-24 bg-emerald-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <User className="w-12 h-12 text-emerald-700" />
                </div>
                <h2 className="text-2xl font-bold text-stone-800">{guest.firstName} {guest.lastName}</h2>
                <p className="text-stone-600 text-sm mt-1">Guest ID: {guest.id}</p>
              </div>

              <div className="space-y-4">
                <div className="flex items-start">
                  <Mail className="w-5 h-5 text-stone-500 mr-3 mt-0.5" />
                  <div>
                    <p className="text-xs text-stone-500 mb-1">Email</p>
                    <p className="text-sm text-stone-800">{guest.email}</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <Phone className="w-5 h-5 text-stone-500 mr-3 mt-0.5" />
                  <div>
                    <p className="text-xs text-stone-500 mb-1">Phone</p>
                    <p className="text-sm text-stone-800">{guest.phone}</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <MapPin className="w-5 h-5 text-stone-500 mr-3 mt-0.5" />
                  <div>
                    <p className="text-xs text-stone-500 mb-1">Address</p>
                    <p className="text-sm text-stone-800">{guest.address}</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <FileText className="w-5 h-5 text-stone-500 mr-3 mt-0.5" />
                  <div>
                    <p className="text-xs text-stone-500 mb-1">ID Information</p>
                    <p className="text-sm text-stone-800">{guest.idType}</p>
                    <p className="text-sm text-stone-600">{guest.idNumber}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Current Reservation & History */}
          <div className="md:col-span-2 space-y-6">
            {/* Current Reservation */}
            <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-blue-600">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-stone-800 flex items-center">
                  <Calendar className="w-5 h-5 text-blue-600 mr-2" />
                  Current Reservation
                </h2>
                <span className="px-4 py-1 bg-emerald-100 text-emerald-700 rounded-full text-sm font-medium">
                  {guest.currentReservation.status}
                </span>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <div className="mb-4">
                    <p className="text-xs text-stone-500 mb-1">Reservation ID</p>
                    <p className="font-medium text-stone-800">{guest.currentReservation.reservationId}</p>
                  </div>
                  <div className="mb-4">
                    <p className="text-xs text-stone-500 mb-1">Room Details</p>
                    <p className="font-medium text-stone-800">Room {guest.currentReservation.room}</p>
                    <p className="text-sm text-stone-600">{guest.currentReservation.roomType}</p>
                  </div>
                  <div className="mb-4">
                    <p className="text-xs text-stone-500 mb-1">Check-In Date</p>
                    <p className="text-stone-800">{guest.currentReservation.checkIn}</p>
                  </div>
                  <div>
                    <p className="text-xs text-stone-500 mb-1">Check-Out Date</p>
                    <p className="text-stone-800">{guest.currentReservation.checkOut}</p>
                  </div>
                </div>

                <div>
                  <div className="mb-4">
                    <p className="text-xs text-stone-500 mb-1">Duration</p>
                    <p className="text-stone-800">{guest.currentReservation.nights} nights</p>
                  </div>
                  <div className="mb-4">
                    <p className="text-xs text-stone-500 mb-1">Number of Guests</p>
                    <p className="text-stone-800">{guest.currentReservation.adults} Adults, {guest.currentReservation.children} Children</p>
                  </div>
                  <div className="mb-4">
                    <p className="text-xs text-stone-500 mb-1">Payment Method</p>
                    <p className="text-stone-800">{guest.currentReservation.paymentMethod}</p>
                  </div>
                </div>
              </div>

              <div className="mt-6 pt-6 border-t border-stone-200">
                <div className="grid grid-cols-3 gap-4">
                  <div className="bg-stone-50 p-4 rounded-lg">
                    <p className="text-xs text-stone-500 mb-1">Total Amount</p>
                    <p className="text-xl font-bold text-stone-800">{guest.currentReservation.amount}</p>
                  </div>
                  <div className="bg-emerald-50 p-4 rounded-lg">
                    <p className="text-xs text-stone-500 mb-1">Deposit Paid</p>
                    <p className="text-xl font-bold text-emerald-700">{guest.currentReservation.deposit}</p>
                  </div>
                  <div className="bg-amber-50 p-4 rounded-lg">
                    <p className="text-xs text-stone-500 mb-1">Balance Due</p>
                    <p className="text-xl font-bold text-amber-700">{guest.currentReservation.balance}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Stay History */}
            <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-purple-600">
              <h2 className="text-xl font-semibold text-stone-800 mb-6 flex items-center">
                <FileText className="w-5 h-5 text-purple-600 mr-2" />
                Stay History
              </h2>

              <div className="space-y-4">
                {guest.stayHistory.map((stay) => (
                  <div key={stay.reservationId} className="p-4 bg-stone-50 rounded-lg border border-stone-200">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-medium text-stone-800">{stay.reservationId}</h3>
                      <span className="px-3 py-1 bg-stone-200 text-stone-700 rounded-full text-xs font-medium">
                        {stay.status}
                      </span>
                    </div>
                    <div className="grid grid-cols-4 gap-4 text-sm">
                      <div>
                        <p className="text-xs text-stone-500">Check-In</p>
                        <p className="text-stone-700">{stay.checkIn}</p>
                      </div>
                      <div>
                        <p className="text-xs text-stone-500">Check-Out</p>
                        <p className="text-stone-700">{stay.checkOut}</p>
                      </div>
                      <div>
                        <p className="text-xs text-stone-500">Room</p>
                        <p className="text-stone-700">{stay.room}</p>
                      </div>
                      <div>
                        <p className="text-xs text-stone-500">Amount</p>
                        <p className="font-medium text-stone-800">{stay.amount}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-6 pt-6 border-t border-stone-200">
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div>
                    <p className="text-2xl font-bold text-purple-700">4</p>
                    <p className="text-sm text-stone-600">Total Stays</p>
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-purple-700">₱57,000</p>
                    <p className="text-sm text-stone-600">Total Spent</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
