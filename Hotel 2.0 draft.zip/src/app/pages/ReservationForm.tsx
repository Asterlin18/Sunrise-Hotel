import { Sidebar } from '../components/Sidebar';
import { ArrowLeft, User, Calendar, DoorOpen, CreditCard } from 'lucide-react';
import { Link } from 'react-router';

export function ReservationForm() {
  return (
    <div className="flex min-h-screen bg-stone-100">
      <Sidebar role="frontdesk" />
      
      <main className="ml-64 flex-1 p-8">
        {/* Header */}
        <div className="mb-8">
          <Link to="/frontdesk" className="text-emerald-600 hover:text-emerald-700 font-medium mb-4 inline-flex items-center">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Link>
          <h1 className="text-3xl font-bold text-stone-800 mt-4 mb-2">New Reservation</h1>
          <p className="text-stone-600">Create a new booking for a guest</p>
        </div>

        <div className="max-w-4xl">
          <form className="space-y-6">
            {/* Guest Information Section */}
            <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-emerald-600">
              <div className="flex items-center mb-6">
                <User className="w-6 h-6 text-emerald-700 mr-3" />
                <h2 className="text-xl font-semibold text-stone-800">Guest Information</h2>
              </div>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-stone-700 mb-2">
                    First Name <span className="text-red-600">*</span>
                  </label>
                  <input 
                    type="text" 
                    className="w-full px-4 py-3 border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                    placeholder="Juan"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-stone-700 mb-2">
                    Last Name <span className="text-red-600">*</span>
                  </label>
                  <input 
                    type="text" 
                    className="w-full px-4 py-3 border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                    placeholder="dela Cruz"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-stone-700 mb-2">
                    Email Address <span className="text-red-600">*</span>
                  </label>
                  <input 
                    type="email" 
                    className="w-full px-4 py-3 border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                    placeholder="juan.delacruz@email.com"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-stone-700 mb-2">
                    Phone Number <span className="text-red-600">*</span>
                  </label>
                  <input 
                    type="tel" 
                    className="w-full px-4 py-3 border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                    placeholder="+63 912 345 6789"
                    required
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-stone-700 mb-2">
                    Address
                  </label>
                  <textarea 
                    className="w-full px-4 py-3 border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                    rows={3}
                    placeholder="Complete address"
                  ></textarea>
                </div>

                <div>
                  <label className="block text-sm font-medium text-stone-700 mb-2">
                    ID Type <span className="text-red-600">*</span>
                  </label>
                  <select 
                    className="w-full px-4 py-3 border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                    required
                  >
                    <option value="">Select ID Type</option>
                    <option value="passport">Passport</option>
                    <option value="drivers">Driver's License</option>
                    <option value="national">National ID</option>
                    <option value="sss">SSS ID</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-stone-700 mb-2">
                    ID Number <span className="text-red-600">*</span>
                  </label>
                  <input 
                    type="text" 
                    className="w-full px-4 py-3 border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                    placeholder="ID Number"
                    required
                  />
                </div>
              </div>
            </div>

            {/* Booking Details Section */}
            <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-blue-600">
              <div className="flex items-center mb-6">
                <Calendar className="w-6 h-6 text-blue-700 mr-3" />
                <h2 className="text-xl font-semibold text-stone-800">Booking Details</h2>
              </div>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-stone-700 mb-2">
                    Check-In Date <span className="text-red-600">*</span>
                  </label>
                  <input 
                    type="date" 
                    className="w-full px-4 py-3 border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-stone-700 mb-2">
                    Check-Out Date <span className="text-red-600">*</span>
                  </label>
                  <input 
                    type="date" 
                    className="w-full px-4 py-3 border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-stone-700 mb-2">
                    Number of Adults <span className="text-red-600">*</span>
                  </label>
                  <input 
                    type="number" 
                    min="1"
                    className="w-full px-4 py-3 border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                    defaultValue="1"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-stone-700 mb-2">
                    Number of Children
                  </label>
                  <input 
                    type="number" 
                    min="0"
                    className="w-full px-4 py-3 border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                    defaultValue="0"
                  />
                </div>
              </div>
            </div>

            {/* Room Selection Section */}
            <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-purple-600">
              <div className="flex items-center mb-6">
                <DoorOpen className="w-6 h-6 text-purple-700 mr-3" />
                <h2 className="text-xl font-semibold text-stone-800">Room Selection</h2>
              </div>
              
              <div className="grid gap-4">
                <div>
                  <label className="block text-sm font-medium text-stone-700 mb-2">
                    Room Type <span className="text-red-600">*</span>
                  </label>
                  <select 
                    className="w-full px-4 py-3 border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                    required
                  >
                    <option value="">Select Room Type</option>
                    <option value="standard">Standard Room - ₱3,500/night</option>
                    <option value="premium">Premium Room - ₱5,500/night</option>
                    <option value="suite">Suite - ₱8,500/night</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-stone-700 mb-2">
                    Room Preference
                  </label>
                  <select 
                    className="w-full px-4 py-3 border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                  >
                    <option value="">No Preference</option>
                    <option value="lower">Lower Floor</option>
                    <option value="upper">Upper Floor</option>
                    <option value="view">With View</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-stone-700 mb-2">
                    Special Requests
                  </label>
                  <textarea 
                    className="w-full px-4 py-3 border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                    rows={4}
                    placeholder="Any special requests or requirements (e.g., extra bed, early check-in, etc.)"
                  ></textarea>
                </div>
              </div>
            </div>

            {/* Payment Information Section */}
            <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-amber-600">
              <div className="flex items-center mb-6">
                <CreditCard className="w-6 h-6 text-amber-700 mr-3" />
                <h2 className="text-xl font-semibold text-stone-800">Payment Information</h2>
              </div>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-stone-700 mb-2">
                    Payment Method <span className="text-red-600">*</span>
                  </label>
                  <select 
                    className="w-full px-4 py-3 border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                    required
                  >
                    <option value="">Select Payment Method</option>
                    <option value="cash">Cash</option>
                    <option value="credit">Credit Card</option>
                    <option value="debit">Debit Card</option>
                    <option value="gcash">GCash</option>
                    <option value="bank">Bank Transfer</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-stone-700 mb-2">
                    Deposit Amount <span className="text-red-600">*</span>
                  </label>
                  <input 
                    type="number" 
                    className="w-full px-4 py-3 border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                    placeholder="₱0.00"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-stone-700 mb-2">
                    Reservation Status <span className="text-red-600">*</span>
                  </label>
                  <select 
                    className="w-full px-4 py-3 border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                    required
                  >
                    <option value="pending">Pending</option>
                    <option value="confirmed">Confirmed</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex justify-end space-x-4 pt-4">
              <Link
                to="/frontdesk"
                className="px-8 py-3 border-2 border-stone-300 text-stone-700 rounded-lg font-medium hover:bg-stone-100 transition-colors"
              >
                Cancel
              </Link>
              <button
                type="submit"
                className="px-8 py-3 bg-emerald-600 text-white rounded-lg font-medium hover:bg-emerald-700 transition-colors"
              >
                Create Reservation
              </button>
            </div>
          </form>
        </div>
      </main>
    </div>
  );
}
