import { Sidebar } from '../components/Sidebar';
import { CheckCircle, DoorOpen, User, Calendar, Clock } from 'lucide-react';

export function CheckInOut() {
  const checkIns = [
    { id: 'RES-2024-015', guest: 'Carlos Mendoza', room: '201', time: '2:00 PM', adults: 2, children: 0, nights: 3 },
    { id: 'RES-2024-016', guest: 'Lisa Tan', room: '305', time: '3:00 PM', adults: 2, children: 1, nights: 2 },
    { id: 'RES-2024-017', guest: 'Robert Lee', room: '412', time: '4:30 PM', adults: 1, children: 0, nights: 4 },
    { id: 'RES-2024-018', guest: 'Sofia Cruz', room: '108', time: '5:00 PM', adults: 2, children: 2, nights: 1 },
  ];

  const checkOuts = [
    { id: 'RES-2024-007', guest: 'Miguel Torres', room: '203', time: '11:00 AM', checkIn: '2026-04-06', amount: '₱22,000', paid: '₱11,000', balance: '₱11,000' },
    { id: 'RES-2024-008', guest: 'Elena Ramos', room: '307', time: '12:00 PM', checkIn: '2026-04-07', amount: '₱22,000', paid: '₱22,000', balance: '₱0' },
    { id: 'RES-2024-009', guest: 'David Kim', room: '501', time: '12:00 PM', checkIn: '2026-04-05', amount: '₱42,500', paid: '₱20,000', balance: '₱22,500' },
  ];

  return (
    <div className="flex min-h-screen bg-stone-100">
      <Sidebar role="frontdesk" />
      
      <main className="ml-64 flex-1 p-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-stone-800 mb-2">Check-In / Check-Out</h1>
          <p className="text-stone-600">Process guest arrivals and departures</p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Check-In Section */}
          <div>
            <div className="bg-white rounded-lg shadow-md p-6 border-t-4 border-emerald-600 mb-6">
              <div className="flex items-center mb-6">
                <CheckCircle className="w-6 h-6 text-emerald-700 mr-3" />
                <h2 className="text-2xl font-semibold text-stone-800">Guest Check-In</h2>
              </div>

              <div className="space-y-4">
                {checkIns.map((checkIn) => (
                  <div key={checkIn.id} className="p-4 bg-emerald-50 rounded-lg border border-emerald-200">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-start">
                        <User className="w-5 h-5 text-emerald-700 mr-2 mt-0.5" />
                        <div>
                          <h3 className="font-semibold text-stone-800">{checkIn.guest}</h3>
                          <p className="text-sm text-stone-600">{checkIn.id}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium text-emerald-700">{checkIn.time}</p>
                        <p className="text-xs text-stone-600">Expected</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-3 mb-4">
                      <div className="text-center p-2 bg-white rounded">
                        <p className="text-xs text-stone-600 mb-1">Room</p>
                        <p className="font-semibold text-stone-800">{checkIn.room}</p>
                      </div>
                      <div className="text-center p-2 bg-white rounded">
                        <p className="text-xs text-stone-600 mb-1">Guests</p>
                        <p className="font-semibold text-stone-800">{checkIn.adults}A {checkIn.children}C</p>
                      </div>
                      <div className="text-center p-2 bg-white rounded">
                        <p className="text-xs text-stone-600 mb-1">Nights</p>
                        <p className="font-semibold text-stone-800">{checkIn.nights}</p>
                      </div>
                    </div>

                    <button className="w-full px-4 py-3 bg-emerald-600 text-white rounded-lg font-medium hover:bg-emerald-700 transition-colors">
                      Process Check-In
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Manual Check-In Form */}
            <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-emerald-600">
              <h3 className="font-semibold text-stone-800 mb-4">Walk-In Guest / Manual Check-In</h3>
              <form className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-stone-700 mb-2">Guest Name</label>
                  <input 
                    type="text"
                    className="w-full px-4 py-2 border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                    placeholder="Full name"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-stone-700 mb-2">Room Number</label>
                  <select className="w-full px-4 py-2 border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent">
                    <option value="">Select available room</option>
                    <option value="102">102 - Standard</option>
                    <option value="103">103 - Standard</option>
                    <option value="201">201 - Premium</option>
                  </select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-stone-700 mb-2">Check-In Date</label>
                    <input 
                      type="date"
                      className="w-full px-4 py-2 border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-stone-700 mb-2">Check-Out Date</label>
                    <input 
                      type="date"
                      className="w-full px-4 py-2 border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                    />
                  </div>
                </div>
                <button 
                  type="submit"
                  className="w-full px-4 py-3 bg-emerald-600 text-white rounded-lg font-medium hover:bg-emerald-700 transition-colors"
                >
                  Process Walk-In
                </button>
              </form>
            </div>
          </div>

          {/* Check-Out Section */}
          <div>
            <div className="bg-white rounded-lg shadow-md p-6 border-t-4 border-blue-600 mb-6">
              <div className="flex items-center mb-6">
                <DoorOpen className="w-6 h-6 text-blue-700 mr-3" />
                <h2 className="text-2xl font-semibold text-stone-800">Guest Check-Out</h2>
              </div>

              <div className="space-y-4">
                {checkOuts.map((checkOut) => (
                  <div key={checkOut.id} className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-start">
                        <User className="w-5 h-5 text-blue-700 mr-2 mt-0.5" />
                        <div>
                          <h3 className="font-semibold text-stone-800">{checkOut.guest}</h3>
                          <p className="text-sm text-stone-600">{checkOut.id}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium text-blue-700">{checkOut.time}</p>
                        <p className="text-xs text-stone-600">Expected</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="text-center p-2 bg-white rounded">
                        <p className="text-xs text-stone-600 mb-1">Room</p>
                        <p className="font-semibold text-stone-800">{checkOut.room}</p>
                      </div>
                      <div className="text-center p-2 bg-white rounded">
                        <p className="text-xs text-stone-600 mb-1">Check-In</p>
                        <p className="font-semibold text-stone-800">{checkOut.checkIn}</p>
                      </div>
                    </div>

                    <div className="bg-white rounded-lg p-3 mb-4">
                      <div className="flex justify-between mb-2">
                        <span className="text-sm text-stone-600">Total Amount</span>
                        <span className="font-semibold text-stone-800">{checkOut.amount}</span>
                      </div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm text-stone-600">Paid</span>
                        <span className="font-semibold text-emerald-700">{checkOut.paid}</span>
                      </div>
                      <div className="flex justify-between pt-2 border-t border-stone-200">
                        <span className="text-sm font-medium text-stone-800">Balance Due</span>
                        <span className={`font-bold ${checkOut.balance === '₱0' ? 'text-emerald-700' : 'text-amber-700'}`}>
                          {checkOut.balance}
                        </span>
                      </div>
                    </div>

                    <button className="w-full px-4 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors">
                      Process Check-Out
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Stats */}
            <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-purple-600">
              <h3 className="font-semibold text-stone-800 mb-4">Today's Summary</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-emerald-50 rounded-lg">
                  <div className="flex items-center">
                    <CheckCircle className="w-8 h-8 text-emerald-700 mr-3" />
                    <div>
                      <p className="text-sm text-stone-600">Total Check-Ins</p>
                      <p className="text-2xl font-bold text-emerald-700">15</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-stone-600">Pending</p>
                    <p className="text-lg font-semibold text-emerald-700">4</p>
                  </div>
                </div>

                <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
                  <div className="flex items-center">
                    <DoorOpen className="w-8 h-8 text-blue-700 mr-3" />
                    <div>
                      <p className="text-sm text-stone-600">Total Check-Outs</p>
                      <p className="text-2xl font-bold text-blue-700">12</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-stone-600">Pending</p>
                    <p className="text-lg font-semibold text-blue-700">3</p>
                  </div>
                </div>

                <div className="p-4 bg-amber-50 rounded-lg">
                  <div className="flex items-center mb-2">
                    <Clock className="w-5 h-5 text-amber-700 mr-2" />
                    <p className="text-sm font-medium text-stone-800">Next Expected Arrival</p>
                  </div>
                  <p className="text-lg font-semibold text-amber-700">Carlos Mendoza - 2:00 PM</p>
                  <p className="text-xs text-stone-600">Room 201</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
