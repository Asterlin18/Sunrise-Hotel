import { Sidebar } from '../components/Sidebar';
import { 
  DoorOpen, 
  Calendar, 
  Users, 
  DollarSign, 
  TrendingUp, 
  CheckCircle,
  Clock,
  AlertCircle
} from 'lucide-react';
import { Link } from 'react-router';

export function AdminDashboard() {
  const stats = [
    { label: 'Total Rooms', value: '120', icon: DoorOpen, color: 'bg-blue-600', change: '+0%' },
    { label: 'Occupied Rooms', value: '87', icon: CheckCircle, color: 'bg-emerald-600', change: '+12%' },
    { label: 'Reservations Today', value: '23', icon: Calendar, color: 'bg-amber-600', change: '+8%' },
    { label: 'Revenue This Month', value: '₱2.3M', icon: DollarSign, color: 'bg-purple-600', change: '+15%' },
  ];

  const recentReservations = [
    { id: 'RES-2024-001', guest: 'Juan dela Cruz', room: '101', checkIn: '2026-04-08', status: 'Confirmed' },
    { id: 'RES-2024-002', guest: 'Maria Santos', room: '205', checkIn: '2026-04-09', status: 'Pending' },
    { id: 'RES-2024-003', guest: 'Pedro Reyes', room: '312', checkIn: '2026-04-10', status: 'Confirmed' },
    { id: 'RES-2024-004', guest: 'Ana Garcia', room: '408', checkIn: '2026-04-11', status: 'Confirmed' },
    { id: 'RES-2024-005', guest: 'Jose Mercado', room: '520', checkIn: '2026-04-12', status: 'Pending' },
  ];

  const roomStatus = [
    { type: 'Standard', total: 60, occupied: 45, available: 15, maintenance: 0 },
    { type: 'Premium', total: 40, occupied: 30, available: 8, maintenance: 2 },
    { type: 'Suite', total: 20, occupied: 12, available: 7, maintenance: 1 },
  ];

  return (
    <div className="flex min-h-screen bg-stone-100">
      <Sidebar role="admin" />
      
      <main className="ml-64 flex-1 p-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-stone-800 mb-2">Admin Dashboard</h1>
          <p className="text-stone-600">Welcome back! Here's what's happening at Sunrise Haven today.</p>
        </div>

        {/* Stats Grid */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          {stats.map((stat) => {
            const Icon = stat.icon;
            return (
              <div key={stat.label} className="bg-white rounded-lg shadow-md p-6 border-l-4 border-l-emerald-600">
                <div className="flex items-center justify-between mb-4">
                  <div className={`${stat.color} p-3 rounded-lg`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  <span className="text-emerald-600 text-sm font-medium flex items-center">
                    <TrendingUp className="w-4 h-4 mr-1" />
                    {stat.change}
                  </span>
                </div>
                <h3 className="text-2xl font-bold text-stone-800 mb-1">{stat.value}</h3>
                <p className="text-stone-600 text-sm">{stat.label}</p>
              </div>
            );
          })}
        </div>

        {/* Main Content Grid */}
        <div className="grid md:grid-cols-2 gap-8 mb-8">
          {/* Recent Reservations */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-stone-800">Recent Reservations</h2>
              <Link to="/reservations" className="text-emerald-600 hover:text-emerald-700 text-sm font-medium">
                View All →
              </Link>
            </div>
            <div className="space-y-4">
              {recentReservations.map((reservation) => (
                <div key={reservation.id} className="flex items-center justify-between p-4 bg-stone-50 rounded-lg hover:bg-stone-100 transition-colors">
                  <div>
                    <p className="font-medium text-stone-800">{reservation.guest}</p>
                    <p className="text-sm text-stone-600">Room {reservation.room} • {reservation.id}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-stone-600 mb-1">{reservation.checkIn}</p>
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                      reservation.status === 'Confirmed' 
                        ? 'bg-emerald-100 text-emerald-700'
                        : 'bg-amber-100 text-amber-700'
                    }`}>
                      {reservation.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Room Status Overview */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-stone-800">Room Status Overview</h2>
              <Link to="/rooms" className="text-emerald-600 hover:text-emerald-700 text-sm font-medium">
                Manage →
              </Link>
            </div>
            <div className="space-y-4">
              {roomStatus.map((room) => (
                <div key={room.type} className="p-4 bg-stone-50 rounded-lg">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-medium text-stone-800">{room.type} Rooms</h3>
                    <span className="text-sm text-stone-600">{room.total} Total</span>
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-center">
                      <div className="flex items-center justify-center mb-1">
                        <CheckCircle className="w-4 h-4 text-emerald-600 mr-1" />
                        <span className="text-lg font-bold text-emerald-600">{room.occupied}</span>
                      </div>
                      <p className="text-xs text-stone-600">Occupied</p>
                    </div>
                    <div className="text-center">
                      <div className="flex items-center justify-center mb-1">
                        <DoorOpen className="w-4 h-4 text-blue-600 mr-1" />
                        <span className="text-lg font-bold text-blue-600">{room.available}</span>
                      </div>
                      <p className="text-xs text-stone-600">Available</p>
                    </div>
                    <div className="text-center">
                      <div className="flex items-center justify-center mb-1">
                        <AlertCircle className="w-4 h-4 text-orange-600 mr-1" />
                        <span className="text-lg font-bold text-orange-600">{room.maintenance}</span>
                      </div>
                      <p className="text-xs text-stone-600">Maintenance</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold text-stone-800 mb-6">Quick Actions</h2>
          <div className="grid md:grid-cols-4 gap-4">
            <Link 
              to="/reserve" 
              className="flex items-center justify-center p-4 bg-emerald-50 hover:bg-emerald-100 rounded-lg transition-colors border-2 border-emerald-200"
            >
              <Calendar className="w-5 h-5 text-emerald-700 mr-2" />
              <span className="font-medium text-emerald-700">New Reservation</span>
            </Link>
            <Link 
              to="/checkinout" 
              className="flex items-center justify-center p-4 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors border-2 border-blue-200"
            >
              <Clock className="w-5 h-5 text-blue-700 mr-2" />
              <span className="font-medium text-blue-700">Check-In/Out</span>
            </Link>
            <Link 
              to="/rooms" 
              className="flex items-center justify-center p-4 bg-purple-50 hover:bg-purple-100 rounded-lg transition-colors border-2 border-purple-200"
            >
              <DoorOpen className="w-5 h-5 text-purple-700 mr-2" />
              <span className="font-medium text-purple-700">Manage Rooms</span>
            </Link>
            <Link 
              to="/reports" 
              className="flex items-center justify-center p-4 bg-amber-50 hover:bg-amber-100 rounded-lg transition-colors border-2 border-amber-200"
            >
              <TrendingUp className="w-5 h-5 text-amber-700 mr-2" />
              <span className="font-medium text-amber-700">View Reports</span>
            </Link>
          </div>
        </div>
      </main>
    </div>
  );
}
