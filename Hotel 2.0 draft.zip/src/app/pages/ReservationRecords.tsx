import { Sidebar } from '../components/Sidebar';
import { Search, Filter, Eye, Edit, XCircle, Calendar } from 'lucide-react';
import { Link } from 'react-router';

export function ReservationRecords() {
  const reservations = [
    { id: 'RES-2024-001', guest: 'Juan dela Cruz', room: '101', type: 'Standard', checkIn: '2026-04-08', checkOut: '2026-04-12', adults: 2, children: 0, status: 'Confirmed', amount: '₱14,000' },
    { id: 'RES-2024-002', guest: 'Maria Santos', room: '205', type: 'Premium', checkIn: '2026-04-09', checkOut: '2026-04-14', adults: 2, children: 1, status: 'Pending', amount: '₱27,500' },
    { id: 'RES-2024-003', guest: 'Pedro Reyes', room: '312', type: 'Standard', checkIn: '2026-04-10', checkOut: '2026-04-13', adults: 1, children: 0, status: 'Confirmed', amount: '₱10,500' },
    { id: 'RES-2024-004', guest: 'Ana Garcia', room: '408', type: 'Suite', checkIn: '2026-04-11', checkOut: '2026-04-15', adults: 2, children: 2, status: 'Confirmed', amount: '₱34,000' },
    { id: 'RES-2024-005', guest: 'Jose Mercado', room: '520', type: 'Suite', checkIn: '2026-04-12', checkOut: '2026-04-16', adults: 3, children: 0, status: 'Pending', amount: '₱34,000' },
    { id: 'RES-2024-006', guest: 'Rosa Lim', room: '115', type: 'Standard', checkIn: '2026-04-13', checkOut: '2026-04-15', adults: 1, children: 0, status: 'Confirmed', amount: '₱7,000' },
    { id: 'RES-2024-007', guest: 'Miguel Torres', room: '203', type: 'Premium', checkIn: '2026-04-06', checkOut: '2026-04-10', adults: 2, children: 0, status: 'Checked-In', amount: '₱22,000' },
    { id: 'RES-2024-008', guest: 'Elena Ramos', room: '307', type: 'Premium', checkIn: '2026-04-07', checkOut: '2026-04-11', adults: 2, children: 1, status: 'Checked-In', amount: '₱22,000' },
    { id: 'RES-2024-009', guest: 'David Kim', room: '501', type: 'Suite', checkIn: '2026-04-05', checkOut: '2026-04-10', adults: 4, children: 0, status: 'Checked-In', amount: '₱42,500' },
    { id: 'RES-2024-010', guest: 'Carmen Diaz', room: '220', type: 'Premium', checkIn: '2026-04-15', checkOut: '2026-04-18', adults: 2, children: 0, status: 'Confirmed', amount: '₱16,500' },
  ];

  return (
    <div className="flex min-h-screen bg-stone-100">
      <Sidebar role="admin" />
      
      <main className="ml-64 flex-1 p-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-stone-800 mb-2">Reservation Records</h1>
          <p className="text-stone-600">View and manage all hotel reservations</p>
        </div>

        {/* Search and Filter Bar */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <div className="grid md:grid-cols-4 gap-4">
            <div className="md:col-span-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-stone-400" />
                <input 
                  type="text" 
                  placeholder="Search by guest name, reservation ID, or room number..."
                  className="w-full pl-10 pr-4 py-3 border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                />
              </div>
            </div>
            
            <div>
              <select className="w-full px-4 py-3 border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent">
                <option value="">All Statuses</option>
                <option value="pending">Pending</option>
                <option value="confirmed">Confirmed</option>
                <option value="checked-in">Checked-In</option>
                <option value="checked-out">Checked-Out</option>
                <option value="cancelled">Cancelled</option>
              </select>
            </div>

            <div>
              <select className="w-full px-4 py-3 border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent">
                <option value="">All Room Types</option>
                <option value="standard">Standard</option>
                <option value="premium">Premium</option>
                <option value="suite">Suite</option>
              </select>
            </div>
          </div>

          <div className="flex items-center justify-between mt-4 pt-4 border-t border-stone-200">
            <div className="flex items-center space-x-4">
              <Filter className="w-5 h-5 text-stone-600" />
              <label className="flex items-center space-x-2">
                <input type="checkbox" className="rounded border-stone-300 text-emerald-600 focus:ring-emerald-500" />
                <span className="text-sm text-stone-700">Show only today's check-ins</span>
              </label>
              <label className="flex items-center space-x-2">
                <input type="checkbox" className="rounded border-stone-300 text-emerald-600 focus:ring-emerald-500" />
                <span className="text-sm text-stone-700">Show only pending</span>
              </label>
            </div>
            <Link 
              to="/reserve" 
              className="px-6 py-2 bg-emerald-600 text-white rounded-lg font-medium hover:bg-emerald-700 transition-colors flex items-center"
            >
              <Calendar className="w-4 h-4 mr-2" />
              New Reservation
            </Link>
          </div>
        </div>

        {/* Reservations Table */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-stone-800 text-white">
                <tr>
                  <th className="px-6 py-4 text-left font-semibold">Reservation ID</th>
                  <th className="px-6 py-4 text-left font-semibold">Guest Name</th>
                  <th className="px-6 py-4 text-left font-semibold">Room</th>
                  <th className="px-6 py-4 text-left font-semibold">Type</th>
                  <th className="px-6 py-4 text-left font-semibold">Check-In</th>
                  <th className="px-6 py-4 text-left font-semibold">Check-Out</th>
                  <th className="px-6 py-4 text-left font-semibold">Guests</th>
                  <th className="px-6 py-4 text-left font-semibold">Amount</th>
                  <th className="px-6 py-4 text-left font-semibold">Status</th>
                  <th className="px-6 py-4 text-left font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-200">
                {reservations.map((reservation, index) => (
                  <tr key={reservation.id} className={index % 2 === 0 ? 'bg-white' : 'bg-stone-50'}>
                    <td className="px-6 py-4">
                      <span className="font-medium text-stone-800">{reservation.id}</span>
                    </td>
                    <td className="px-6 py-4">
                      <Link 
                        to={`/guests/${reservation.id}`} 
                        className="text-emerald-600 hover:text-emerald-700 hover:underline"
                      >
                        {reservation.guest}
                      </Link>
                    </td>
                    <td className="px-6 py-4">
                      <span className="font-medium">{reservation.room}</span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-stone-700">{reservation.type}</span>
                    </td>
                    <td className="px-6 py-4 text-stone-700">{reservation.checkIn}</td>
                    <td className="px-6 py-4 text-stone-700">{reservation.checkOut}</td>
                    <td className="px-6 py-4 text-stone-700">
                      {reservation.adults}A {reservation.children > 0 && `${reservation.children}C`}
                    </td>
                    <td className="px-6 py-4 font-medium text-stone-800">{reservation.amount}</td>
                    <td className="px-6 py-4">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                        reservation.status === 'Confirmed' ? 'bg-emerald-100 text-emerald-700' :
                        reservation.status === 'Pending' ? 'bg-amber-100 text-amber-700' :
                        reservation.status === 'Checked-In' ? 'bg-blue-100 text-blue-700' :
                        'bg-stone-100 text-stone-700'
                      }`}>
                        {reservation.status}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-2">
                        <Link 
                          to={`/guests/${reservation.id}`}
                          className="p-2 text-blue-600 hover:bg-blue-50 rounded transition-colors"
                          title="View Details"
                        >
                          <Eye className="w-4 h-4" />
                        </Link>
                        <button 
                          className="p-2 text-emerald-600 hover:bg-emerald-50 rounded transition-colors"
                          title="Edit"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button 
                          className="p-2 text-red-600 hover:bg-red-50 rounded transition-colors"
                          title="Cancel"
                        >
                          <XCircle className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          <div className="px-6 py-4 bg-stone-50 border-t border-stone-200 flex items-center justify-between">
            <p className="text-sm text-stone-600">
              Showing <span className="font-medium">1-10</span> of <span className="font-medium">10</span> reservations
            </p>
            <div className="flex space-x-2">
              <button className="px-4 py-2 border border-stone-300 rounded-lg text-stone-700 hover:bg-stone-100 transition-colors disabled:opacity-50" disabled>
                Previous
              </button>
              <button className="px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors">
                1
              </button>
              <button className="px-4 py-2 border border-stone-300 rounded-lg text-stone-700 hover:bg-stone-100 transition-colors disabled:opacity-50" disabled>
                Next
              </button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
