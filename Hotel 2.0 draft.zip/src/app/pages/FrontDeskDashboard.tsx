import { Sidebar } from '../components/Sidebar';
import { 
  Calendar, 
  Users, 
  CheckCircle,
  Clock,
  DoorOpen,
  User
} from 'lucide-react';
import { Link } from 'react-router';

export function FrontDeskDashboard() {
  const todayStats = [
    { label: 'Check-Ins Today', value: '15', icon: CheckCircle, color: 'bg-emerald-600' },
    { label: 'Check-Outs Today', value: '12', icon: DoorOpen, color: 'bg-blue-600' },
    { label: 'Expected Arrivals', value: '8', icon: Clock, color: 'bg-amber-600' },
    { label: 'Current Guests', value: '87', icon: Users, color: 'bg-purple-600' },
  ];

  const upcomingCheckIns = [
    { id: 'RES-2024-015', guest: 'Carlos Mendoza', room: '201', time: '2:00 PM', status: 'Expected' },
    { id: 'RES-2024-016', guest: 'Lisa Tan', room: '305', time: '3:00 PM', status: 'Expected' },
    { id: 'RES-2024-017', guest: 'Robert Lee', room: '412', time: '4:30 PM', status: 'Expected' },
    { id: 'RES-2024-018', guest: 'Sofia Cruz', room: '108', time: '5:00 PM', status: 'Expected' },
  ];

  const pendingCheckOuts = [
    { id: 'RES-2024-007', guest: 'Miguel Torres', room: '203', time: '11:00 AM', status: 'Pending' },
    { id: 'RES-2024-008', guest: 'Elena Ramos', room: '307', time: '12:00 PM', status: 'Pending' },
    { id: 'RES-2024-009', guest: 'David Kim', room: '501', time: '12:00 PM', status: 'Pending' },
  ];

  const availableRooms = [
    { number: '102', type: 'Standard', status: 'Clean' },
    { number: '206', type: 'Premium', status: 'Clean' },
    { number: '315', type: 'Standard', status: 'Clean' },
    { number: '420', type: 'Suite', status: 'Clean' },
    { number: '118', type: 'Standard', status: 'Cleaning' },
  ];

  return (
    <div className="flex min-h-screen bg-stone-100">
      <Sidebar role="frontdesk" />
      
      <main className="ml-64 flex-1 p-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-stone-800 mb-2">Front Desk Dashboard</h1>
          <p className="text-stone-600">Today's Operations • Wednesday, April 8, 2026</p>
        </div>

        {/* Stats Grid */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          {todayStats.map((stat) => {
            const Icon = stat.icon;
            return (
              <div key={stat.label} className="bg-white rounded-lg shadow-md p-6">
                <div className={`${stat.color} p-3 rounded-lg inline-block mb-4`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-3xl font-bold text-stone-800 mb-1">{stat.value}</h3>
                <p className="text-stone-600 text-sm">{stat.label}</p>
              </div>
            );
          })}
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-8">
          {/* Upcoming Check-Ins */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-stone-800 flex items-center">
                <CheckCircle className="w-5 h-5 text-emerald-600 mr-2" />
                Upcoming Check-Ins
              </h2>
              <Link to="/checkinout" className="text-emerald-600 hover:text-emerald-700 text-sm font-medium">
                Process →
              </Link>
            </div>
            <div className="space-y-3">
              {upcomingCheckIns.map((checkIn) => (
                <div key={checkIn.id} className="flex items-center justify-between p-4 bg-emerald-50 rounded-lg border border-emerald-200">
                  <div className="flex items-center">
                    <User className="w-8 h-8 text-emerald-700 mr-3" />
                    <div>
                      <p className="font-medium text-stone-800">{checkIn.guest}</p>
                      <p className="text-sm text-stone-600">Room {checkIn.room} • {checkIn.id}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium text-emerald-700">{checkIn.time}</p>
                    <p className="text-xs text-stone-600">{checkIn.status}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Pending Check-Outs */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-stone-800 flex items-center">
                <DoorOpen className="w-5 h-5 text-blue-600 mr-2" />
                Pending Check-Outs
              </h2>
              <Link to="/checkinout" className="text-blue-600 hover:text-blue-700 text-sm font-medium">
                Process →
              </Link>
            </div>
            <div className="space-y-3">
              {pendingCheckOuts.map((checkOut) => (
                <div key={checkOut.id} className="flex items-center justify-between p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <div className="flex items-center">
                    <User className="w-8 h-8 text-blue-700 mr-3" />
                    <div>
                      <p className="font-medium text-stone-800">{checkOut.guest}</p>
                      <p className="text-sm text-stone-600">Room {checkOut.room} • {checkOut.id}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium text-blue-700">{checkOut.time}</p>
                    <Link 
                      to="/checkinout" 
                      className="text-xs text-blue-600 hover:underline"
                    >
                      Process →
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Available Rooms & Quick Actions */}
        <div className="grid md:grid-cols-3 gap-8">
          {/* Available Rooms */}
          <div className="md:col-span-2 bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-stone-800">Available Rooms</h2>
              <Link to="/rooms" className="text-emerald-600 hover:text-emerald-700 text-sm font-medium">
                View All →
              </Link>
            </div>
            <div className="grid grid-cols-5 gap-3">
              {availableRooms.map((room) => (
                <div 
                  key={room.number} 
                  className={`p-4 rounded-lg border-2 text-center ${
                    room.status === 'Clean' 
                      ? 'bg-emerald-50 border-emerald-300' 
                      : 'bg-amber-50 border-amber-300'
                  }`}
                >
                  <p className="text-2xl font-bold text-stone-800 mb-1">{room.number}</p>
                  <p className="text-xs text-stone-600 mb-1">{room.type}</p>
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    room.status === 'Clean'
                      ? 'bg-emerald-200 text-emerald-800'
                      : 'bg-amber-200 text-amber-800'
                  }`}>
                    {room.status}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold text-stone-800 mb-6">Quick Actions</h2>
            <div className="space-y-3">
              <Link 
                to="/reserve" 
                className="block w-full p-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-center font-medium transition-colors"
              >
                <Calendar className="w-5 h-5 inline-block mr-2" />
                New Reservation
              </Link>
              <Link 
                to="/checkinout" 
                className="block w-full p-4 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-center font-medium transition-colors"
              >
                <Clock className="w-5 h-5 inline-block mr-2" />
                Check-In/Out
              </Link>
              <Link 
                to="/reservations" 
                className="block w-full p-4 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-center font-medium transition-colors"
              >
                <Users className="w-5 h-5 inline-block mr-2" />
                View Reservations
              </Link>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
