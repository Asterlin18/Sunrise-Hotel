
  # Home

  This is a code bundle for Home. The original project is available at https://www.figma.com/design/8oteN0Mto1Hw1pvbasNKMq/Home.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  